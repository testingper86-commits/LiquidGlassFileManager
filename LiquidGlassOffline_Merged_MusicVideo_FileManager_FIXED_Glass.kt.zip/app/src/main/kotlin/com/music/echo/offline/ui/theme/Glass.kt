package com.music.echo.offline.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.hazeEffect

/** The HazeState that records the app content behind floating glass surfaces. */
val LocalHaze = compositionLocalOf<HazeState?> { null }

/**
 * "Liquid Glass" surface: backdrop blur (Android 12+, via Haze), a light/dark tint at ~40% opacity
 * (0xFFFAFAFA light / 0xFF121212 dark, as in Echo's DESIGN.md) and a specular rim highlight.
 * Falls back to plain translucency on older devices.
 */
@Composable
fun Modifier.glass(shape: Shape, blur: Dp = 24.dp, opacity: Float = 0.4f): Modifier {
    val haze = LocalHaze.current
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val tintColor = (if (dark) Color(0xFF121212) else Color(0xFFFAFAFA)).copy(alpha = opacity)
    val rim = Brush.linearGradient(
        listOf(Color.White.copy(alpha = if (dark) 0.35f else 0.8f), Color.White.copy(alpha = 0.04f), Color.White.copy(alpha = 0.25f)),
    )
    val base = this.clip(shape)
    val filled = if (haze != null) {
        base.hazeEffect(haze) {
            style = HazeStyle(
                blurRadius = blur,
                tint = HazeTint(tintColor),
                noiseFactor = 0.03f,
            )
        }
    } else {
        base.background(tintColor.copy(alpha = 0.85f))
    }
    return filled.border(0.75.dp, rim, shape)
}
