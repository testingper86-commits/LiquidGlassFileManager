package com.music.echo.offline.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.music.echo.offline.data.Settings
import com.music.echo.offline.data.ThemeMode
import com.music.echo.offline.data.UiStyle

/** Echo Music's default seed colour is 0xFFED5564; these are hand-derived tonal roles from it. */
private val LightScheme = lightColorScheme(
    primary = Color(0xFF5865E8), onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E4FF), onPrimaryContainer = Color(0xFF171D63),
    secondary = Color(0xFF008F9C), onSecondary = Color.White,
    secondaryContainer = Color(0xFFB9F2F2), onSecondaryContainer = Color(0xFF00363B),
    tertiary = Color(0xFFB65BD6), onTertiary = Color.White,
    background = Color(0xFFF5F7FC), onBackground = Color(0xFF171A2A),
    surface = Color(0xFFFBFCFF), onSurface = Color(0xFF171A2A),
    surfaceVariant = Color(0xFFE8ECF8), onSurfaceVariant = Color(0xFF50566D),
    outline = Color(0xFF858BA4),
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFB8BDFF), onPrimary = Color(0xFF20276F),
    primaryContainer = Color(0xFF3943B6), onPrimaryContainer = Color(0xFFE0E4FF),
    secondary = Color(0xFF75DCE4), onSecondary = Color(0xFF00363B),
    secondaryContainer = Color(0xFF15545B), onSecondaryContainer = Color(0xFFB9F2F2),
    tertiary = Color(0xFFE4B1F5), onTertiary = Color(0xFF48105F),
    background = Color(0xFF101321), onBackground = Color(0xFFE9EBFA),
    surface = Color(0xFF15192A), onSurface = Color(0xFFE9EBFA),
    surfaceVariant = Color(0xFF292F46), onSurfaceVariant = Color(0xFFC1C6E0),
    outline = Color(0xFF777F9E),
)

@Composable
fun EchoTheme(settings: Settings, content: @Composable () -> Unit) {
    val dark = when (settings.theme) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
    }
    val ctx = LocalContext.current
    var scheme = when {
        settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> DarkScheme
        else -> LightScheme
    }
    if (dark && settings.amoled) {
        scheme = scheme.copy(
            background = Color.Black, surface = Color.Black,
            surfaceContainer = Color(0xFF0B0B0B), surfaceContainerHigh = Color(0xFF141414),
            surfaceContainerHighest = Color(0xFF1C1C1C),
        )
    }

    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let { w ->
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }

    CompositionLocalProvider(LocalUiStyle provides settings.style) {
        MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
    }
}

val LocalUiStyle = staticCompositionLocalOf { UiStyle.Material }
