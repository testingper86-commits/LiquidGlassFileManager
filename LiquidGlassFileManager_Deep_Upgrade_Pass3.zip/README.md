# Echo Offline

A fully offline re-creation of Echo Music: plays the music already on your device, with Echo's look
(translucent cards, floating tab bar, dynamic colour) and two switchable styles — **Material You**
and **Liquid Glass** (Settings → Appearance).

**No `INTERNET` permission is declared**, there are no network libraries, and no accounts.

## Build
1. Open this folder in Android Studio (Ladybug or newer, JDK 17). It will sync and generate the Gradle wrapper.
   (Or run `gradle wrapper --gradle-version 8.9` once, then `./gradlew assembleDebug`.)
2. Run on a device/emulator with Android 8.0+ (API 26). Liquid Glass backdrop blur needs Android 12+; older versions fall back to translucency.

## Features
- Scans MediaStore for songs, albums, artists (min-duration filter to hide ringtones)
- Background playback (Media3 + MediaSession): notification, lock screen, headset/Bluetooth buttons
- Queue (play next, add, reorder, remove), shuffle, repeat, speed, sleep timer
- Favorites, playlists, history, most played, recently added (Room database)
- Synced lyrics: import a `.lrc` (or `.txt`) per song; tap a line to seek
- System equalizer with presets
- Export / restore backup (favorites, playlists, history) as JSON
- Material You dynamic colour, light/dark/AMOLED

## Added in v1.1
- Resume queue (last queue, song and position restored on launch, paused)
- Picture-in-Picture (leave the app from the player screen while playing; prev/play/next in the PiP window)
- A-B repeat, skip silence, bass boost and virtualizer
- Folder browser with per-folder hide switches; sorting (title / artist / newest / longest)
- Smart lists: most played, never played, added this week
- Listening stats (plays, estimated hours, top songs and artists)
- Album-art colour theming in the Material player; swipe the mini player left/right to skip
- Share a song file

## Layout
- `data/` MediaStore scanner, Room, DataStore settings, lyrics, backup, cover-art loader
- `playback/` `MusicService`, `PlayerController`, `EqualizerController`
- `ui/theme/` theme + `Modifier.glass()` · `ui/screens/` · `ui/player/` · `ui/components/`

## Not included (needs network or is out of scope)
Streaming, online lyrics, Cast, Listen Together, Spotify import, AI playlists, song recognition, Discord RPC.

## GitHub build

This repository is ready to build in GitHub Actions.

### 1. Create the repository

1. Go to GitHub and create a new repository, for example `EchoOffline`.
2. Keep it empty if you are uploading these files.
3. Upload the **contents of this project folder** so that `build.gradle.kts`, `settings.gradle.kts`, `app/`, and `.github/` are at the repository root.

### 2. Push from a computer

```bash
git init
git add .
git commit -m "Initial EchoOffline Android project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/EchoOffline.git
git push -u origin main
```

### 3. Let GitHub build the APK

Open the repository on GitHub → **Actions** → **Android Build**.  
The workflow uses JDK 17 and Gradle 8.9, then runs:

```bash
gradle --no-daemon assembleDebug
```

When it finishes, open the workflow run and download the **EchoOffline-debug-apk** artifact.

### 4. Build a release APK

The repository also contains `.github/workflows/release.yml`.

You can run it manually from **Actions → Android Release APK → Run workflow**, or create a version tag:

```bash
git tag v1.0.0
git push origin v1.0.0
```

The release workflow currently builds an unsigned release APK. For a Play Store-ready signed APK/AAB, add Android signing secrets and a signing configuration before publishing.

### Project structure

```text
EchoOffline/
├── .github/
│   ├── workflows/
│   │   ├── android-build.yml
│   │   └── release.yml
│   └── PULL_REQUEST_TEMPLATE.md
├── app/
│   ├── build.gradle.kts
│   └── src/main/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradle/
│   └── wrapper/
├── proguard-rules.pro
└── README.md
```

### Important

- No `INTERNET` permission is declared by the app.
- The app is intended to play local device audio.
- The GitHub workflow installs Gradle 8.9 directly, so a `gradlew` wrapper script is not required for the CI build.
- For local Android Studio builds, open the project root (`EchoOffline`) and use JDK 17.

## LiquidGlass redesign integration update (2026-10-18)

- The native file-manager Activity is now the app launcher, so the file manager is the first experience rather than the music-player home screen.
- The file-manager bottom navigation is now **Home · Music · Settings**. Music opens the existing integrated music-player Activity; Settings opens the existing settings screen. Browse and Favorites are no longer bottom-navigation destinations; existing file browsing and favorite data/code are retained to avoid deleting user functionality.
- Bundled local Heroicons outline SVG assets are in `app/src/main/assets/heroicons/outline/`; MIT license and attribution are in the same asset folder. No runtime network access is required for these assets.

### Verification status

Source ZIP integrity and key manifest/navigation edits were inspected. A Gradle build and Android device smoke test have **not** been run in this environment. Treat the project as ready for a GitHub Actions build attempt, not as build-verified. The existing CI workflow remains the intended build path.

## Complete-upgrade audit (2026-10-18)

This ZIP is an incremental, source-preserving upgrade of the existing native file-manager-first project. Existing Java file operations and Kotlin Media3 player screens were retained; this update does not replace them with mock implementations.

### Feature status from source inspection
- **Storage analyzer:** present; scans readable internal shared-storage files, totals by extension category, and reports largest files. Results are estimates and inaccessible files may be omitted.
- **Duplicate finder:** present; candidates are grouped by size and confirmed using checksums. Review results before using the Recycle Bin.
- **Archive support:** ZIP creation, ZIP listing, and ZIP extraction are implemented. Extraction includes a path-containment guard against ZIP-slip. The UI now exposes an Archive manager entry. RAR/7z and other archive formats may be classified/listed, but are **not** extracted by this build.
- **File previews:** built-in viewer is wired for images, video, audio, PDF, and text, subject to Android codecs and installed viewer support.
- **Secure folder / vault:** encrypted vault implementation uses Android Keystore-backed key material and a PIN flow. This source audit does not constitute a cryptographic security review; users should keep an independent backup of important originals.
- **Accessibility:** improved accessible descriptions/focusability for category tiles and quick-access folders; the storage card announces its usage and opens the analyzer. Existing navigation and action controls also have labels where provided. A full TalkBack/device accessibility pass remains outstanding.
- **Offline behavior:** file browsing and the core file operations are local. Optional Wi-Fi transfer is network-dependent by design; no cloud service is required for local browsing/playback.

### Verification status
- ZIP structure and archive integrity: checked locally.
- Android manifest XML: checked locally.
- Java/Kotlin compilation, Gradle assembleDebug, install/launch, and physical-device tests: **not verified in this environment**. This archive does not contain a Gradle wrapper, and a working Android SDK/Gradle installation was not available for a local build. Use the repository's GitHub Actions workflow to build the APK and inspect its run result before treating it as build-verified.
