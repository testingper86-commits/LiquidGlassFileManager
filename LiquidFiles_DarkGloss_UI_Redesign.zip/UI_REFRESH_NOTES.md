# LiquidFiles dark-gloss UI redesign

This pass applies a unified mirror-black visual system to the existing native Android file manager. Existing navigation, storage operations, built-in media playback, privacy/security flows, and reusable assets are retained.

## Visual direction

- Extreme smoked-black surfaces with stronger specular sheen, crisp outer rims, and restrained metallic accent bloom.
- The same consistent layout language across the app rather than 15 unrelated screen designs.
- Fifteen selectable visual variations in Settings: BlackViscosity, ShadowMelt, Dark Mirror VR, PitchGloss, AbyssFluid, JetGlaze, MidnightGloss, InkMirror, SlickDark, ObsidianCanvas, OnyxFlow, VantaGlass, LiquidObsidian, GlossEngine, and DarkFluid.
- The style picker is scrollable on shorter displays.
- Fresh installs default to dark mode; an existing explicit appearance preference is preserved.
- Launcher background updated to near-black.

## Validation

- Project smoke tests and Android resource XML validation should be run before release.
- A Gradle build could not be completed in this environment because the Gradle distribution host (`services.gradle.org`) was unreachable. No successful APK build or device rendering is claimed.
