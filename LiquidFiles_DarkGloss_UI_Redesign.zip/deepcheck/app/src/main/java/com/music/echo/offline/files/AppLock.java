package com.music.echo.offline.files;

import com.music.echo.offline.R;

import android.content.Context;
import android.content.SharedPreferences;
import java.security.MessageDigest;

/**
 * Optional whole-app PIN/biometric gate. Re-armed every time the app leaves the
 * foreground (see MainActivity.onPause), so backgrounding the app always re-locks it.
 */
final class AppLock {
    static SharedPreferences sp(Context c) { return c.getSharedPreferences("lg_applock", Context.MODE_PRIVATE); }
    static boolean hasPin(Context c) { return sp(c).contains("pinhash"); }
    static boolean enabled(Context c) { return Ui.bool("applock_on", false) && hasPin(c); }

    private static String hash(String pin) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(("lgapplock:" + pin).getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    static void setPin(Context c, String pin) { sp(c).edit().putString("pinhash", hash(pin)).apply(); }
    static boolean checkPin(Context c, String pin) { return hasPin(c) && sp(c).getString("pinhash", "").equals(hash(pin)); }
    static void clearPin(Context c) { sp(c).edit().remove("pinhash").apply(); }
}
