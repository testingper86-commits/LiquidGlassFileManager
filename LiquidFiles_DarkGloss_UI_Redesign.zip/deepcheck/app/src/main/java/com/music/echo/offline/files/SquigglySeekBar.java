package com.music.echo.offline.files;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.SeekBar;

/** Android 13-inspired squiggly playback progress control for the existing local player. */
public final class SquigglySeekBar extends SeekBar {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private int active = 0xFFB9A4FF;
    private int inactive = 0x667F7F8A;
    private float density;
    public SquigglySeekBar(Context c) { super(c); init(c); }
    public SquigglySeekBar(Context c, AttributeSet a) { super(c,a); init(c); }
    public SquigglySeekBar(Context c, AttributeSet a, int d) { super(c,a,d); init(c); }
    private void init(Context c) {
        density = c.getResources().getDisplayMetrics().density;
        setSplitTrack(false);
        if (Build.VERSION.SDK_INT >= 21) {
            setProgressTintList(ColorStateList.valueOf(0x00000000));
            setSecondaryProgressTintList(ColorStateList.valueOf(0x00000000));
            setProgressBackgroundTintList(ColorStateList.valueOf(0x00000000));
            setThumbTintList(ColorStateList.valueOf(0x00000000));
        }
        setContentDescription("Squiggly playback progress");
    }
    public void setSquiggleColors(int played, int unplayed) { active=played; inactive=unplayed; invalidate(); }
    @Override protected synchronized void onDraw(Canvas canvas) {
        // Keep SeekBar's native touch/accessibility machinery; replace only its visual track.
        super.onDraw(canvas);
        float left=getPaddingLeft()+8*density, right=getWidth()-getPaddingRight()-8*density;
        if (right<=left) return;
        float cy=getHeight()/2f;
        float fraction=getMax()>0 ? Math.max(0f,Math.min(1f,getProgress()/(float)getMax())) : 0f;
        float end=left+(right-left)*fraction;
        paint.setStrokeCap(Paint.Cap.ROUND); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.7f*density); paint.setColor(inactive);
        canvas.drawLine(left,cy,right,cy,paint);
        if (end>left) {
            paint.setColor(active); paint.setStrokeWidth(2.2f*density); path.reset();
            float amp=Math.min(3.4f*density,Math.max(1.4f*density,getHeight()*0.12f));
            float wavelength=10f*density; path.moveTo(left,cy);
            for (float x=left+1*density;x<=end;x+=1.5f*density) {
                float y=cy+(float)Math.sin((x-left)*Math.PI*2/wavelength)*amp; path.lineTo(x,y);
            }
            path.lineTo(end,cy); canvas.drawPath(path,paint);
            paint.setStyle(Paint.Style.FILL); canvas.drawCircle(end,cy,3.2f*density,paint);
        }
    }
}
