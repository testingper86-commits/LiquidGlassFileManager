package com.music.echo.offline.files;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;

/**
 * The Settings screen. Every pixel is drawn natively (gradients, glass panels, vector icons,
 * custom switches); there are no bitmap/screenshot assets involved.
 */
final class SettingsScreen {
    // ---- icon ids ----
    static final int I_PALETTE = 0, I_FOLDER = 1, I_PLAY = 2, I_SHIELD = 3, I_INFO = 4, I_SUN = 5, I_MOON = 6,
            I_GEAR = 7, I_CHECK = 8, I_EYE = 9, I_CODE = 10, I_SORT = 11, I_VIDEO = 12, I_IMAGE = 13,
            I_CLOCK = 14, I_LOCK = 15, I_STACK = 16, I_WIFI = 17, I_CHEV_R = 18, I_CHEV_D = 19, I_BACK = 20;

    static final int WHITE = 0xFFFFFFFF;

    final MainActivity a;
    TextView cacheVal, lockVal;

    SettingsScreen(MainActivity a) { this.a = a; }

    // =====================================================================================
    //  Build
    // =====================================================================================
    void build(LinearLayout out) {
        out.removeAllViews();
        out.setPadding(0, 0, 0, 0);

        // ---- header: glass back button + title ----
        LinearLayout hd = new LinearLayout(a);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout back = new FrameLayout(a);
        back.setBackground(new Glass(24, 70, 40, true));
        ImageView bi = new ImageView(a);
        bi.setImageDrawable(new Ic(I_BACK, Ui.WHITE));
        back.addView(bi, new FrameLayout.LayoutParams(Ui.dp(24), Ui.dp(24), Gravity.CENTER));
        back.setContentDescription("Back");
        back.setClickable(true);
        back.setOnClickListener(v -> { Ui.tick(v); a.selectTab(0); });
        Ui.press(back);
        hd.addView(back, new LinearLayout.LayoutParams(Ui.dp(48), Ui.dp(48)));
        LinearLayout titles = new LinearLayout(a);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(tv("Settings", 28, Ui.WHITE, true));
        TextView sub = tv("Make LiquidFiles yours", 15, Ui.SUB, false);
        sub.setPadding(0, Ui.dp(3), 0, 0);
        titles.addView(sub);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f);
        tl.leftMargin = Ui.dp(16);
        hd.addView(titles, tl);
        out.addView(hd, lp(-1, -2, 18, 12, 18, 16));

        buildAppearance(out);
        buildFileBrowsing(out);
        buildMedia(out);
        buildPrivacy(out);
        buildAbout(out);

        // ---- footer tagline ----
        LinearLayout ft = new LinearLayout(a);
        ft.setGravity(Gravity.CENTER);
        ft.addView(line(), new LinearLayout.LayoutParams(Ui.dp(34), Ui.dp(1)));
        TextView t = tv("Your files. Your device. Your control.", 11.5f, Ui.SUB, false);
        t.setLetterSpacing(0.06f);
        t.setPadding(Ui.dp(12), 0, Ui.dp(12), 0);
        ft.addView(t);
        ft.addView(line(), new LinearLayout.LayoutParams(Ui.dp(34), Ui.dp(1)));
        out.addView(ft, lp(-1, -2, 18, 6, 18, 8));
    }

    // ---- Appearance ----
    void buildAppearance(LinearLayout out) {
        LinearLayout card = card();
        card.addView(cardHeader(I_PALETTE, Color.rgb(190, 110, 255), Color.rgb(120, 90, 255),
                "Appearance", "Theme, colors and visual style", false));

        int mode = Ui.themeMode(a);
        LinearLayout seg = new LinearLayout(a);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        seg.addView(modeButton(0, "Light", I_SUN, mode == 0), segLp(false));
        seg.addView(modeButton(1, "Dark", I_MOON, mode == 1), segLp(true));
        seg.addView(modeButton(2, "System", I_GEAR, mode == 2), segLp(true));
        card.addView(seg, lp(-1, Ui.dp(44), 14, 2, 14, 12));

        // accent colour row (an inner glass plate)
        LinearLayout acc = new LinearLayout(a);
        acc.setGravity(Gravity.CENTER_VERTICAL);
        acc.setBackground(new Glass(20, 34, 22, false));
        acc.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(14), Ui.dp(10));
        View sw = new View(a);
        sw.setBackground(swatch(Ui.theme, 12));
        acc.addView(sw, new LinearLayout.LayoutParams(Ui.dp(68), Ui.dp(48)));
        LinearLayout tx = new LinearLayout(a);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.addView(tv("Accent color", 16.5f, Ui.WHITE, true));
        TextView s2 = tv("Used for highlights and active elements", 13, Ui.SUB, false);
        s2.setPadding(0, Ui.dp(3), 0, 0);
        s2.setSingleLine(false);
        tx.addView(s2);
        LinearLayout.LayoutParams txp = new LinearLayout.LayoutParams(0, -2, 1f);
        txp.leftMargin = Ui.dp(14);
        txp.rightMargin = Ui.dp(6);
        acc.addView(tx, txp);
        acc.addView(icon(I_CHEV_R, Ui.SUB, 20), new LinearLayout.LayoutParams(Ui.dp(20), Ui.dp(20)));
        acc.setClickable(true);
        acc.setContentDescription("Accent color");
        acc.setOnClickListener(v -> { Ui.tick(v); accentDialog(); });
        Ui.press(acc);
        card.addView(acc, lp(-1, -2, 12, 0, 12, 12));
        out.addView(card, cardLp());
    }

    View modeButton(final int mode, String label, int ic, boolean selected) {
        LinearLayout b = new LinearLayout(a);
        b.setGravity(Gravity.CENTER);
        b.setOrientation(LinearLayout.HORIZONTAL);
        int fg;
        if (selected) {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Ui.gradA, Ui.gradB});
            g.setCornerRadius(Ui.dp(16));
            g.setStroke(Ui.dp(1), Color.argb(150, 255, 255, 255));
            b.setBackground(g);
            fg = WHITE;
        } else if (mode == 1) { // "Dark" always looks like a dark chip, like the reference
            GradientDrawable g = new GradientDrawable();
            g.setColor(Color.argb(Ui.light ? 235 : 200, 52, 60, 86));
            g.setCornerRadius(Ui.dp(16));
            g.setStroke(Ui.dp(1), Color.argb(70, 255, 255, 255));
            b.setBackground(g);
            fg = WHITE;
        } else {
            b.setBackground(new Glass(16, Ui.light ? 150 : 52, Ui.light ? 110 : 34, false));
            fg = Ui.WHITE;
        }
        ImageView iv = icon(ic, fg, 18);
        b.addView(iv, new LinearLayout.LayoutParams(Ui.dp(18), Ui.dp(18)));
        TextView t = tv(label, 14.5f, fg, false);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.leftMargin = Ui.dp(6);
        b.addView(t, tp);
        if (selected) {
            FrameLayout badge = new FrameLayout(a);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(Color.argb(70, 255, 255, 255));
            bg.setStroke(Ui.dp(1.2f), Color.argb(230, 255, 255, 255));
            badge.setBackground(bg);
            ImageView ck = icon(I_CHECK, WHITE, 12);
            badge.addView(ck, new FrameLayout.LayoutParams(Ui.dp(12), Ui.dp(12), Gravity.CENTER));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(Ui.dp(20), Ui.dp(20));
            bp.leftMargin = Ui.dp(6);
            b.addView(badge, bp);
        }
        b.setClickable(true);
        b.setContentDescription(label + (selected ? ", selected" : ""));
        b.setOnClickListener(v -> {
            if (Ui.themeMode(a) == mode) return;
            Ui.tick(v);
            Ui.sp.edit().putInt("theme_mode", mode).apply();
            boolean wantLight = Ui.wantLight(a);
            if (wantLight != Ui.light) { Ui.setLight(wantLight, true); a.recreate(); }
            else build(a.settings);
        });
        Ui.press(b);
        return b;
    }

    // ---- File browsing ----
    void buildFileBrowsing(LinearLayout out) {
        LinearLayout card = card();
        card.addView(cardHeader(I_FOLDER, Color.rgb(60, 215, 200), Color.rgb(70, 190, 150),
                "File browsing", "How files are displayed and sorted", true));
        card.addView(toggleRow(I_EYE, "Show hidden files", "hidden", false, () -> a.filesView.reload()));
        card.addView(divider());
        card.addView(toggleRow(I_CODE, "Show file extensions", "extensions", true, () -> reloadBrowsers()));
        card.addView(divider());
        card.addView(toggleRow(I_SORT, "Sort folders first", "foldersfirst", true, () -> reloadBrowsers()));
        out.addView(card, cardLp());
    }

    void reloadBrowsers() {
        a.filesView.reload();
        a.favView.reload();
        a.listView.ad.notifyDataSetChanged();
    }

    // ---- Media & viewer ----
    void buildMedia(LinearLayout out) {
        LinearLayout card = card();
        card.addView(cardHeader(I_PLAY, Color.rgb(150, 105, 255), Color.rgb(90, 140, 255),
                "Media & viewer", "Video, image and playback settings", true));
        card.addView(dropdownRow(I_VIDEO, "Default video player", "video_player",
                new String[]{"Built-in player", "External player"}));
        card.addView(divider());
        card.addView(dropdownRow(I_IMAGE, "Image viewer", "image_viewer",
                new String[]{"Built-in viewer", "External viewer"}));
        card.addView(divider());
        card.addView(toggleRow(I_CLOCK, "Remember playback position", "remember_pos", true, null));
        out.addView(card, cardLp());
    }

    // ---- Privacy & storage ----
    void buildPrivacy(LinearLayout out) {
        LinearLayout card = card();
        card.addView(cardHeader(I_SHIELD, Color.rgb(60, 215, 215), Color.rgb(70, 160, 240),
                "Privacy & storage", "Security and storage management", true));

        lockVal = tv(AppLock.enabled(a) ? "On" : "Off", 15, Ui.SUB, false);
        card.addView(valueRow(I_LOCK, "App lock", lockVal, v -> appLockDialog()));
        card.addView(divider());

        cacheVal = tv("…", 15, Ui.SUB, false);
        card.addView(valueRow(I_STACK, "Clear cache", cacheVal, v -> confirmClearCache()));
        updateCacheSize();
        card.addView(divider());

        card.addView(toggleRow(I_WIFI, "Local Wi-Fi transfer", "wifi_transfer", true, null));
        out.addView(card, cardLp());
    }

    // ---- About ----
    void buildAbout(LinearLayout out) {
        LinearLayout card = card();
        card.addView(cardHeader(I_INFO, Color.rgb(165, 110, 255), Color.rgb(105, 120, 255),
                "About", "App information and credits", true));

        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(16), Ui.dp(12));
        FrameLayout logo = new FrameLayout(a);
        logo.setBackground(tile(Color.rgb(165, 110, 255), Color.rgb(80, 150, 255), 15));
        logo.addView(icon(I_FOLDER, WHITE, 28), new FrameLayout.LayoutParams(Ui.dp(28), Ui.dp(28), Gravity.CENTER));
        r.addView(logo, new LinearLayout.LayoutParams(Ui.dp(52), Ui.dp(52)));
        LinearLayout tx = new LinearLayout(a);
        tx.setOrientation(LinearLayout.VERTICAL);
        TextView nm = tv("LiquidFiles Offline Manager", 16.5f, Ui.WHITE, true);
        nm.setSingleLine(true);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        tx.addView(nm);
        TextView ver = tv(versionLine(), 13, Ui.SUB, false);
        ver.setPadding(0, Ui.dp(4), 0, 0);
        tx.addView(ver);
        LinearLayout.LayoutParams txp = new LinearLayout.LayoutParams(0, -2, 1f);
        txp.leftMargin = Ui.dp(14);
        r.addView(tx, txp);
        r.addView(icon(I_CHEV_R, Ui.WHITE, 22), new LinearLayout.LayoutParams(Ui.dp(22), Ui.dp(22)));
        pressable(r, v -> { Ui.tick(v); a.showAbout(); });
        card.addView(r);
        out.addView(card, cardLp());
    }

    String versionLine() {
        try {
            android.content.pm.PackageInfo i = a.getPackageManager().getPackageInfo(a.getPackageName(), 0);
            long code = android.os.Build.VERSION.SDK_INT >= 28 ? i.getLongVersionCode() : i.versionCode;
            return "Version " + i.versionName + " (Build " + code + ")";
        } catch (Exception e) { return "Version"; }
    }

    // =====================================================================================
    //  Behaviour
    // =====================================================================================
    void appLockDialog() {
        if (!AppLock.hasPin(a)) { a.setAppLockPin(); return; }
        final boolean on = AppLock.enabled(a);
        String[] items = {on ? "Turn off app lock" : "Turn on app lock", "Change PIN"};
        new AlertDialog.Builder(a).setTitle("App lock").setItems(items, (d, w) -> {
            if (w == 0) { Ui.set("applock_on", !on); a.unlocked = true; build(a.settings); }
            else a.setAppLockPin();
        }).setNegativeButton("Cancel", null).show();
    }

    void confirmClearCache() {
        new AlertDialog.Builder(a).setTitle("Clear cache?")
                .setMessage("Removes temporary files and thumbnails. Your own files are never touched.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", (d, w) -> {
                    if (cacheVal != null) cacheVal.setText("…");
                    a.io.execute(() -> {
                        wipe(a.getCacheDir());
                        wipe(a.getExternalCacheDir());
                        Thumbs.clear();
                        a.runOnUiThread(() -> { Ui.toast(a, "Cache cleared"); updateCacheSize(); });
                    });
                }).show();
    }

    void updateCacheSize() {
        a.io.execute(() -> {
            final long n = size(a.getCacheDir()) + size(a.getExternalCacheDir());
            a.runOnUiThread(() -> { if (cacheVal != null) cacheVal.setText(n <= 0 ? "0 B" : Ui.size(n)); });
        });
    }

    static long size(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long n = 0;
        File[] c = f.listFiles();
        if (c != null) for (File x : c) n += size(x);
        return n;
    }

    /** Deletes everything inside a cache dir (the dir itself stays). */
    static void wipe(File dir) {
        if (dir == null) return;
        File[] c = dir.listFiles();
        if (c == null) return;
        for (File x : c) { if (x.isDirectory()) wipe(x); x.delete(); }
    }

    void accentDialog() {
        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Ui.light ? Color.argb(250, 246, 247, 252) : Color.argb(248, 40, 46, 70));
        bg.setCornerRadii(new float[]{Ui.dp(28), Ui.dp(28), Ui.dp(28), Ui.dp(28), 0, 0, 0, 0});
        box.setBackground(bg);
        box.setPadding(Ui.dp(20), Ui.dp(22), Ui.dp(20), Ui.dp(24) + Ui.bottom);
        box.addView(tv("Dark-gloss style", 20, Ui.WHITE, true));
        TextView sub = tv("15 mirror-black finishes · choose an accent identity", 13.5f, Ui.SUB, false);
        sub.setPadding(0, Ui.dp(4), 0, Ui.dp(16));
        box.addView(sub);
        int n = Ui.THEMES.length, per = 4;
        for (int rowStart = 0; rowStart < n; rowStart += per) {
            LinearLayout line = new LinearLayout(a);
            for (int i = rowStart; i < rowStart + per; i++) {
                if (i >= n) { line.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f)); continue; }
                final int idx = i;
                LinearLayout cell = new LinearLayout(a);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                FrameLayout dot = new FrameLayout(a);
                GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Ui.GA[i], Ui.GB[i]});
                g.setShape(GradientDrawable.OVAL);
                g.setStroke(Ui.dp(i == Ui.theme ? 3 : 1), i == Ui.theme ? Ui.WHITE : Color.argb(110, 255, 255, 255));
                dot.setBackground(g);
                if (i == Ui.theme) dot.addView(icon(I_CHECK, WHITE, 22), new FrameLayout.LayoutParams(Ui.dp(22), Ui.dp(22), Gravity.CENTER));
                cell.addView(dot, new LinearLayout.LayoutParams(Ui.dp(54), Ui.dp(54)));
                TextView nm = tv(Ui.THEMES[i], 11.5f, i == Ui.theme ? Ui.WHITE : Ui.SUB, false);
                nm.setGravity(Gravity.CENTER);
                nm.setSingleLine(true);
                nm.setPadding(0, Ui.dp(6), 0, 0);
                cell.addView(nm, new LinearLayout.LayoutParams(-1, -2));
                cell.setClickable(true);
                cell.setOnClickListener(v -> { Ui.tick(v); Ui.setTheme(idx, true); d.dismiss(); a.recolor(); });
                Ui.press(cell);
                line.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
            }
            box.addView(line, lp(-1, -2, 0, 0, 0, 14));
        }
        ScrollView themeScroll = new ScrollView(a);
        themeScroll.setFillViewport(false);
        themeScroll.setClipToPadding(false);
        themeScroll.addView(box, new ScrollView.LayoutParams(-1, -2));
        d.setContentView(themeScroll);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int maxHeight = Math.min((int) (a.getResources().getDisplayMetrics().heightPixels * 0.72f), Ui.dp(620));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, maxHeight);
            w.setGravity(Gravity.BOTTOM);
        }
        d.show();
    }

    // =====================================================================================
    //  Row / card builders
    // =====================================================================================
    LinearLayout card() {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(new Glass(26, 56, 34, true));
        Ui.round(c, 26);
        return c;
    }

    LinearLayout.LayoutParams cardLp() { return lp(-1, -2, 18, 0, 18, 12); }

    View cardHeader(int ic, int gA, int gB, String title, String sub, boolean divider) {
        LinearLayout wrap = new LinearLayout(a);
        wrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout h = new LinearLayout(a);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(divider ? 14 : 12));
        FrameLayout tile = new FrameLayout(a);
        tile.setBackground(tile(gA, gB, 15));
        tile.addView(icon(ic, WHITE, 26), new FrameLayout.LayoutParams(Ui.dp(26), Ui.dp(26), Gravity.CENTER));
        h.addView(tile, new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(46)));
        LinearLayout tx = new LinearLayout(a);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.addView(tv(title, 20, Ui.WHITE, true));
        TextView s = tv(sub, 13.5f, Ui.SUB, false);
        s.setPadding(0, Ui.dp(3), 0, 0);
        tx.addView(s);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tp.leftMargin = Ui.dp(14);
        h.addView(tx, tp);
        wrap.addView(h);
        if (divider) wrap.addView(divider());
        return wrap;
    }

    /** Standard row: [icon][title ........ right-view]. */
    LinearLayout baseRow(int ic, String title, View right) {
        LinearLayout r = new LinearLayout(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(Ui.dp(56));
        r.setPadding(Ui.dp(16), 0, Ui.dp(16), 0);
        FrameLayout ib = new FrameLayout(a);
        ib.addView(icon(ic, Ui.WHITE, 24), new FrameLayout.LayoutParams(Ui.dp(24), Ui.dp(24), Gravity.CENTER));
        r.addView(ib, new LinearLayout.LayoutParams(Ui.dp(46), Ui.dp(24)));
        TextView t = tv(title, 16.5f, Ui.WHITE, false);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tp.leftMargin = Ui.dp(14);
        tp.rightMargin = Ui.dp(8);
        r.addView(t, tp);
        if (right != null) r.addView(right);
        return r;
    }

    View toggleRow(int ic, String title, final String key, boolean def, final Runnable after) {
        final Tgl tg = new Tgl(a, Ui.bool(key, def), on -> {
            Ui.set(key, on);
            if (after != null) after.run();
        });
        LinearLayout r = baseRow(ic, title, tg);
        pressable(r, v -> { Ui.tick(v); tg.toggle(); });
        r.setContentDescription(title);
        return r;
    }

    View valueRow(int ic, String title, TextView value, View.OnClickListener l) {
        LinearLayout right = new LinearLayout(a);
        right.setGravity(Gravity.CENTER_VERTICAL);
        right.addView(value);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(Ui.dp(20), Ui.dp(20));
        cp.leftMargin = Ui.dp(6);
        right.addView(icon(I_CHEV_R, Ui.SUB, 20), cp);
        LinearLayout r = baseRow(ic, title, right);
        pressable(r, v -> { Ui.tick(v); l.onClick(v); });
        return r;
    }

    View dropdownRow(int ic, String title, final String key, final String[] options) {
        int cur = Math.max(0, Math.min(options.length - 1, Ui.sp.getInt(key, 0)));
        final LinearLayout pill = new LinearLayout(a);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackground(new Glass(14, Ui.light ? 150 : 40, Ui.light ? 110 : 28, false));
        pill.setPadding(Ui.dp(12), 0, Ui.dp(10), 0);
        pill.setMinimumWidth(Ui.dp(128));
        final TextView val = tv(options[cur], 14, Ui.WHITE, false);
        val.setSingleLine(true);
        pill.addView(val, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(Ui.dp(16), Ui.dp(16));
        cp.leftMargin = Ui.dp(8);
        pill.addView(icon(I_CHEV_D, Ui.WHITE, 16), cp);
        pill.setClickable(true);
        pill.setOnClickListener(v -> { Ui.tick(v); showMenu(pill, key, options, val); });
        LinearLayout r = baseRow(ic, title, null);
        r.addView(pill, new LinearLayout.LayoutParams(-2, Ui.dp(36)));
        // allow the title to wrap so the pill keeps its width on narrow screens
        ((TextView) r.getChildAt(1)).setSingleLine(false);
        ((TextView) r.getChildAt(1)).setMaxLines(2);
        r.setClickable(true);
        r.setOnClickListener(v -> pill.performClick());
        return r;
    }

    void showMenu(final View anchor, final String key, final String[] options, final TextView valueView) {
        final PopupWindow pw = new PopupWindow(a);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Ui.light ? Color.argb(250, 250, 250, 254) : Color.argb(248, 46, 52, 78));
        bg.setCornerRadius(Ui.dp(16));
        bg.setStroke(Ui.dp(1), Color.argb(Ui.light ? 40 : 70, 255, 255, 255));
        box.setBackground(bg);
        box.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
        int cur = Ui.sp.getInt(key, 0);
        for (int i = 0; i < options.length; i++) {
            final int idx = i;
            LinearLayout it = new LinearLayout(a);
            it.setGravity(Gravity.CENTER_VERTICAL);
            it.setPadding(Ui.dp(16), 0, Ui.dp(14), 0);
            TextView t = tv(options[i], 15, i == cur ? Ui.accent : Ui.WHITE, i == cur);
            it.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            if (i == cur) it.addView(icon(I_CHECK, Ui.accent, 18), new LinearLayout.LayoutParams(Ui.dp(18), Ui.dp(18)));
            it.setOnClickListener(v -> {
                Ui.sp.edit().putInt(key, idx).apply();
                valueView.setText(options[idx]);
                pw.dismiss();
            });
            box.addView(it, new LinearLayout.LayoutParams(-1, Ui.dp(46)));
        }
        int w = Math.max(anchor.getWidth(), Ui.dp(176));
        pw.setContentView(box);
        pw.setWidth(w);
        pw.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        pw.setFocusable(true);
        pw.setOutsideTouchable(true);
        pw.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        pw.setElevation(Ui.dp(12));
        pw.showAsDropDown(anchor, anchor.getWidth() - w, Ui.dp(6));
    }

    void pressable(View r, View.OnClickListener l) {
        r.setClickable(true);
        r.setFocusable(true);
        r.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(46, 255, 255, 255)), null, new ColorDrawable(Color.BLACK)));
        r.setOnClickListener(l);
    }

    View divider() {
        View v = new View(a);
        v.setBackgroundColor(Ui.light ? Color.argb(34, 20, 25, 45) : Color.argb(40, 255, 255, 255));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, Math.max(1, Ui.dp(0.8f)));
        p.leftMargin = Ui.dp(16);
        p.rightMargin = Ui.dp(16);
        v.setLayoutParams(p);
        return v;
    }

    View line() {
        View v = new View(a);
        v.setBackgroundColor(Ui.light ? Color.argb(70, 20, 25, 45) : Color.argb(70, 255, 255, 255));
        return v;
    }

    LinearLayout.LayoutParams segLp(boolean gap) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -1, 1f);
        if (gap) p.leftMargin = Ui.dp(8);
        return p;
    }

    LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(Ui.dp(l), Ui.dp(t), Ui.dp(r), Ui.dp(b));
        return p;
    }

    TextView tv(String text, float sp, int color, boolean medium) {
        TextView v = new TextView(a);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        v.setIncludeFontPadding(false);
        return v;
    }

    ImageView icon(int kind, int color, float sizeDp) {
        ImageView v = new ImageView(a);
        v.setImageDrawable(new Ic(kind, color));
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        return v;
    }

    /** Gradient rounded tile with a soft top highlight and light rim (section icon tiles). */
    Drawable tile(int c1, int c2, float radiusDp) {
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        base.setCornerRadius(Ui.dp(radiusDp));
        GradientDrawable hi = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.argb(95, 255, 255, 255), Color.argb(0, 255, 255, 255)});
        hi.setCornerRadius(Ui.dp(radiusDp));
        GradientDrawable rim = new GradientDrawable();
        rim.setColor(Color.TRANSPARENT);
        rim.setCornerRadius(Ui.dp(radiusDp));
        rim.setStroke(Math.max(1, Ui.dp(1)), Color.argb(120, 255, 255, 255));
        return new LayerDrawable(new Drawable[]{base, hi, rim});
    }

    Drawable swatch(int themeIdx, float radiusDp) {
        int a1 = Ui.GA[themeIdx], b1 = Ui.GB[themeIdx];
        int mid = Glyphs.mix(a1, b1, 0.45f);
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Glyphs.mix(a1, Color.rgb(255, 150, 230), 0.35f), mid, b1});
        base.setCornerRadius(Ui.dp(radiusDp));
        GradientDrawable hi = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.argb(110, 255, 255, 255), Color.argb(0, 255, 255, 255)});
        hi.setCornerRadius(Ui.dp(radiusDp));
        GradientDrawable rim = new GradientDrawable();
        rim.setColor(Color.TRANSPARENT);
        rim.setCornerRadius(Ui.dp(radiusDp));
        rim.setStroke(Math.max(1, Ui.dp(1.2f)), Color.argb(170, 255, 255, 255));
        return new LayerDrawable(new Drawable[]{base, hi, rim});
    }

    // =====================================================================================
    //  Glass panel drawable
    // =====================================================================================
    static final class Glass extends Drawable {
        final float r;
        final int topA, botA;
        final boolean irid;
        final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), hi = new Paint(Paint.ANTI_ALIAS_FLAG),
                rim = new Paint(Paint.ANTI_ALIAS_FLAG), glint = new Paint(Paint.ANTI_ALIAS_FLAG),
                dark = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF rf = new RectF();

        Glass(float radiusDp, int topA, int botA, boolean irid) {
            this.r = Ui.dp(radiusDp);
            this.topA = topA;
            this.botA = botA;
            this.irid = irid;
            rim.setStyle(Paint.Style.STROKE);
            glint.setStyle(Paint.Style.STROKE);
            dark.setStyle(Paint.Style.STROKE);
        }

        @Override protected void onBoundsChange(Rect b) {
            float w = b.width(), h = b.height();
            if (w <= 0 || h <= 0) return;
            fill.setShader(new LinearGradient(0, b.top, 0, b.bottom, Color.argb(topA, 255, 255, 255), Color.argb(botA, 255, 255, 255), Shader.TileMode.CLAMP));
            hi.setShader(new LinearGradient(b.left, b.top, b.left + w * 0.9f, b.top + h * 0.7f,
                    Color.argb(Ui.light ? 90 : 46, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP));
            float sw = Math.max(1f, Ui.dp(1.2f));
            rim.setStrokeWidth(sw);
            rim.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                    new int[]{Color.argb(210, 255, 255, 255), Color.argb(72, 255, 255, 255), Color.argb(46, 255, 255, 255), Color.argb(130, 255, 255, 255)},
                    new float[]{0f, 0.35f, 0.7f, 1f}, Shader.TileMode.CLAMP));
            dark.setStrokeWidth(sw);
            dark.setColor(Color.argb(Ui.light ? 46 : 0, 20, 25, 50));
            if (irid) {
                glint.setStrokeWidth(Math.max(1f, Ui.dp(1.7f)));
                int ca = Ui.gradA, cb = Ui.gradB;
                glint.setShader(new RadialGradient(b.right - Ui.dp(8), b.top + Ui.dp(6), Math.max(w * 0.55f, Ui.dp(120)),
                        new int[]{Color.argb(240, Color.red(ca), Color.green(ca), Color.blue(ca)),
                                Color.argb(190, Color.red(cb), Color.green(cb), Color.blue(cb)),
                                Color.argb(0, Color.red(cb), Color.green(cb), Color.blue(cb))},
                        new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
            }
        }

        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            float sw = Math.max(1f, Ui.dp(1.2f)) / 2f;
            rf.set(b.left + sw, b.top + sw, b.right - sw, b.bottom - sw);
            float rad = Math.min(r, Math.min(rf.width(), rf.height()) / 2f);
            c.drawRoundRect(rf, rad, rad, fill);
            c.drawRoundRect(rf, rad, rad, hi);
            c.drawRoundRect(rf, rad, rad, rim);
            if (Ui.light) c.drawRoundRect(rf, rad, rad, dark);
            if (irid) c.drawRoundRect(rf, rad, rad, glint);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    // =====================================================================================
    //  Switch with gradient track and white knob
    // =====================================================================================
    interface OnToggle { void on(boolean v); }

    static final class Tgl extends View {
        boolean on;
        float p;
        ValueAnimator va;
        final OnToggle cb;
        final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG), knob = new Paint(Paint.ANTI_ALIAS_FLAG),
                rim = new Paint(Paint.ANTI_ALIAS_FLAG), shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF rf = new RectF();

        Tgl(Context c, boolean on, OnToggle cb) {
            super(c);
            this.on = on;
            this.p = on ? 1f : 0f;
            this.cb = cb;
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(Math.max(1f, Ui.dp(1)));
            shadow.setColor(Color.argb(60, 0, 0, 0));
            knob.setColor(Color.WHITE);
            setClickable(true);
            setOnClickListener(v -> { Ui.tick(v); toggle(); });
        }

        void toggle() {
            on = !on;
            if (va != null) va.cancel();
            va = ValueAnimator.ofFloat(p, on ? 1f : 0f);
            va.setDuration(220);
            va.addUpdateListener(a -> { p = (float) a.getAnimatedValue(); invalidate(); });
            va.start();
            if (cb != null) cb.on(on);
        }

        @Override protected void onMeasure(int wm, int hm) { setMeasuredDimension(Ui.dp(56), Ui.dp(32)); }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), rad = h / 2f;
            rf.set(0, 0, w, h);
            // off track
            track.setShader(null);
            track.setColor(Ui.light ? Color.argb(46, 20, 25, 50) : Color.argb(64, 255, 255, 255));
            c.drawRoundRect(rf, rad, rad, track);
            // on track (gradient), faded in
            if (p > 0f) {
                track.setShader(new LinearGradient(0, 0, w, 0, Ui.gradA, Ui.gradB, Shader.TileMode.CLAMP));
                track.setAlpha(Math.round(255 * p));
                c.drawRoundRect(rf, rad, rad, track);
                track.setShader(null);
            }
            rim.setColor(Color.argb(Ui.light ? 60 : 90, 255, 255, 255));
            rf.inset(rim.getStrokeWidth() / 2f, rim.getStrokeWidth() / 2f);
            c.drawRoundRect(rf, rad, rad, rim);
            float kr = h / 2f - Ui.dp(4);
            float cx = rad + (w - 2 * rad) * p;
            c.drawCircle(cx, h / 2f + Ui.dp(1), kr + Ui.dp(0.5f), shadow);
            knob.setAlpha(Math.round(225 + 30 * p));
            c.drawCircle(cx, h / 2f, kr, knob);
        }
    }

    // =====================================================================================
    //  Page background: soft warm light on slate, drawn with gradients only
    // =====================================================================================
    static final class Bg extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Bg(Context c) { super(c); }

        void blob(Canvas c, float cx, float cy, float r, int col) {
            p.setShader(new RadialGradient(cx, cy, r, col, Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)), Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, p);
            p.setShader(null);
        }

        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (w == 0 || h == 0) return;
            boolean L = Ui.light;
            c.drawColor(L ? Color.rgb(206, 212, 232) : Color.rgb(84, 91, 122));
            if (L) {
                blob(c, w * 0.02f, h * 0.26f, w * 0.85f, Color.argb(235, 255, 214, 190));
                blob(c, w * 0.12f, h * 0.02f, w * 0.90f, Color.argb(215, 255, 226, 212));
                blob(c, w * 0.98f, h * 0.12f, w * 0.80f, Color.argb(200, 170, 185, 240));
                blob(c, w * 0.60f, h * 0.55f, w * 1.00f, Color.argb(170, 190, 190, 244));
                blob(c, w * 0.25f, h * 1.02f, w * 0.95f, Color.argb(235, 255, 205, 175));
                blob(c, w * 1.00f, h * 0.88f, w * 0.80f, Color.argb(190, 170, 182, 238));
            } else {
                blob(c, w * 0.02f, h * 0.26f, w * 0.80f, Color.argb(235, 232, 192, 164));
                blob(c, w * 0.10f, h * 0.02f, w * 0.85f, Color.argb(215, 214, 184, 172));
                blob(c, w * 0.98f, h * 0.10f, w * 0.75f, Color.argb(205, 92, 104, 150));
                blob(c, w * 0.58f, h * 0.55f, w * 1.00f, Color.argb(175, 112, 110, 152));
                blob(c, w * 0.22f, h * 1.02f, w * 0.90f, Color.argb(235, 204, 156, 124));
                blob(c, w * 1.00f, h * 0.88f, w * 0.80f, Color.argb(195, 94, 102, 140));
            }
            // soft diagonal light shafts
            for (int i = 0; i < 3; i++) {
                c.save();
                c.rotate(-28f, w * 0.1f, 0);
                float x0 = w * (0.05f + 0.30f * i), bw = w * (0.20f + 0.05f * i);
                p.setShader(new LinearGradient(x0, 0, x0 + bw, 0,
                        new int[]{Color.argb(0, 255, 255, 255), Color.argb(L ? 70 : 38, 255, 255, 255), Color.argb(0, 255, 255, 255)},
                        new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
                c.drawRect(x0, -h * 0.2f, x0 + bw, h * 1.4f, p);
                p.setShader(null);
                c.restore();
            }
            // gentle bottom vignette
            p.setShader(new LinearGradient(0, h * 0.82f, 0, h, Color.argb(0, 0, 0, 0), Color.argb(L ? 18 : 46, 0, 0, 0), Shader.TileMode.CLAMP));
            c.drawRect(0, h * 0.82f, w, h, p);
            p.setShader(null);
        }
    }

    // =====================================================================================
    //  Vector icons on a 24x24 grid
    // =====================================================================================
    static final class Ic extends Drawable {
        final int kind;
        final Paint st = new Paint(Paint.ANTI_ALIAS_FLAG), fl = new Paint(Paint.ANTI_ALIAS_FLAG);

        Ic(int kind, int color) {
            this.kind = kind;
            st.setStyle(Paint.Style.STROKE);
            st.setColor(color);
            st.setStrokeCap(Paint.Cap.ROUND);
            st.setStrokeJoin(Paint.Join.ROUND);
            st.setStrokeWidth(1.8f);
            fl.setStyle(Paint.Style.FILL);
            fl.setColor(color);
        }

        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            if (b.width() <= 0 || b.height() <= 0) return;
            c.save();
            c.translate(b.left, b.top);
            c.scale(b.width() / 24f, b.height() / 24f);
            paint(c);
            c.restore();
        }

        void pl(Canvas c, boolean close, float... v) {
            Path pa = new Path();
            pa.moveTo(v[0], v[1]);
            for (int i = 2; i + 1 < v.length; i += 2) pa.lineTo(v[i], v[i + 1]);
            if (close) pa.close();
            c.drawPath(pa, st);
        }

        void paint(Canvas c) {
            switch (kind) {
                case I_PALETTE: {
                    Path pa = new Path();
                    pa.addCircle(12, 12, 9.8f, Path.Direction.CW);
                    float[][] holes = {{7.4f, 12.3f, 1.5f}, {9.8f, 7.7f, 1.5f}, {14.6f, 7.5f, 1.5f}, {17.3f, 11.4f, 1.5f}};
                    for (float[] hh : holes) { Path hp = new Path(); hp.addCircle(hh[0], hh[1], hh[2], Path.Direction.CW); pa.op(hp, Path.Op.DIFFERENCE); }
                    Path notch = new Path();
                    notch.addCircle(16.2f, 18.6f, 3.1f, Path.Direction.CW);
                    pa.op(notch, Path.Op.DIFFERENCE);
                    c.drawPath(pa, fl);
                    break;
                }
                case I_FOLDER:
                    pl(c, true, 3.3f, 6.6f, 9.3f, 6.6f, 11.5f, 9.2f, 20.7f, 9.2f, 20.7f, 18.6f, 3.3f, 18.6f);
                    break;
                case I_PLAY: {
                    Path pa = new Path();
                    pa.moveTo(8.3f, 5.8f); pa.lineTo(18.6f, 12f); pa.lineTo(8.3f, 18.2f); pa.close();
                    c.drawPath(pa, fl);
                    c.drawPath(pa, st);
                    break;
                }
                case I_SHIELD: {
                    Path pa = new Path();
                    pa.moveTo(12, 3); pa.lineTo(19.6f, 6f); pa.lineTo(19.6f, 11.4f);
                    pa.cubicTo(19.6f, 16f, 16.5f, 19.6f, 12, 21f);
                    pa.cubicTo(7.5f, 19.6f, 4.4f, 16f, 4.4f, 11.4f);
                    pa.lineTo(4.4f, 6f); pa.close();
                    c.drawPath(pa, st);
                    break;
                }
                case I_INFO:
                    c.drawCircle(12, 12, 9.2f, st);
                    c.drawCircle(12, 7.9f, 1.2f, fl);
                    pl(c, false, 12, 11, 12, 16.6f);
                    break;
                case I_SUN:
                    c.drawCircle(12, 12, 3.9f, st);
                    for (int i = 0; i < 8; i++) {
                        double an = Math.toRadians(i * 45);
                        float cs = (float) Math.cos(an), sn = (float) Math.sin(an);
                        c.drawLine(12 + cs * 7f, 12 + sn * 7f, 12 + cs * 9.4f, 12 + sn * 9.4f, st);
                    }
                    break;
                case I_MOON: {
                    Path a1 = new Path(), a2 = new Path();
                    a1.addCircle(12, 12, 8.6f, Path.Direction.CW);
                    a2.addCircle(16.6f, 8.8f, 7f, Path.Direction.CW);
                    a1.op(a2, Path.Op.DIFFERENCE);
                    c.drawPath(a1, st);
                    break;
                }
                case I_GEAR: {
                    Path pa = new Path();
                    boolean first = true;
                    for (int i = 0; i < 8; i++) {
                        float base = i * 45f;
                        float[][] pts = {{6.9f, base - 13}, {9.5f, base - 8}, {9.5f, base + 8}, {6.9f, base + 13}};
                        for (float[] q : pts) {
                            double an = Math.toRadians(q[1]);
                            float x = 12 + (float) Math.cos(an) * q[0], y = 12 + (float) Math.sin(an) * q[0];
                            if (first) { pa.moveTo(x, y); first = false; } else pa.lineTo(x, y);
                        }
                    }
                    pa.close();
                    c.drawPath(pa, st);
                    c.drawCircle(12, 12, 2.9f, st);
                    break;
                }
                case I_CHECK: {
                    float w0 = st.getStrokeWidth();
                    st.setStrokeWidth(2.4f);
                    pl(c, false, 6.2f, 12.6f, 10.3f, 16.6f, 17.8f, 8f);
                    st.setStrokeWidth(w0);
                    break;
                }
                case I_EYE: {
                    Path pa = new Path();
                    pa.moveTo(2.4f, 12);
                    pa.cubicTo(5, 7.2f, 8.3f, 5.6f, 12, 5.6f);
                    pa.cubicTo(15.7f, 5.6f, 19, 7.2f, 21.6f, 12);
                    pa.cubicTo(19, 16.8f, 15.7f, 18.4f, 12, 18.4f);
                    pa.cubicTo(8.3f, 18.4f, 5, 16.8f, 2.4f, 12);
                    pa.close();
                    c.drawPath(pa, st);
                    c.drawCircle(12, 12, 3f, st);
                    break;
                }
                case I_CODE:
                    pl(c, false, 8, 7.5f, 3.5f, 12, 8, 16.5f);
                    pl(c, false, 16, 7.5f, 20.5f, 12, 16, 16.5f);
                    pl(c, false, 13.8f, 5.5f, 10.2f, 18.5f);
                    break;
                case I_SORT:
                    pl(c, false, 8, 19, 8, 5);
                    pl(c, false, 4.5f, 8.5f, 8, 5, 11.5f, 8.5f);
                    pl(c, false, 16, 5, 16, 19);
                    pl(c, false, 12.5f, 15.5f, 16, 19, 19.5f, 15.5f);
                    break;
                case I_VIDEO:
                    c.drawRoundRect(new RectF(2.8f, 6.4f, 15.2f, 17.6f), 3.2f, 3.2f, st);
                    pl(c, true, 15.2f, 10.6f, 21.2f, 7.4f, 21.2f, 16.6f, 15.2f, 13.4f);
                    break;
                case I_IMAGE:
                    c.drawRoundRect(new RectF(3.4f, 4.4f, 20.6f, 19.6f), 3.6f, 3.6f, st);
                    c.drawCircle(9f, 9.9f, 1.7f, fl);
                    pl(c, false, 4.2f, 17.8f, 9.4f, 12.8f, 13f, 16f, 15.4f, 13.6f, 19.8f, 17.8f);
                    break;
                case I_CLOCK:
                    c.drawCircle(12, 12, 9.2f, st);
                    pl(c, false, 12, 6.8f, 12, 12, 15.6f, 14.2f);
                    break;
                case I_LOCK: {
                    c.drawRoundRect(new RectF(5f, 10.6f, 19f, 20.6f), 2.8f, 2.8f, st);
                    Path pa = new Path();
                    pa.moveTo(8, 10.6f); pa.lineTo(8, 8f);
                    pa.arcTo(new RectF(8, 4f, 16, 12f), 180, 180);
                    pa.lineTo(16, 10.6f);
                    c.drawPath(pa, st);
                    c.drawCircle(12, 15.1f, 1.3f, fl);
                    break;
                }
                case I_STACK: {
                    c.drawOval(new RectF(5, 3.4f, 19, 9.6f), st);
                    Path pa = new Path();
                    pa.moveTo(5, 6.5f); pa.lineTo(5, 17.5f);
                    pa.arcTo(new RectF(5, 14.4f, 19, 20.6f), 180, -180);
                    pa.lineTo(19, 6.5f);
                    c.drawPath(pa, st);
                    Path mid = new Path();
                    mid.moveTo(5, 12f);
                    mid.arcTo(new RectF(5, 8.9f, 19, 15.1f), 180, -180);
                    c.drawPath(mid, st);
                    break;
                }
                case I_WIFI: {
                    float[] rr = {4.6f, 8.8f, 13f};
                    for (float r : rr) c.drawArc(new RectF(12 - r, 19.2f - r, 12 + r, 19.2f + r), 227, 86, false, st);
                    c.drawCircle(12, 19.2f, 1.4f, fl);
                    break;
                }
                case I_CHEV_R: pl(c, false, 9, 5.5f, 15.5f, 12, 9, 18.5f); break;
                case I_CHEV_D: pl(c, false, 5.5f, 9, 12, 15.5f, 18.5f, 9); break;
                case I_BACK: pl(c, false, 14.5f, 5.5f, 8, 12, 14.5f, 18.5f); break;
                default: break;
            }
        }

        @Override public void setAlpha(int alpha) { st.setAlpha(alpha); fl.setAlpha(alpha); }
        @Override public void setColorFilter(ColorFilter cf) { st.setColorFilter(cf); fl.setColorFilter(cf); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
