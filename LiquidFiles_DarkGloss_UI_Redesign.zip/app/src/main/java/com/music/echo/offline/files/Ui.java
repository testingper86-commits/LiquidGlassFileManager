package com.music.echo.offline.files;

import com.music.echo.offline.R;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Shared look & feel helpers: theme colours, glass drawables, small view factories. */
final class Ui {
    static float D = 3f;
    static SharedPreferences sp;
    static int theme = 0, accent = Color.rgb(150, 175, 255), blob1, blob2, blob3;
    static int top = 0, bottom = 0;
    /** Dark-gloss theme accents. All 15 variations share the same obsidian UI language. */
    static int gradA = Color.rgb(146, 92, 255), gradB = Color.rgb(64, 214, 236);
    static final int[] GA = {
        Color.rgb(90, 210, 255), Color.rgb(115, 145, 255), Color.rgb(155, 190, 255),
        Color.rgb(190, 205, 220), Color.rgb(70, 120, 255), Color.rgb(145, 165, 195),
        Color.rgb(135, 150, 180), Color.rgb(170, 190, 220), Color.rgb(105, 125, 155),
        Color.rgb(155, 170, 195), Color.rgb(80, 175, 165), Color.rgb(205, 215, 235),
        Color.rgb(120, 135, 165), Color.rgb(120, 185, 255), Color.rgb(100, 115, 145)
    };
    static final int[] GB = {
        Color.rgb(20, 95, 150), Color.rgb(45, 65, 160), Color.rgb(65, 95, 145),
        Color.rgb(95, 110, 135), Color.rgb(30, 45, 115), Color.rgb(65, 85, 120),
        Color.rgb(50, 65, 95), Color.rgb(70, 95, 135), Color.rgb(35, 50, 80),
        Color.rgb(75, 90, 120), Color.rgb(20, 90, 85), Color.rgb(95, 105, 130),
        Color.rgb(45, 55, 80), Color.rgb(25, 85, 145), Color.rgb(30, 40, 65)
    };
    // Not "final" on purpose: javac only inlines static-final primitives initialized with a
    // constant expression. WHITE (a literal) would be baked into every call site and could
    // never be swapped for a light theme; keeping it a real mutable field means one call to
    // setLight() recolors every screen that reads Ui.WHITE / Ui.SUB, without editing each file.
    static int WHITE = 0xFFFFFFFF;
    static int SUB = Color.argb(175, 225, 230, 244);
    static boolean light = false;
    static int bg = Color.rgb(7, 9, 15);
    static int panelR = 10, panelG = 14, panelB = 26;
    static int hiTop = Color.argb(56, 255, 255, 255), hiBot = Color.argb(6, 255, 255, 255);
    static int edgeStroke = Color.argb(72, 255, 255, 255);
    static final String[] THEMES = {
        "BlackViscosity", "ShadowMelt", "DarkMirror VR", "PitchGloss", "AbyssFluid",
        "JetGlaze", "MidnightGloss", "InkMirror", "SlickDark", "ObsidianCanvas",
        "OnyxFlow", "VantaGlass", "LiquidObsidian", "GlossEngine", "DarkFluid"
    };
    static final int[] DOTS = GA;
    static final SimpleDateFormat DF = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());

    static void init(Context c) {
        D = c.getResources().getDisplayMetrics().density;
        if (sp == null) sp = c.getApplicationContext().getSharedPreferences("lg_settings", Context.MODE_PRIVATE);
        if (!sp.contains("theme_mode")) sp.edit().putInt("theme_mode", sp.contains("light") ? (sp.getBoolean("light", false) ? 0 : 1) : 1).apply(); // new installs default to dark gloss; preserve existing explicit choice
        setLight(wantLight(c), true);
        setTheme(sp.getInt("theme", 0), false);
    }

    static void setLight(boolean l, boolean save) {
        light = l;
        if (save) sp.edit().putBoolean("light", l).apply();
        if (l) {
            WHITE = Color.rgb(18, 20, 26);
            SUB = Color.argb(210, 70, 75, 90);
            bg = Color.rgb(236, 238, 244);
            panelR = 255; panelG = 255; panelB = 255;
            hiTop = Color.argb(150, 255, 255, 255); hiBot = Color.argb(10, 255, 255, 255);
            edgeStroke = Color.argb(50, 20, 22, 30);
        } else {
            WHITE = 0xFFFFFFFF;
            SUB = Color.argb(175, 225, 230, 244);
            bg = Color.rgb(7, 9, 15);
            panelR = 10; panelG = 14; panelB = 26;
            hiTop = Color.argb(56, 255, 255, 255); hiBot = Color.argb(6, 255, 255, 255);
            edgeStroke = Color.argb(72, 255, 255, 255);
        }
    }

    static int dp(float v) { return Math.round(v * D); }

    /** 0 = Light, 1 = Dark, 2 = System. Older installs only stored the "light" flag. */
    static int themeMode(Context c) {
        SharedPreferences p = c.getApplicationContext().getSharedPreferences("lg_settings", Context.MODE_PRIVATE);
        if (p.contains("theme_mode")) return p.getInt("theme_mode", 2);
        if (p.contains("light")) return p.getBoolean("light", false) ? 0 : 1;
        return 2;
    }

    /** Resolves the saved mode (including "System") to a concrete light/dark choice. */
    static boolean wantLight(Context c) {
        int m = themeMode(c);
        if (m == 0) return true;
        if (m == 1) return false;
        int night = c.getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return night != android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    static void setTheme(int t, boolean save) {
        theme = Math.max(0, Math.min(THEMES.length - 1, t));
        gradA = GA[theme];
        gradB = GB[theme];
        if (save) sp.edit().putInt("theme", theme).apply();
        accent = gradA;
        // Controlled colored bloom over an otherwise consistently black, mirror-gloss UI.
        blob1 = Color.argb(105, Color.red(gradA), Color.green(gradA), Color.blue(gradA));
        blob2 = Color.argb(78, Color.red(gradB), Color.green(gradB), Color.blue(gradB));
        blob3 = Color.argb(46, Color.red(gradA), Color.green(gradA), Color.blue(gradA));
    }

    static boolean bool(String k, boolean d) { return sp.getBoolean(k, d); }
    static void set(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }

    /**
     * Layered Liquid Glass panel: readable tinted body, subtle colour bloom, top specular
     * highlight and a fine rim. This is a translucent layered drawable, not a backdrop blur.
     */
    static Drawable glass(float radiusDp, boolean strong) {
        float rad = dp(radiusDp);
        // Stronger "hard glass" treatment: a deeper smoked body, saturated edge bloom,
        // crisp specular highlight and two fine rims. This is a drawable-only effect and
        // intentionally does not pretend to be a real-time backdrop blur.
        int bodyAlpha = strong ? (light ? 224 : 218) : (light ? 194 : 190);
        GradientDrawable base = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{
                        Color.argb(Math.min(250, bodyAlpha + 34), panelR, panelG, panelB),
                        Color.argb(bodyAlpha, panelR, panelG, panelB),
                        Color.argb(Math.max(38, bodyAlpha - 38), panelR, panelG, panelB)
                });
        base.setCornerRadius(rad);

        GradientDrawable bloom = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{
                        Color.argb(light ? 48 : 86, Color.red(accent), Color.green(accent), Color.blue(accent)),
                        Color.argb(light ? 16 : 38, Color.red(blob2), Color.green(blob2), Color.blue(blob2)),
                        Color.argb(0, 255, 255, 255)
                });
        bloom.setCornerRadius(rad);

        GradientDrawable hi = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{
                        Color.argb(light ? 158 : 178, 255, 255, 255),
                        Color.argb(light ? 48 : 58, 255, 255, 255),
                        Color.argb(0, 255, 255, 255)
                });
        hi.setCornerRadius(rad);

        GradientDrawable innerRim = new GradientDrawable();
        innerRim.setColor(Color.TRANSPARENT);
        innerRim.setCornerRadius(Math.max(0, rad - dp(2)));
        innerRim.setStroke(Math.max(1, dp(0.7f)), Color.argb(light ? 82 : 76, 255, 255, 255));

        GradientDrawable edge = new GradientDrawable();
        edge.setColor(Color.TRANSPARENT);
        edge.setCornerRadius(rad);
        int edgeAlpha = strong ? (light ? 205 : 205) : (light ? 160 : 160);
        edge.setStroke(Math.max(1, dp(strong ? 1.15f : 0.9f)),
                Color.argb(edgeAlpha, Color.red(edgeStroke), Color.green(edgeStroke), Color.blue(edgeStroke)));

        return new LayerDrawable(new Drawable[]{base, bloom, hi, innerRim, edge});
    }

    static Drawable accentPill(float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(105, Color.red(accent), Color.green(accent), Color.blue(accent)));
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(Math.max(1, dp(1)), Color.argb(130, 255, 255, 255));
        return g;
    }

    static TextView tv(Context c, CharSequence t, float sp, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        v.setIncludeFontPadding(false);
        return v;
    }

    static ImageView iconBtn(Context c, int glyph, int color) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(Glyphs.get(glyph, color));
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        v.setBackground(glass(16, true));
        v.setElevation(dp(3));
        v.setClickable(true);
        v.setFocusable(true);
        press(v);
        return v;
    }

    /** Springy "liquid" press feedback; never consumes the touch so clicks still work. */
    static void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(new OvershootInterpolator(2.2f)).start();
            return false;
        });
    }

    static void round(View v, final float rDp) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline o) {
                o.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(rDp));
            }
        });
        v.setClipToOutline(true);
    }

    static void tick(View v) {
        if (bool("haptic", true)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    static void toast(Context c, String m) { Toast.makeText(c, m, Toast.LENGTH_SHORT).show(); }

    static String size(long n) {
        if (n < 1024) return n + " B";
        if (n < 1048576L) return (n / 1024) + " KB";
        if (n < 1073741824L) return String.format(Locale.US, "%.1f MB", n / 1048576.0);
        return String.format(Locale.US, "%.2f GB", n / 1073741824.0);
    }

    static String date(long t) { return DF.format(new Date(t)); }
}
