# Liquid Glass Files

Offline Android file manager (plain Java) with a Liquid Glass UI, built-in
image / video / music / PDF / text viewer, Recycle Bin, encrypted Vault, App Lock, duplicate finder,
storage analysis and local Wi-Fi transfer.

## Build
- **Android Studio** (Ladybug or newer, JDK 17): open this folder, let it sync, run the `app` module.
- **GitHub Actions**: push the contents of this folder to a repository. `.github/workflows/build.yml`
  builds `assembleDebug` and uploads `LiquidGlassFileManager-debug-apk` (Actions tab → run → Artifacts).
- **Command line** (JDK 17): `./gradlew assembleDebug` → `app/build/outputs/apk/debug/`.

Requires Android 8.0+ (API 26). On first launch grant "All files access" so the app can browse storage.
The debug build installs next to a release build as `com.music.echo.offline.debug`.

## Third-party
- [Liquid-Glass-Android](https://github.com/QWEA0/Liquid-Glass-Android) (MIT) via JitPack: real backdrop blur, refraction and dispersion on the bottom dock. The first build needs internet to download it; see `THIRD_PARTY_NOTICES.md`.
- Heroicons assets (MIT).

## Layout
`app/src/main/java/com/music/echo/offline/files/`
- `MainActivity` home grid, settings categories, overlays · `BrowserView` file lists
- `ViewerActivity` built-in viewer and the music / video players
- `Ui`, `Glyphs`, `Rows` look and feel · `FileOps`, `RecycleBin`, `Vault`, `AppLock`, `LanTransfer`, `Indexer`, `DupFinder`

## Permissions
All-files access (browsing and file operations), install packages (open APKs), INTERNET (only the optional
local Wi-Fi transfer), WAKE_LOCK and MODIFY_AUDIO_SETTINGS (music playback with the screen off, equalizer).

## Known limits
- Music keeps playing while the app is in the background, but there is no notification or lock-screen control
  (no foreground service). Android can stop it under memory pressure.
- Only the bottom dock uses the real refracting glass view. Home tiles, settings rows and the players use a layered
  translucent drawable, which does not blur what is behind it. The refraction effect needs Android 13+; older versions
  fall back to blur only.
- ZIP is the only archive format that can be extracted.
