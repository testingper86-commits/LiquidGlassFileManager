# No custom rules required: the app is plain Java with no reflection.
