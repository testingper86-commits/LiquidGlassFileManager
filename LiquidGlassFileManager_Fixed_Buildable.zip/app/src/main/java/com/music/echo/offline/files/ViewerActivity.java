package com.music.echo.offline.files;

import com.music.echo.offline.R;

import android.app.Activity;
import com.example.liquidglass.GlassMaterial;
import com.example.liquidglass.LiquidGlassView;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfRenderer;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.ExifInterface;
import android.media.audiofx.Equalizer;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.util.LruCache;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.VideoView;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Built-in viewer: images (pinch zoom), video, audio, PDF and text. Works without any other app installed. */
public class ViewerActivity extends Activity {
    ArrayList<String> paths;
    int idx;
    FrameLayout root, stage;
    TextView titleTv, counterTv;
    ImageView prevBtn, nextBtn;
    LinearLayout bar;
    final ExecutorService io = Executors.newSingleThreadExecutor();
    final Handler h = new Handler(Looper.getMainLooper());
    MediaPlayer mp;
    MediaPlayer videoPlayer;
    VideoView vv;
    PdfRenderer pdf;
    ParcelFileDescriptor pfd;
    Runnable ticker;
    boolean destroyed;
    boolean audioShuffle = false, videoLoop = false, mpReady, userSeeking, resumeAfterFocus;
    int repeatMode = 0, lrcLine = -1, audioSession = 0;
    float videoSpeed = 1.0f, audioSpeed = 1.0f;
    String curVideoKey;
    ImageView audioPlayBtn;
    TextView sleepPill;
    Runnable sleepTask;
    Equalizer eq;
    Lrc lrc;
    AudioManager audio;
    AudioFocusRequest focusReq;
    final Random random = new Random();
    int topInset, bottomInset;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        Ui.setLight(false, false);
        paths = getIntent().getStringArrayListExtra("paths");
        idx = getIntent().getIntExtra("index", 0);
        if (paths == null || paths.isEmpty()) { finish(); return; }
        if (idx < 0 || idx >= paths.size()) idx = 0;
        audioShuffle = getIntent().getBooleanExtra("shuffle", false);
        registerReceiver(noisyReceiver, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF05070C);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        else root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        stage = new FrameLayout(this);
        root.addView(stage, new FrameLayout.LayoutParams(-1, -1));

        bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(Ui.glass(26, true));
        bar.setPadding(Ui.dp(4), 0, Ui.dp(4), 0);
        ImageView back = Ui.iconBtn(this, Glyphs.BACK, Ui.WHITE);
        back.setOnClickListener(v -> finish());
        titleTv = Ui.tv(this, "", 15, Ui.WHITE, true);
        titleTv.setSingleLine(true);
        titleTv.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        counterTv = Ui.tv(this, "", 12, Ui.SUB, false);
        ImageView open = Ui.iconBtn(this, Glyphs.OPEN, Ui.WHITE);
        open.setOnClickListener(v -> FileOps.external(this, new File(paths.get(idx)), true));
        ImageView share = Ui.iconBtn(this, Glyphs.SHARE, Ui.WHITE);
        share.setOnClickListener(v -> { ArrayList<File> l = new ArrayList<>(); l.add(new File(paths.get(idx))); FileOps.share(this, l); });
        bar.addView(back, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        bar.addView(titleTv, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.rightMargin = Ui.dp(6);
        bar.addView(counterTv, cl);
        bar.addView(open, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        bar.addView(share, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, Ui.dp(52), Gravity.TOP);
        bp.setMargins(Ui.dp(12), Ui.dp(8), Ui.dp(12), 0);
        root.addView(bar, bp);

        prevBtn = edge(Glyphs.BACK, Gravity.START | Gravity.CENTER_VERTICAL, -1);
        nextBtn = edge(Glyphs.NEXT, Gravity.END | Gravity.CENTER_VERTICAL, 1);

        setContentView(root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets in = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                topInset = in.top; bottomInset = in.bottom;
            } else { topInset = insets.getSystemWindowInsetTop(); bottomInset = insets.getSystemWindowInsetBottom(); }
            FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) bar.getLayoutParams();
            if (p.topMargin != topInset + Ui.dp(8)) { p.topMargin = topInset + Ui.dp(8); bar.setLayoutParams(p); }
            return insets;
        });
        root.requestApplyInsets();
        show();
    }

    ImageView edge(int glyph, int gravity, final int delta) {
        ImageView v = new ImageView(this);
        v.setImageDrawable(Glyphs.get(glyph, Ui.WHITE));
        v.setBackground(Ui.glass(24, true));
        v.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10));
        v.setOnClickListener(x -> go(delta));
        Ui.press(v);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(Ui.dp(46), Ui.dp(46), gravity);
        p.setMargins(Ui.dp(10), 0, Ui.dp(10), 0);
        root.addView(v, p);
        return v;
    }

    void go(int d) {
        int n = idx + d;
        if (n < 0 || n >= paths.size()) return;
        idx = n;
        show();
    }

    void cleanup() {
        if (ticker != null) { h.removeCallbacks(ticker); ticker = null; }
        mpReady = false;
        userSeeking = false;
        audioPlayBtn = null;
        lrc = null;
        lrcLine = -1;
        if (mp != null) { try { mp.release(); } catch (Exception ignored) { } mp = null; }
        saveVideoPos();
        if (vv != null) { try { vv.stopPlayback(); } catch (Exception ignored) { } vv = null; videoPlayer = null; }
        curVideoKey = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (pdf != null) {
            final PdfRenderer r = pdf;
            final ParcelFileDescriptor f = pfd;
            io.execute(() -> { try { r.close(); } catch (Exception ignored) { } try { if (f != null) f.close(); } catch (Exception ignored) { } });
            pdf = null; pfd = null;
        }
        if (stage != null) stage.removeAllViews();
    }

    void show() {
        cleanup();
        File f = new File(paths.get(idx));
        Entry e = new Entry(f);
        titleTv.setText(f.getName());
        counterTv.setText(paths.size() > 1 ? (idx + 1) + "/" + paths.size() : "");
        boolean multi = paths.size() > 1 && (e.kind == FileKinds.IMAGE || e.kind == FileKinds.VIDEO);
        prevBtn.setVisibility(multi && idx > 0 ? View.VISIBLE : View.GONE);
        nextBtn.setVisibility(multi && idx < paths.size() - 1 ? View.VISIBLE : View.GONE);
        switch (e.kind) {
            case FileKinds.IMAGE: showImage(f); break;
            case FileKinds.VIDEO: showVideo(f); break;
            case FileKinds.AUDIO: showAudio(f, e); break;
            case FileKinds.PDF: showPdf(f); break;
            default: showText(f);
        }
        bar.bringToFront();
        prevBtn.bringToFront();
        nextBtn.bringToFront();
    }

    // ---------------- image ----------------
    void showImage(final File f) {
        final ZoomImage z = new ZoomImage(this);
        stage.addView(z, new FrameLayout.LayoutParams(-1, -1));
        final int my = idx;
        io.execute(() -> {
            final Bitmap bm = decode(f, 2600);
            h.post(() -> {
                if (destroyed || my != idx) return;
                if (bm == null) Ui.toast(this, "Can't display this image");
                else z.setImageBitmap(bm);
            });
        });
    }

    static Bitmap decode(File f, int max) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / s > max) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            if (b == null) return null;
            int rot = 0;
            try {
                int ori = new ExifInterface(f.getAbsolutePath()).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (ori == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
            } catch (Exception ignored) { }
            if (rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            }
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    static final class ZoomImage extends ImageView {
        final Matrix m = new Matrix();
        final ScaleGestureDetector sg;
        final GestureDetector gd;
        float minS = 1f;

        ZoomImage(android.content.Context c) {
            super(c);
            setScaleType(ScaleType.MATRIX);
            sg = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector d) {
                    float cur = scale();
                    float ns = Math.max(minS, Math.min(cur * d.getScaleFactor(), minS * 8f));
                    float f = ns / cur;
                    m.postScale(f, f, d.getFocusX(), d.getFocusY());
                    fix();
                    setImageMatrix(m);
                    return true;
                }
            });
            gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }
                @Override public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                    m.postTranslate(-dx, -dy);
                    fix();
                    setImageMatrix(m);
                    return true;
                }
                @Override public boolean onDoubleTap(MotionEvent e) {
                    float cur = scale();
                    float target = cur > minS * 1.5f ? minS : minS * 3f;
                    float f = target / cur;
                    m.postScale(f, f, e.getX(), e.getY());
                    fix();
                    setImageMatrix(m);
                    return true;
                }
            });
        }

        float scale() { float[] v = new float[9]; m.getValues(v); return v[Matrix.MSCALE_X]; }

        void fit() {
            Drawable d = getDrawable();
            if (d == null || getWidth() == 0) return;
            float dw = d.getIntrinsicWidth(), dh = d.getIntrinsicHeight();
            float s = Math.min(getWidth() / dw, getHeight() / dh);
            minS = s;
            m.reset();
            m.postScale(s, s);
            m.postTranslate((getWidth() - dw * s) / 2f, (getHeight() - dh * s) / 2f);
            setImageMatrix(m);
        }

        void fix() {
            Drawable d = getDrawable();
            if (d == null) return;
            RectF r = new RectF(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
            m.mapRect(r);
            float dx = 0, dy = 0;
            if (r.width() <= getWidth()) dx = (getWidth() - r.width()) / 2f - r.left;
            else if (r.left > 0) dx = -r.left;
            else if (r.right < getWidth()) dx = getWidth() - r.right;
            if (r.height() <= getHeight()) dy = (getHeight() - r.height()) / 2f - r.top;
            else if (r.top > 0) dy = -r.top;
            else if (r.bottom < getHeight()) dy = getHeight() - r.bottom;
            m.postTranslate(dx, dy);
        }

        @Override protected void onSizeChanged(int w, int h, int ow, int oh) { super.onSizeChanged(w, h, ow, oh); fit(); }

        @Override public void setImageBitmap(Bitmap b) { super.setImageBitmap(b); fit(); }

        @Override public boolean onTouchEvent(MotionEvent e) {
            sg.onTouchEvent(e);
            if (!sg.isInProgress()) gd.onTouchEvent(e);
            return true;
        }
    }

    // ---------------- shared playback helpers ----------------
    static final String RESUME_PREFS = "lg_resume";

    final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        if (change == AudioManager.AUDIOFOCUS_LOSS) {
            resumeAfterFocus = false;
            pauseMedia();
        } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK) {
            if (playingNow()) { resumeAfterFocus = true; pauseMedia(); }
        } else if (change == AudioManager.AUDIOFOCUS_GAIN) {
            if (resumeAfterFocus) { resumeAfterFocus = false; resumeMedia(); }
        }
    };

    final BroadcastReceiver noisyReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { pauseMedia(); }
    };

    void requestAudioFocus() {
        if (audio == null) audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audio == null) return;
        if (focusReq == null) {
            focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setOnAudioFocusChangeListener(focusListener).build();
        }
        try { audio.requestAudioFocus(focusReq); } catch (Exception ignored) { }
    }

    void abandonAudioFocus() {
        try { if (audio != null && focusReq != null) audio.abandonAudioFocusRequest(focusReq); } catch (Exception ignored) { }
    }

    boolean playingNow() {
        try { if (mp != null && mpReady && mp.isPlaying()) return true; } catch (Exception ignored) { }
        try { if (vv != null && vv.isPlaying()) return true; } catch (Exception ignored) { }
        return false;
    }

    void pauseMedia() {
        try { if (mp != null && mpReady && mp.isPlaying()) mp.pause(); } catch (Exception ignored) { }
        try { if (vv != null && vv.isPlaying()) vv.pause(); } catch (Exception ignored) { }
        if (audioPlayBtn != null) audioPlayBtn.setImageDrawable(Glyphs.get(Glyphs.PLAY, Ui.WHITE));
    }

    void resumeMedia() {
        try { if (mp != null && mpReady && !mp.isPlaying()) { mp.start(); applyAudioSpeed(); } } catch (Exception ignored) { }
        try { if (vv != null && !vv.isPlaying()) vv.start(); } catch (Exception ignored) { }
        if (audioPlayBtn != null && mp != null) audioPlayBtn.setImageDrawable(Glyphs.get(Glyphs.PAUSE, Ui.WHITE));
    }

    TextView pill(String label) {
        TextView t = Ui.tv(this, label, 12.5f, Ui.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.accentPill(18));
        t.setPadding(Ui.dp(12), Ui.dp(8), Ui.dp(12), Ui.dp(8));
        Ui.press(t);
        return t;
    }

    LinearLayout.LayoutParams pillLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(4));
        return p;
    }

    static String speedLabel(float s) {
        return (s == (int) s ? String.valueOf((int) s) : String.valueOf(s)) + "×";
    }

    static float nextSpeed(float s) {
        if (s == 1.0f) return 1.25f;
        if (s == 1.25f) return 1.5f;
        if (s == 1.5f) return 2.0f;
        if (s == 2.0f) return 0.75f;
        return 1.0f;
    }

    // ---------------- video ----------------
    void saveVideoPos() {
        if (vv == null || curVideoKey == null || !Ui.bool("resume_video", true)) return;
        try {
            int pos = vv.getCurrentPosition(), dur = vv.getDuration();
            SharedPreferences.Editor ed = getSharedPreferences(RESUME_PREFS, MODE_PRIVATE).edit();
            if (pos > 3000 && dur > 0 && pos < dur - 5000) ed.putInt(curVideoKey, pos); else ed.remove(curVideoKey);
            ed.apply();
        } catch (Exception ignored) { }
    }

    void applyVideoSpeed() {
        if (videoPlayer == null || vv == null) return;
        try {
            boolean was = vv.isPlaying();
            videoPlayer.setPlaybackParams(new PlaybackParams().setSpeed(videoSpeed));
            if (!was) vv.pause();
        } catch (Exception ex) { Ui.toast(this, "This device can't change speed for this video"); }
    }

    void showVideo(final File f) {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        curVideoKey = f.getAbsolutePath();
        vv = new VideoView(this);
        stage.addView(vv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        MediaController mc = new MediaController(this);
        mc.setAnchorView(vv);
        vv.setMediaController(mc);
        requestAudioFocus();
        vv.setOnPreparedListener(m -> {
            videoPlayer = m;
            try { m.setLooping(videoLoop); } catch (Exception ignored) { }
            int saved = Ui.bool("resume_video", true) ? getSharedPreferences(RESUME_PREFS, MODE_PRIVATE).getInt(curVideoKey, 0) : 0;
            int dur = m.getDuration();
            if (saved > 3000 && dur > 0 && saved < dur - 5000) {
                vv.seekTo(saved);
                Ui.toast(this, "Resumed at " + fmt(saved));
            }
            vv.start();
            if (videoSpeed != 1.0f) applyVideoSpeed();
        });
        vv.setOnCompletionListener(m -> {
            getSharedPreferences(RESUME_PREFS, MODE_PRIVATE).edit().remove(curVideoKey).apply();
            if (idx < paths.size() - 1) go(1);
        });
        vv.setOnErrorListener((m, w, x) -> { Ui.toast(this, "This video can't be played here — try \"Open with\""); return true; });
        vv.setVideoPath(f.getAbsolutePath());

        LinearLayout tools = new LinearLayout(this);
        tools.setGravity(Gravity.CENTER);
        tools.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4));
        tools.setBackground(Ui.glass(24, true));
        TextView back10 = pill("−10s");
        back10.setOnClickListener(v -> { if (vv != null) vv.seekTo(Math.max(0, vv.getCurrentPosition() - 10000)); });
        TextView fwd10 = pill("+10s");
        fwd10.setOnClickListener(v -> { if (vv != null) vv.seekTo(Math.min(Math.max(0, vv.getDuration() - 500), vv.getCurrentPosition() + 10000)); });
        final TextView speed = pill("Speed " + speedLabel(videoSpeed));
        speed.setOnClickListener(v -> {
            videoSpeed = nextSpeed(videoSpeed);
            speed.setText("Speed " + speedLabel(videoSpeed));
            applyVideoSpeed();
        });
        final TextView loop = pill(videoLoop ? "Loop on" : "Loop off");
        loop.setOnClickListener(v -> {
            videoLoop = !videoLoop;
            loop.setText(videoLoop ? "Loop on" : "Loop off");
            try { if (videoPlayer != null) videoPlayer.setLooping(videoLoop); } catch (Exception ignored) { }
        });
        tools.addView(back10, pillLp());
        tools.addView(fwd10, pillLp());
        tools.addView(speed, pillLp());
        tools.addView(loop, pillLp());
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        tp.bottomMargin = bottomInset + Ui.dp(96);
        stage.addView(tools, tp);
    }

    // ---------------- audio ----------------
    static final class Lrc {
        long[] t = new long[0];
        String[] s = new String[0];
    }

    static Long lrcStamp(String tag) {
        try {
            int c = tag.indexOf(':');
            if (c <= 0) return null;
            long m = Long.parseLong(tag.substring(0, c).trim());
            double sec = Double.parseDouble(tag.substring(c + 1).trim());
            return (long) (m * 60000L + sec * 1000);
        } catch (Exception ex) { return null; }
    }

    /** Reads "Song.lrc" next to "Song.mp3" (synced lyrics). Returns empty lyrics when absent or unreadable. */
    static Lrc readLrc(File audio) {
        Lrc out = new Lrc();
        try {
            String n = audio.getName();
            int d = n.lastIndexOf('.');
            File l = new File(audio.getParentFile(), (d > 0 ? n.substring(0, d) : n) + ".lrc");
            if (!l.isFile() || l.length() > 512 * 1024) return out;
            ArrayList<Long> ts = new ArrayList<>();
            ArrayList<String> ls = new ArrayList<>();
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(l), "UTF-8"));
            try {
                String line;
                while ((line = br.readLine()) != null) {
                    String rest = line.trim();
                    ArrayList<Long> stamps = new ArrayList<>();
                    while (rest.startsWith("[")) {
                        int close = rest.indexOf(']');
                        if (close < 0) break;
                        Long ms = lrcStamp(rest.substring(1, close));
                        rest = rest.substring(close + 1);
                        if (ms != null) stamps.add(ms);
                    }
                    String text = rest.trim();
                    for (Long ms : stamps) { ts.add(ms); ls.add(text); }
                }
            } finally { try { br.close(); } catch (Exception ignored) { } }
            final ArrayList<Long> fts = ts;
            Integer[] order = new Integer[ts.size()];
            for (int i = 0; i < order.length; i++) order[i] = i;
            java.util.Arrays.sort(order, (a, b) -> Long.compare(fts.get(a), fts.get(b)));
            out.t = new long[order.length];
            out.s = new String[order.length];
            for (int i = 0; i < order.length; i++) { out.t[i] = ts.get(order[i]); out.s[i] = ls.get(order[i]); }
        } catch (Exception ignored) { }
        return out;
    }

    void applyAudioSpeed() {
        if (mp == null || !mpReady) return;
        try {
            boolean was = mp.isPlaying();
            mp.setPlaybackParams(new PlaybackParams().setSpeed(audioSpeed));
            if (!was) mp.pause();
        } catch (Exception ex) { Ui.toast(this, "This device can't change speed for this track"); }
    }

    int randomOther() {
        if (paths.size() < 2) return idx;
        int n = idx;
        while (n == idx) n = random.nextInt(paths.size());
        return n;
    }

    void nextAudio() {
        if (audioShuffle && paths.size() > 1) { idx = randomOther(); show(); }
        else if (idx < paths.size() - 1) { idx++; show(); }
        else if (repeatMode == 1 && paths.size() > 1) { idx = 0; show(); }
        else Ui.toast(this, "End of the list");
    }

    void prevAudio() {
        try { if (mp != null && mpReady && mp.getCurrentPosition() > 3000) { mp.seekTo(0); return; } } catch (Exception ignored) { }
        if (audioShuffle && paths.size() > 1) { idx = randomOther(); show(); }
        else if (idx > 0) { idx--; show(); }
        else if (repeatMode == 1 && paths.size() > 1) { idx = paths.size() - 1; show(); }
        else { try { if (mp != null && mpReady) mp.seekTo(0); } catch (Exception ignored) { } }
    }

    static String baseName(String path) {
        String n = new File(path).getName();
        int d = n.lastIndexOf('.');
        return d > 0 ? n.substring(0, d) : n;
    }

    void showQueue() {
        String[] names = new String[paths.size()];
        for (int i = 0; i < names.length; i++) names[i] = baseName(paths.get(i));
        new AlertDialog.Builder(this).setTitle("Queue • " + names.length + " tracks")
                .setSingleChoiceItems(names, idx, (d, which) -> { d.dismiss(); if (which != idx) { idx = which; show(); } })
                .setNegativeButton("Close", null).show();
    }

    void setSleep(int minutes) {
        if (sleepTask != null) { h.removeCallbacks(sleepTask); sleepTask = null; }
        if (minutes <= 0) { if (sleepPill != null) sleepPill.setText("Sleep off"); return; }
        sleepTask = () -> { sleepTask = null; pauseMedia(); if (sleepPill != null) sleepPill.setText("Sleep off"); Ui.toast(this, "Sleep timer: paused"); };
        h.postDelayed(sleepTask, minutes * 60000L);
        if (sleepPill != null) sleepPill.setText("Sleep " + minutes + "m");
    }

    void showSleepDialog() {
        final int[] mins = {0, 15, 30, 45, 60};
        String[] labels = {"Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes"};
        new AlertDialog.Builder(this).setTitle("Sleep timer")
                .setItems(labels, (d, which) -> setSleep(mins[which])).show();
    }

    void ensureEq() {
        if (eq != null || audioSession == 0) return;
        try {
            eq = new Equalizer(0, audioSession);
            String saved = Ui.sp.getString("eq_levels", "");
            String[] parts = saved.isEmpty() ? new String[0] : saved.split(",");
            short[] range = eq.getBandLevelRange();
            for (short b = 0; b < eq.getNumberOfBands() && b < parts.length; b++) {
                int lv = Integer.parseInt(parts[b]);
                eq.setBandLevel(b, (short) Math.max(range[0], Math.min(range[1], lv)));
            }
            eq.setEnabled(Ui.bool("eq_on", false));
        } catch (Throwable t) {
            try { if (eq != null) eq.release(); } catch (Throwable ignored) { }
            eq = null;
        }
    }

    void showEqualizer() {
        ensureEq();
        if (eq == null) { Ui.toast(this, "Equalizer isn't available on this device"); return; }
        final Equalizer q = eq;
        final short[] range = q.getBandLevelRange();
        final short bands = q.getNumberOfBands();
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        Switch on = new Switch(this);
        on.setText("Equalizer");
        on.setChecked(Ui.bool("eq_on", false));
        on.setOnCheckedChangeListener((b, c) -> { Ui.set("eq_on", c); try { q.setEnabled(c); } catch (Throwable ignored) { } });
        col.addView(on);
        for (short b = 0; b < bands; b++) {
            final short band = b;
            int hz = q.getCenterFreq(b) / 1000;
            TextView lab = new TextView(this);
            lab.setText(hz >= 1000 ? (hz / 1000) + " kHz" : hz + " Hz");
            lab.setPadding(0, Ui.dp(10), 0, 0);
            col.addView(lab);
            SeekBar s = new SeekBar(this);
            s.setMax(range[1] - range[0]);
            s.setProgress(q.getBandLevel(b) - range[0]);
            s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar sb, int p, boolean user) {
                    if (user) { try { q.setBandLevel(band, (short) (p + range[0])); } catch (Throwable ignored) { } }
                }
                @Override public void onStartTrackingTouch(SeekBar sb) { }
                @Override public void onStopTrackingTouch(SeekBar sb) { }
            });
            col.addView(s);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        new AlertDialog.Builder(this).setTitle("Equalizer").setView(sv)
                .setPositiveButton("Done", null)
                .setOnDismissListener(d -> {
                    StringBuilder sb = new StringBuilder();
                    try { for (short b = 0; b < bands; b++) { if (b > 0) sb.append(','); sb.append(q.getBandLevel(b)); } } catch (Throwable ignored) { }
                    Ui.sp.edit().putString("eq_levels", sb.toString()).apply();
                }).show();
    }

    void showAudio(final File f, final Entry e) {
        final ImageView backArt = new ImageView(this);
        backArt.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backArt.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                new int[]{Glyphs.mix(Ui.accent, Color.BLACK, 0.35f), Color.rgb(8, 10, 18), Glyphs.mix(Ui.accent, Color.BLACK, 0.6f)}));
        stage.addView(backArt, new FrameLayout.LayoutParams(-1, -1));
        final LiquidGlassView glass = new LiquidGlassView(this);
        glass.setCornerRadius(Ui.dp(30));
        glass.setMaterial(GlassMaterial.REGULAR);
        glass.setRefractionHeight(Ui.dp(14));
        glass.setBevelWidth(Ui.dp(22));
        glass.setDispersionStrength(0.08f);
        glass.setGlassTint(Color.BLACK, 0.25f);
        glass.setEnablePressEffect(false);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(Ui.dp(20), Ui.dp(24), Ui.dp(20), Ui.dp(18));
        final ImageView art = new ImageView(this);
        art.setImageDrawable(Glyphs.tile(FileKinds.AUDIO));
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        Ui.round(art, 28);
        card.addView(art, new LinearLayout.LayoutParams(Ui.dp(170), Ui.dp(170)));
        final TextView nm = Ui.tv(this, baseName(f.getAbsolutePath()), 18, Ui.WHITE, true);
        nm.setGravity(Gravity.CENTER);
        nm.setPadding(0, Ui.dp(16), 0, 0);
        card.addView(nm, new LinearLayout.LayoutParams(-1, -2));
        final TextView meta = Ui.tv(this, "", 13, Ui.SUB, false);
        meta.setGravity(Gravity.CENTER);
        meta.setPadding(0, Ui.dp(6), 0, Ui.dp(6));
        card.addView(meta, new LinearLayout.LayoutParams(-1, -2));
        final TextView lyric = Ui.tv(this, "", 15, Ui.accent, true);
        lyric.setGravity(Gravity.CENTER);
        lyric.setMaxLines(2);
        lyric.setVisibility(View.GONE);
        lyric.setPadding(0, 0, 0, Ui.dp(6));
        card.addView(lyric, new LinearLayout.LayoutParams(-1, -2));
        final SeekBar sb = new SeekBar(this);
        sb.getProgressDrawable().setTint(Ui.accent);
        sb.getThumb().setTint(Ui.accent);
        card.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        final TextView time = Ui.tv(this, "0:00 / 0:00", 12, Ui.SUB, false);
        time.setGravity(Gravity.CENTER);
        card.addView(time, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout ctl = new LinearLayout(this);
        ctl.setGravity(Gravity.CENTER);
        ImageView pv = Ui.iconBtn(this, Glyphs.BACK, Ui.WHITE);
        final ImageView pp = Ui.iconBtn(this, Glyphs.PAUSE, Ui.WHITE);
        audioPlayBtn = pp;
        ImageView nx = Ui.iconBtn(this, Glyphs.NEXT, Ui.WHITE);
        pp.setBackground(Ui.accentPill(30));
        pv.setContentDescription("Previous track");
        nx.setContentDescription("Next track");
        pp.setContentDescription("Play or pause");
        pv.setOnClickListener(v -> prevAudio());
        nx.setOnClickListener(v -> nextAudio());
        ctl.addView(pv, new LinearLayout.LayoutParams(Ui.dp(52), Ui.dp(52)));
        LinearLayout.LayoutParams ppl = new LinearLayout.LayoutParams(Ui.dp(64), Ui.dp(64));
        ppl.setMargins(Ui.dp(18), 0, Ui.dp(18), 0);
        ctl.addView(pp, ppl);
        ctl.addView(nx, new LinearLayout.LayoutParams(Ui.dp(52), Ui.dp(52)));
        LinearLayout.LayoutParams cll = new LinearLayout.LayoutParams(-1, -2);
        cll.topMargin = Ui.dp(8);
        card.addView(ctl, cll);

        LinearLayout row1 = new LinearLayout(this);
        row1.setGravity(Gravity.CENTER);
        final TextView shuf = pill(audioShuffle ? "Shuffle on" : "Shuffle off");
        shuf.setOnClickListener(v -> { audioShuffle = !audioShuffle; shuf.setText(audioShuffle ? "Shuffle on" : "Shuffle off"); });
        final TextView rep = pill(repeatMode == 0 ? "Repeat off" : repeatMode == 1 ? "Repeat all" : "Repeat one");
        rep.setOnClickListener(v -> {
            repeatMode = (repeatMode + 1) % 3;
            rep.setText(repeatMode == 0 ? "Repeat off" : repeatMode == 1 ? "Repeat all" : "Repeat one");
        });
        final TextView spd = pill("Speed " + speedLabel(audioSpeed));
        spd.setOnClickListener(v -> { audioSpeed = nextSpeed(audioSpeed); spd.setText("Speed " + speedLabel(audioSpeed)); applyAudioSpeed(); });
        row1.addView(shuf, pillLp());
        row1.addView(rep, pillLp());
        row1.addView(spd, pillLp());
        card.addView(row1, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row2 = new LinearLayout(this);
        row2.setGravity(Gravity.CENTER);
        TextView que = pill("Queue");
        que.setOnClickListener(v -> showQueue());
        TextView eqp = pill("Equalizer");
        eqp.setOnClickListener(v -> showEqualizer());
        sleepPill = pill(sleepTask != null ? "Sleep on" : "Sleep off");
        sleepPill.setOnClickListener(v -> showSleepDialog());
        row2.addView(que, pillLp());
        row2.addView(eqp, pillLp());
        row2.addView(sleepPill, pillLp());
        card.addView(row2, new LinearLayout.LayoutParams(-1, -2));

        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        fp.setMargins(Ui.dp(18), Ui.dp(40), Ui.dp(18), 0);
        glass.addView(card, new FrameLayout.LayoutParams(-1, -2));
        stage.addView(glass, fp);

        final int my = idx;
        lrc = new Lrc();
        io.execute(() -> {
            String info = "", title = null;
            Bitmap cover = null;
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(f.getAbsolutePath());
                String ar = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                String al = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM);
                title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                info = (ar != null ? ar : "") + (ar != null && al != null ? " • " : "") + (al != null ? al : "");
                byte[] pic = r.getEmbeddedPicture();
                if (pic != null) cover = BitmapFactory.decodeByteArray(pic, 0, pic.length);
            } catch (Throwable ignored) { } finally { try { r.release(); } catch (Throwable ignored) { } }
            final Lrc lyrics = readLrc(f);
            final String fi = info.isEmpty() ? Ui.size(e.len) : info;
            final String ft = title;
            final Bitmap fc = cover;
            h.post(() -> {
                if (destroyed || my != idx) return;
                meta.setText(fi);
                if (ft != null && !ft.trim().isEmpty()) nm.setText(ft);
                if (fc != null) {
                    art.setImageBitmap(fc);
                    backArt.setImageBitmap(fc);
                    if (android.os.Build.VERSION.SDK_INT >= 31) backArt.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(36f, 36f, android.graphics.Shader.TileMode.CLAMP));
                    glass.invalidate();
                }
                lrc = lyrics;
                lrcLine = -1;
                if (lyrics.t.length > 0) lyric.setVisibility(View.VISIBLE);
            });
        });

        try {
            if (audioSession == 0) {
                requestAudioFocus();
                if (audio != null) audioSession = audio.generateAudioSessionId();
            } else requestAudioFocus();
            mpReady = false;
            mp = new MediaPlayer();
            if (audioSession != 0) mp.setAudioSessionId(audioSession);
            mp.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnPreparedListener(m -> {
                mpReady = true;
                sb.setMax(m.getDuration());
                ensureEq();
                m.start();
                if (audioSpeed != 1.0f) applyAudioSpeed();
                pp.setImageDrawable(Glyphs.get(Glyphs.PAUSE, Ui.WHITE));
                startTicker(sb, time, lyric);
            });
            mp.setOnCompletionListener(m -> {
                if (repeatMode == 2) {
                    try { m.seekTo(0); m.start(); pp.setImageDrawable(Glyphs.get(Glyphs.PAUSE, Ui.WHITE)); }
                    catch (Exception ignored) { pp.setImageDrawable(Glyphs.get(Glyphs.PLAY, Ui.WHITE)); }
                } else if (audioShuffle && paths.size() > 1) {
                    idx = randomOther(); show();
                } else if (idx < paths.size() - 1) {
                    idx++; show();
                } else if (repeatMode == 1 && paths.size() > 1) {
                    idx = 0; show();
                } else {
                    pp.setImageDrawable(Glyphs.get(Glyphs.PLAY, Ui.WHITE));
                }
            });
            mp.setOnErrorListener((m, w, x) -> {
                Ui.toast(this, "Can't play this audio file");
                pp.setImageDrawable(Glyphs.get(Glyphs.PLAY, Ui.WHITE));
                return true;
            });
            mp.prepareAsync();
        } catch (Exception ex) {
            Ui.toast(this, "Can't play this audio file");
        }
        pp.setOnClickListener(v -> {
            if (mp == null || !mpReady) return;
            try {
                if (mp.isPlaying()) { mp.pause(); pp.setImageDrawable(Glyphs.get(Glyphs.PLAY, Ui.WHITE)); }
                else { requestAudioFocus(); mp.start(); applyAudioSpeed(); pp.setImageDrawable(Glyphs.get(Glyphs.PAUSE, Ui.WHITE)); }
            } catch (Exception ignored) { }
        });
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user && mp != null && mpReady) {
                    try { time.setText(fmt(p) + " / " + fmt(mp.getDuration())); } catch (Exception ignored) { }
                }
            }
            @Override public void onStartTrackingTouch(SeekBar s) { userSeeking = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                userSeeking = false;
                if (mp != null && mpReady) { try { mp.seekTo(s.getProgress()); } catch (Exception ignored) { } }
            }
        });
    }

    static String fmt(int ms) { int s = Math.max(0, ms) / 1000; return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60); }

    void startTicker(final SeekBar sb, final TextView time, final TextView lyric) {
        if (ticker != null) h.removeCallbacks(ticker);
        ticker = new Runnable() {
            @Override public void run() {
                if (mp == null || !mpReady || destroyed) return;
                try {
                    int p = mp.getCurrentPosition();
                    if (!userSeeking) {
                        sb.setProgress(p);
                        time.setText(fmt(p) + " / " + fmt(mp.getDuration()));
                    }
                    Lrc l = lrc;
                    if (l != null && l.t.length > 0) {
                        int cur = -1;
                        for (int i = 0; i < l.t.length; i++) { if (l.t[i] <= p) cur = i; else break; }
                        if (cur != lrcLine) { lrcLine = cur; lyric.setText(cur >= 0 ? l.s[cur] : ""); }
                    }
                } catch (Exception ignored) { }
                h.postDelayed(this, 400);
            }
        };
        h.post(ticker);
    }

    // ---------------- text ----------------
    void showText(final File f) {
        final ScrollView sv = new ScrollView(this);
        final TextView t = new TextView(this);
        t.setTextColor(0xFFE6EAF5);
        t.setTextSize(13);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextIsSelectable(true);
        t.setPadding(Ui.dp(18), Ui.dp(72) + topInset, Ui.dp(18), Ui.dp(40) + bottomInset);
        t.setText("Loading…");
        sv.addView(t, new FrameLayout.LayoutParams(-1, -2));
        stage.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        final int my = idx;
        io.execute(() -> {
            String s;
            try (FileInputStream in = new FileInputStream(f)) {
                byte[] buf = new byte[300 * 1024];
                int n = in.read(buf);
                s = new String(buf, 0, Math.max(n, 0), "UTF-8");
                if (f.length() > buf.length) s += "\n\n… file truncated (showing first 300 KB)";
            } catch (Exception ex) { s = "Can't read this file."; }
            final String fs = s;
            h.post(() -> { if (!destroyed && my == idx) t.setText(fs); });
        });
    }

    // ---------------- pdf ----------------
    void showPdf(File f) {
        try {
            pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
            pdf = new PdfRenderer(pfd);
        } catch (Exception ex) {
            Ui.toast(this, "Can't open this PDF here — try \"Open with\"");
            return;
        }
        final PdfRenderer r = pdf;
        final int count = r.getPageCount();
        final int w = getResources().getDisplayMetrics().widthPixels;
        final LruCache<Integer, Bitmap> cache = new LruCache<>(6);
        ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setClipToPadding(false);
        lv.setPadding(0, Ui.dp(72) + topInset, 0, Ui.dp(24) + bottomInset);
        lv.setVerticalScrollBarEnabled(false);
        lv.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return count; }
            @Override public Object getItem(int i) { return null; }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(final int pos, View cv, ViewGroup parent) {
                final ImageView iv;
                if (cv == null) {
                    iv = new ImageView(ViewerActivity.this);
                    iv.setAdjustViewBounds(true);
                    iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    iv.setBackgroundColor(Color.WHITE);
                    AbsListView.LayoutParams lp = new AbsListView.LayoutParams(-1, -2);
                    iv.setLayoutParams(lp);
                } else iv = (ImageView) cv;
                iv.setTag(pos);
                Bitmap b = cache.get(pos);
                if (b != null) { iv.setImageBitmap(b); iv.setMinimumHeight(0); }
                else {
                    iv.setImageDrawable(null);
                    iv.setMinimumHeight((int) (w * 1.35f));
                    io.execute(() -> {
                        Bitmap bm = renderPage(r, pos, w);
                        if (bm == null) return;
                        cache.put(pos, bm);
                        h.post(() -> {
                            Object tg = iv.getTag();
                            if (!destroyed && tg != null && ((Integer) tg) == pos) { iv.setImageBitmap(bm); iv.setMinimumHeight(0); }
                        });
                    });
                }
                return iv;
            }
        });
        stage.addView(lv, new FrameLayout.LayoutParams(-1, -1));
    }

    static Bitmap renderPage(PdfRenderer r, int pos, int w) {
        try {
            synchronized (r) {
                PdfRenderer.Page p = r.openPage(pos);
                float sc = (float) w / p.getWidth();
                Bitmap b = Bitmap.createBitmap(w, Math.max(1, (int) (p.getHeight() * sc)), Bitmap.Config.ARGB_8888);
                b.eraseColor(Color.WHITE);
                p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                p.close();
                return b;
            }
        } catch (Throwable t) {
            return null;
        }
    }

    @Override protected void onPause() {
        super.onPause();
        // Video pauses when the screen is left; music keeps playing (screen off / app in background).
        saveVideoPos();
        try { if (vv != null && vv.isPlaying()) vv.pause(); } catch (Exception ignored) { }
        if (!Ui.bool("bg_audio", true)) pauseMedia();
    }

    @Override protected void onDestroy() {
        destroyed = true;
        Ui.setLight(Ui.sp.getBoolean("light", false), false);
        if (sleepTask != null) { h.removeCallbacks(sleepTask); sleepTask = null; }
        cleanup();
        try { unregisterReceiver(noisyReceiver); } catch (Exception ignored) { }
        try { if (eq != null) eq.release(); } catch (Throwable ignored) { }
        eq = null;
        abandonAudioFocus();
        io.shutdown();
        super.onDestroy();
    }
}
