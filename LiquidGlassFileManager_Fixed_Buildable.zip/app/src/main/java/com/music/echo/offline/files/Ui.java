package com.music.echo.offline.files;

import com.music.echo.offline.R;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Shared look & feel helpers: theme colours, glass drawables, small view factories. */
final class Ui {
    static float D = 3f;
    static SharedPreferences sp;
    static int theme = 0, accent = Color.rgb(150, 175, 255), blob1, blob2, blob3;
    static int top = 0, bottom = 0;
    // Not "final" on purpose: javac only inlines static-final primitives initialized with a
    // constant expression. WHITE (a literal) would be baked into every call site and could
    // never be swapped for a light theme; keeping it a real mutable field means one call to
    // setLight() recolors every screen that reads Ui.WHITE / Ui.SUB, without editing each file.
    static int WHITE = 0xFFFFFFFF;
    static int SUB = Color.argb(175, 225, 230, 244);
    static boolean light = false;
    static int bg = Color.rgb(7, 9, 15);
    static int panelR = 10, panelG = 14, panelB = 26;
    static int hiTop = Color.argb(56, 255, 255, 255), hiBot = Color.argb(6, 255, 255, 255);
    static int edgeStroke = Color.argb(72, 255, 255, 255);
    static final String[] THEMES = {"Cool Blue", "Warm Amber", "Monochrome", "Aurora Green"};
    static final int[] DOTS = {Color.rgb(150, 175, 255), Color.rgb(255, 190, 120), Color.rgb(225, 228, 235), Color.rgb(120, 235, 200)};
    static final SimpleDateFormat DF = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());

    static void init(Context c) {
        D = c.getResources().getDisplayMetrics().density;
        if (sp == null) sp = c.getApplicationContext().getSharedPreferences("lg_settings", Context.MODE_PRIVATE);
        setLight(sp.getBoolean("light", false), false);
        setTheme(sp.getInt("theme", 0), false);
    }

    static void setLight(boolean l, boolean save) {
        light = l;
        if (save) sp.edit().putBoolean("light", l).apply();
        if (l) {
            WHITE = Color.rgb(18, 20, 26);
            SUB = Color.argb(210, 70, 75, 90);
            bg = Color.rgb(236, 238, 244);
            panelR = 255; panelG = 255; panelB = 255;
            hiTop = Color.argb(150, 255, 255, 255); hiBot = Color.argb(10, 255, 255, 255);
            edgeStroke = Color.argb(50, 20, 22, 30);
        } else {
            WHITE = 0xFFFFFFFF;
            SUB = Color.argb(175, 225, 230, 244);
            bg = Color.rgb(7, 9, 15);
            panelR = 10; panelG = 14; panelB = 26;
            hiTop = Color.argb(56, 255, 255, 255); hiBot = Color.argb(6, 255, 255, 255);
            edgeStroke = Color.argb(72, 255, 255, 255);
        }
    }

    static int dp(float v) { return Math.round(v * D); }

    static void setTheme(int t, boolean save) {
        theme = t;
        if (save) sp.edit().putInt("theme", t).apply();
        switch (t) {
            case 1: accent = Color.rgb(255, 190, 120); blob1 = Color.argb(115, 255, 150, 70); blob2 = Color.argb(95, 255, 80, 90); blob3 = Color.argb(70, 255, 210, 120); break;
            case 2: accent = Color.rgb(225, 228, 235); blob1 = Color.argb(70, 255, 255, 255); blob2 = Color.argb(55, 170, 180, 200); blob3 = Color.argb(40, 255, 255, 255); break;
            case 3: accent = Color.rgb(120, 235, 200); blob1 = Color.argb(105, 30, 200, 160); blob2 = Color.argb(90, 70, 120, 255); blob3 = Color.argb(70, 150, 255, 200); break;
            default: accent = Color.rgb(150, 175, 255); blob1 = Color.argb(115, 90, 120, 255); blob2 = Color.argb(100, 170, 100, 255); blob3 = Color.argb(70, 60, 200, 255);
        }
    }

    static boolean bool(String k, boolean d) { return sp.getBoolean(k, d); }
    static void set(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }

    /**
     * Liquid Glass panel: tinted translucent body, diagonal colour bloom, a soft specular spot and
     * top sheen, an inner glow along the bottom edge and a gradient rim that is bright on the
     * top-left and bottom-right like light catching glass. It is drawn translucent over the
     * blurred colour background; it does not blur whatever is directly behind each panel.
     */
    static Drawable glass(float radiusDp, boolean strong) { return new GlassDrawable(dp(radiusDp), strong); }

    static final class GlassDrawable extends Drawable {
        private final float rad;
        private final boolean strong, lightMode = light;
        private final int accentC = accent, blobC = blob2, panel = Color.rgb(panelR, panelG, panelB);
        private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG), bloom = new Paint(Paint.ANTI_ALIAS_FLAG),
                sheen = new Paint(Paint.ANTI_ALIAS_FLAG), spot = new Paint(Paint.ANTI_ALIAS_FLAG),
                glow = new Paint(Paint.ANTI_ALIAS_FLAG), rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint[] all = {body, bloom, sheen, spot, glow, rim};
        private final RectF r = new RectF(), sheenR = new RectF(), glowR = new RectF();
        private final Path shape = new Path();
        private int alpha = 255;

        GlassDrawable(float rad, boolean strong) {
            this.rad = rad;
            this.strong = strong;
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(Math.max(1f, dp(1.2f)));
        }

        private float radius() { return Math.max(0f, Math.min(rad, Math.min(r.width(), r.height()) / 2f)); }

        @Override protected void onBoundsChange(Rect b) {
            super.onBoundsChange(b);
            float w = b.width(), h = b.height();
            if (w <= 0 || h <= 0) { r.setEmpty(); return; }
            float inset = rim.getStrokeWidth() / 2f;
            r.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset);
            float cr = radius();
            shape.reset();
            shape.addRoundRect(r, cr, cr, Path.Direction.CW);
            int ba = strong ? (lightMode ? 194 : 148) : (lightMode ? 158 : 112);
            int pr = Color.red(panel), pg = Color.green(panel), pb = Color.blue(panel);
            int ar = Color.red(accentC), ag = Color.green(accentC), ab = Color.blue(accentC);
            int br = Color.red(blobC), bg2 = Color.green(blobC), bb = Color.blue(blobC);
            body.setShader(new LinearGradient(0, b.top, 0, b.bottom,
                    new int[]{Color.argb(Math.min(245, ba + 22), pr, pg, pb), Color.argb(ba, pr, pg, pb), Color.argb(Math.max(24, ba - 28), pr, pg, pb)},
                    null, Shader.TileMode.CLAMP));
            bloom.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                    new int[]{Color.argb(lightMode ? 40 : 56, ar, ag, ab), Color.argb(lightMode ? 10 : 16, br, bg2, bb), Color.argb(0, 255, 255, 255)},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            sheenR.set(r.left + inset * 2, r.top + inset * 2, r.right - inset * 2, r.top + r.height() * 0.48f);
            sheen.setShader(new LinearGradient(0, sheenR.top, 0, sheenR.bottom,
                    Color.argb(lightMode ? 120 : 84, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP));
            spot.setShader(new RadialGradient(b.left + w * 0.16f, b.top - h * 0.05f, Math.max(w, h) * 0.45f,
                    Color.argb(lightMode ? 140 : 96, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP));
            glowR.set(r.left, r.top + r.height() * 0.62f, r.right, r.bottom);
            glow.setShader(new LinearGradient(0, glowR.top, 0, glowR.bottom,
                    Color.argb(0, ar, ag, ab), Color.argb(lightMode ? 46 : 62, ar, ag, ab), Shader.TileMode.CLAMP));
            rim.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                    new int[]{Color.argb(lightMode ? 230 : 190, 255, 255, 255), Color.argb(lightMode ? 70 : 46, 255, 255, 255), Color.argb(lightMode ? 150 : 120, 255, 255, 255)},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        }

        @Override public void draw(Canvas c) {
            if (r.isEmpty()) return;
            for (Paint p : all) p.setAlpha(alpha);
            float cr = radius();
            c.drawRoundRect(r, cr, cr, body);
            c.drawRoundRect(r, cr, cr, bloom);
            int save = c.save();
            c.clipPath(shape);
            c.drawRect(glowR, glow);
            c.drawRect(r, spot);
            c.restoreToCount(save);
            c.drawRoundRect(sheenR, cr, cr, sheen);
            c.drawRoundRect(r, cr, cr, rim);
        }

        @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }

        @Override public void setColorFilter(ColorFilter cf) { for (Paint p : all) p.setColorFilter(cf); invalidateSelf(); }

        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    static Drawable accentPill(float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(105, Color.red(accent), Color.green(accent), Color.blue(accent)));
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(Math.max(1, dp(1)), Color.argb(130, 255, 255, 255));
        return g;
    }

    static TextView tv(Context c, CharSequence t, float sp, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        v.setIncludeFontPadding(false);
        return v;
    }

    static ImageView iconBtn(Context c, int glyph, int color) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(Glyphs.get(glyph, color));
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        press(v);
        return v;
    }

    /** Springy "liquid" press feedback; never consumes the touch so clicks still work. */
    static void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(new OvershootInterpolator(2.2f)).start();
            return false;
        });
    }

    static void round(View v, final float rDp) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline o) {
                o.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(rDp));
            }
        });
        v.setClipToOutline(true);
    }

    static void tick(View v) {
        if (bool("haptic", true)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    static void toast(Context c, String m) { Toast.makeText(c, m, Toast.LENGTH_SHORT).show(); }

    static String size(long n) {
        if (n < 1024) return n + " B";
        if (n < 1048576L) return (n / 1024) + " KB";
        if (n < 1073741824L) return String.format(Locale.US, "%.1f MB", n / 1048576.0);
        return String.format(Locale.US, "%.2f GB", n / 1073741824.0);
    }

    static String date(long t) { return DF.format(new Date(t)); }
}
