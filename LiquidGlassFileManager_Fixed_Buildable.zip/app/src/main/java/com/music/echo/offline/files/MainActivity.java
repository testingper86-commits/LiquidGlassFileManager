package com.music.echo.offline.files;

import com.music.echo.offline.R;

import android.Manifest;
import android.app.Activity;
import com.example.liquidglass.GlassMaterial;
import com.example.liquidglass.LiquidGlassView;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.content.ContentResolver;
import android.database.Cursor;
import android.provider.DocumentsContract;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public class MainActivity extends Activity {
    final ExecutorService io = Executors.newFixedThreadPool(2);
    final ExecutorService ops = Executors.newSingleThreadExecutor();
    final Set<String> favs = new LinkedHashSet<>();
    File[] clip;
    boolean clipCut;

    FrameLayout root, content;
    BgView bg;
    ScrollView homeScroll, settingsScroll, aboutScroll, recycleScroll, vaultScroll;
    LinearLayout home, settings, about, recycle, vault;
    static final int REQ_SAF_TREE = 501, REQ_IMPORT_SETTINGS = 502;
    Uri safTree;
    ScrollView dupScroll;
    LinearLayout dup;
    boolean unlocked = false;
    BrowserView filesView, favView, listView;
    View[] screens;
    FrameLayout nav;
    LiquidGlassView dockGlass;
    View hl;
    ImageView[] navIc = new ImageView[3];
    TextView[] navTx = new TextView[3];
    TextView busyTv;
    int busyCount, tab = 0, pendingCat = -1;
    View overlayView;
    boolean accessOk;
    final Handler ui = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        boolean lightPref = getSharedPreferences("lg_settings", MODE_PRIVATE).getBoolean("light", false);
        setTheme(lightPref ? R.style.AppTheme_Light : R.style.AppTheme);
        super.onCreate(b);
        Ui.init(this);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        SharedPreferences fp = getSharedPreferences("lg_favs", MODE_PRIVATE);
        favs.addAll(fp.getStringSet("paths", new HashSet<String>()));

        root = new FrameLayout(this);
        root.setBackgroundColor(Ui.bg);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        else root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        bg = new BgView(this);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        content = new FrameLayout(this);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        homeScroll = new ScrollView(this);
        homeScroll.setVerticalScrollBarEnabled(false);
        homeScroll.setClipToPadding(false);
        home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        homeScroll.addView(home, new FrameLayout.LayoutParams(-1, -2));
        settingsScroll = new ScrollView(this);
        settingsScroll.setVerticalScrollBarEnabled(false);
        settingsScroll.setClipToPadding(false);
        settings = new LinearLayout(this);
        settings.setOrientation(LinearLayout.VERTICAL);
        settingsScroll.addView(settings, new FrameLayout.LayoutParams(-1, -2));
        aboutScroll = new ScrollView(this);
        aboutScroll.setVerticalScrollBarEnabled(false);
        aboutScroll.setClipToPadding(false);
        about = new LinearLayout(this);
        about.setOrientation(LinearLayout.VERTICAL);
        aboutScroll.addView(about, new FrameLayout.LayoutParams(-1, -2));
        recycleScroll = new ScrollView(this);
        recycleScroll.setVerticalScrollBarEnabled(false);
        recycleScroll.setClipToPadding(false);
        recycle = new LinearLayout(this);
        recycle.setOrientation(LinearLayout.VERTICAL);
        recycleScroll.addView(recycle, new FrameLayout.LayoutParams(-1, -2));
        vaultScroll = new ScrollView(this);
        vaultScroll.setVerticalScrollBarEnabled(false);
        vaultScroll.setClipToPadding(false);
        vault = new LinearLayout(this);
        vault.setOrientation(LinearLayout.VERTICAL);
        vaultScroll.addView(vault, new FrameLayout.LayoutParams(-1, -2));
        dupScroll = new ScrollView(this);
        dupScroll.setVerticalScrollBarEnabled(false);
        dupScroll.setClipToPadding(false);
        dup = new LinearLayout(this);
        dup.setOrientation(LinearLayout.VERTICAL);
        dupScroll.addView(dup, new FrameLayout.LayoutParams(-1, -2));

        filesView = new BrowserView(this, false, false);
        favView = new BrowserView(this, false, true);
        listView = new BrowserView(this, true, false);
        screens = new View[]{homeScroll, filesView, favView, settingsScroll};
        View[] all = {homeScroll, filesView, favView, settingsScroll, listView, aboutScroll, recycleScroll, vaultScroll, dupScroll};
        for (View v : all) { content.addView(v, new FrameLayout.LayoutParams(-1, -1)); v.setVisibility(View.GONE); }

        buildNav();
        busyTv = Ui.tv(this, "Working…", 13, Ui.WHITE, true);
        busyTv.setBackground(Ui.accentPill(20));
        busyTv.setPadding(Ui.dp(18), Ui.dp(10), Ui.dp(18), Ui.dp(10));
        busyTv.setVisibility(View.GONE);
        root.addView(busyTv, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL));

        setContentView(root);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets in = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Ui.top = in.top; Ui.bottom = in.bottom;
            } else { Ui.top = insets.getSystemWindowInsetTop(); Ui.bottom = insets.getSystemWindowInsetBottom(); }
            applyInsets();
            return insets;
        });
        root.requestApplyInsets();

        accessOk = hasAccess();
        selectTab(0);
        if (!accessOk) {
            if (Build.VERSION.SDK_INT >= 30) ui.postDelayed(() -> { if (!isFinishing() && !isDestroyed() && !hasAccess()) showStorageAccess(); }, 600);
            else requestLegacyPerms();
        } else startIndex();
    }

    void applyInsets() {
        content.setPadding(0, Ui.top, 0, 0);
        FrameLayout.LayoutParams np = (FrameLayout.LayoutParams) nav.getLayoutParams();
        np.bottomMargin = Ui.bottom + Ui.dp(12);
        nav.setLayoutParams(np);
        FrameLayout.LayoutParams bp = (FrameLayout.LayoutParams) busyTv.getLayoutParams();
        bp.topMargin = Ui.top + Ui.dp(8);
        busyTv.setLayoutParams(bp);
        int pad = Ui.dp(120) + Ui.bottom;
        homeScroll.setPadding(0, 0, 0, pad);
        settingsScroll.setPadding(0, 0, 0, pad);
        aboutScroll.setPadding(0, 0, 0, Ui.dp(24) + Ui.bottom);
        recycleScroll.setPadding(0, 0, 0, Ui.dp(24) + Ui.bottom);
        vaultScroll.setPadding(0, 0, 0, Ui.dp(24) + Ui.bottom);
        dupScroll.setPadding(0, 0, 0, Ui.dp(24) + Ui.bottom);
        filesView.applyInsets(); favView.applyInsets(); listView.applyInsets();
    }

    // ---------------- permissions ----------------
    boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        if (Build.VERSION.SDK_INT >= 23) return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        return true;
    }

    void requestLegacyPerms() {
        if (Build.VERSION.SDK_INT >= 23)
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 77);
    }

    void showStorageAccess() {
        if (Build.VERSION.SDK_INT < 30) { requestLegacyPerms(); return; }
        new AlertDialog.Builder(this).setTitle("Allow access to all files")
                .setMessage("A file manager needs \"All files access\" to show, open, copy, move and delete your files. Files never leave your device.")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Open settings", (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) {
                        try { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
                        catch (Exception e2) { Ui.toast(this, "Open Settings > Apps > Special access > All files access"); }
                    }
                }).show();
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        onAccessChanged();
    }

    @Override protected void onResume() {
        super.onResume();
        if (dockGlass != null) dockGlass.setEnableDynamicBackground(true);
        if (AppLock.enabled(this) && !unlocked) showAppLock();
        if (hasAccess() != accessOk) onAccessChanged();
        else if (accessOk && !Indexer.I.running && (Indexer.I.dirty || System.currentTimeMillis() - Indexer.I.finished > 180000)) startIndex();
    }

    @Override protected void onPause() {
        super.onPause();
        if (dockGlass != null) dockGlass.setEnableDynamicBackground(false);
        unlocked = false; // re-lock every time the app leaves the foreground
    }

    void onAccessChanged() {
        accessOk = hasAccess();
        if (accessOk) startIndex();
        if (filesView.cur != null) filesView.reload();
        if (tab == 0) buildHome();
        if (tab == 3) buildSettings();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        io.shutdown();
        ops.shutdown();
    }

    // ---------------- index ----------------
    void startIndex() {
        if (!hasAccess()) return;
        Indexer.I.start(this::onIndexDone);
        if (tab == 0 && overlayView == null) buildHome();
    }

    void onIndexDone() {
        String[] names = Indexer.CAT_NAMES;
        if (pendingCat >= 0 && pendingCat < 6) { listView.setList(names[pendingCat], Indexer.I.cats.get(pendingCat), false, false); pendingCat = -1; }
        else if (pendingCat == -2) { listView.setList("Search", Indexer.I.all, true, true); pendingCat = -1; }
        if (tab == 0 && overlayView == null) buildHome();
    }

    void afterOps() {
        Indexer.I.dirty = true;
        filesView.reload();
        favView.reload();
        if (overlayView == listView) listView.reload();
        filesView.updatePaste();
        if (tab == 0) buildHome();
        if (!Indexer.I.running && hasAccess()) startIndex();
    }

    // ---------------- clipboard / favourites / busy ----------------
    void setClip(File[] f, boolean cut) { clip = f; clipCut = cut; filesView.updatePaste(); }

    void saveFavs() { getSharedPreferences("lg_favs", MODE_PRIVATE).edit().putStringSet("paths", new HashSet<>(favs)).apply(); }
    boolean isFav(File f) { return favs.contains(f.getAbsolutePath()); }
    void toggleFav(File f) { String p = f.getAbsolutePath(); if (!favs.remove(p)) favs.add(p); saveFavs(); }
    void removeFavs(List<File> fs) { for (File f : fs) favs.remove(f.getAbsolutePath()); saveFavs(); }
    void renameFav(File from, File to) { if (favs.remove(from.getAbsolutePath())) { favs.add(to.getAbsolutePath()); saveFavs(); } }

    void busy(boolean on) {
        busyCount = Math.max(0, busyCount + (on ? 1 : -1));
        busyTv.setVisibility(busyCount > 0 ? View.VISIBLE : View.GONE);
        if (busyCount == 1 && on) busyTv.setText("Working…"); // reset text for ops that don't call progress()
    }

    /** Called from a background thread via runOnUiThread to show granular "N of M" progress. */
    void progress(String text) { busyTv.setText(text); }

    // ---------------- opening things ----------------
    void openDir(File dir) {
        closeOverlay();
        selectTab(1);
        filesView.showDir(dir);
    }

    void openFile(Entry e, List<Entry> ctx) {
        if (e.dir) { openDir(e.f); return; }
        int k = e.kind;
        boolean inApp = Ui.bool("inapp", true);
        if (inApp && (k == FileKinds.IMAGE || k == FileKinds.VIDEO || k == FileKinds.AUDIO || k == FileKinds.TEXT || k == FileKinds.PDF)) {
            ArrayList<String> ps = new ArrayList<>();
            int idx = 0;
            if (k == FileKinds.IMAGE || k == FileKinds.VIDEO || k == FileKinds.AUDIO) {
                for (Entry x : ctx) if (x.kind == k) { if (x == e) idx = ps.size(); ps.add(x.f.getAbsolutePath()); }
                if (ps.size() > 400) {
                    int from = Math.max(0, Math.min(idx - 200, ps.size() - 400));
                    ps = new ArrayList<>(ps.subList(from, from + 400));
                    idx -= from;
                }
            } else ps.add(e.f.getAbsolutePath());
            Intent i = new Intent(this, ViewerActivity.class);
            i.putStringArrayListExtra("paths", ps);
            i.putExtra("index", idx);
            startActivity(i);
            return;
        }
        if (k == FileKinds.ARCHIVE && e.ext.equals("zip")) { showZip(e.f); return; }
        if (k == FileKinds.APK) { FileOps.install(this, e.f); return; }
        FileOps.external(this, e.f, false);
    }

    void showZip(final File z) {
        try {
            List<String> names = FileOps.listZip(z);
            android.widget.ListView lv = new android.widget.ListView(this);
            lv.setAdapter(new android.widget.ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names));
            new AlertDialog.Builder(this).setTitle(z.getName()).setView(lv).setNegativeButton("Close", null)
                    .setPositiveButton("Extract", (d, w) -> FileOps.unzip(this, z, msg -> { Ui.toast(this, msg); afterOps(); })).show();
        } catch (Exception ex) {
            Ui.toast(this, "Can't read this ZIP file");
        }
    }

    void openCategory(int cat) {
        Indexer ix = Indexer.I;
        listView.setList(Indexer.CAT_NAMES[cat], ix.ready ? ix.cats.get(cat) : null, false, false);
        if (!ix.ready) { pendingCat = cat; if (!ix.running) startIndex(); }
        showOverlay(listView);
    }

    void openSearch() {
        Indexer ix = Indexer.I;
        listView.setList("Search", ix.ready ? ix.all : null, true, true);
        if (!ix.ready) { pendingCat = -2; if (!ix.running) startIndex(); }
        showOverlay(listView);
    }

    // ---------------- tabs / overlay / nav ----------------
    void selectTab(int i) {
        closeOverlay();
        tab = i;
        for (int k = 0; k < screens.length; k++) {
            screens[k].animate().cancel();
            screens[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
            screens[k].setAlpha(1f);
            screens[k].setTranslationY(0);
        }
        View s = screens[i];
        s.setAlpha(0f);
        s.setTranslationY(Ui.dp(12));
        s.animate().alpha(1f).translationY(0f).setDuration(240).setInterpolator(new DecelerateInterpolator()).start();
        if (i == 0) buildHome();
        else if (i == 1) {
            if (filesView.cur == null) {
                String def = Ui.sp.getString("default_folder", null);
                File start = (def != null && new File(def).isDirectory()) ? new File(def) : Environment.getExternalStorageDirectory();
                filesView.showDir(start);
            }
        }
        else if (i == 2) favView.refreshFavs();
        else { subKey = null; buildSettings(); }
        moveHighlight(i);
    }

    void showOverlay(View v) {
        overlayView = v;
        screens[tab].setVisibility(View.GONE);
        v.setAlpha(0f);
        v.setTranslationY(Ui.dp(14));
        v.setVisibility(View.VISIBLE);
        v.animate().alpha(1f).translationY(0f).setDuration(240).setInterpolator(new DecelerateInterpolator()).start();
        nav.setVisibility(v == listView ? View.GONE : View.VISIBLE);
    }

    void closeOverlay() {
        if (overlayView == null) return;
        if (overlayView == listView) { listView.closeSearch(); listView.selecting = false; listView.sel.clear(); pendingCat = -1; }
        overlayView.setVisibility(View.GONE);
        overlayView = null;
        screens[tab].setVisibility(View.VISIBLE);
        nav.setVisibility(View.VISIBLE);
        if (tab == 0) buildHome();
    }

    void navForSelection(boolean selecting) { nav.setVisibility(selecting || overlayView == listView ? View.GONE : View.VISIBLE); }

    @Override public void onBackPressed() {
        if (overlayView == listView) { listView.handleBack(); return; }
        if (overlayView != null) { closeOverlay(); return; }
        if (tab == 1 && filesView.handleBack()) return;
        if (tab == 2 && favView.handleBack()) return;
        if (tab == 3 && subKey != null) { closeSub(); return; }
        if (tab != 0) { selectTab(0); return; }
        super.onBackPressed();
    }

    void buildNav() {
        LiquidGlassView dock = new LiquidGlassView(this);
        dock.setCornerRadius(Ui.dp(30));
        dock.setMaterial(GlassMaterial.REGULAR);
        dock.setRefractionHeight(Ui.dp(12));
        dock.setBevelWidth(Ui.dp(20));
        dock.setDispersionStrength(0.08f);
        dock.setGlassTint(Ui.accent, 0.10f);
        dock.setEnablePressEffect(false);
        dockGlass = dock;
        nav = dock;
        nav.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        hl = new View(this);
        hl.setBackground(Ui.accentPill(24));
        nav.addView(hl, new FrameLayout.LayoutParams(0, -1));
        LinearLayout items = new LinearLayout(this);
        items.setOrientation(LinearLayout.HORIZONTAL);
        nav.addView(items, new FrameLayout.LayoutParams(-1, -1));
        int[] gl = {Glyphs.HOME, Glyphs.AUDIO, Glyphs.TUNE};
        String[] lb = {"Home", "Music", "Settings"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            navIc[i] = new ImageView(this);
            navTx[i] = Ui.tv(this, lb[i], 10.5f, Ui.SUB, false);
            navIc[i].setImageDrawable(Glyphs.get(gl[i], Ui.WHITE));
            navIc[i].setContentDescription(lb[i]);
            it.addView(navIc[i], new LinearLayout.LayoutParams(Ui.dp(24), Ui.dp(24)));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
            tp.topMargin = Ui.dp(3);
            it.addView(navTx[i], tp);
            it.setOnClickListener(v -> {
                Ui.tick(v);
                if (idx == 1) {
                    openCategory(2);
                } else if (idx == 2) {
                    selectTab(3);
                } else {
                    selectTab(0);
                }
            });
            Ui.press(it);
            items.addView(it, new LinearLayout.LayoutParams(0, -1, 1f));
        }
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, Ui.dp(66), Gravity.BOTTOM);
        lp.setMargins(Ui.dp(16), 0, Ui.dp(16), Ui.dp(12));
        root.addView(nav, lp);
        nav.addOnLayoutChangeListener((v, l, t, r, b, l0, t0, r0, b0) -> {
            int iw = (r - l - Ui.dp(12)) / 3;
            FrameLayout.LayoutParams hp = (FrameLayout.LayoutParams) hl.getLayoutParams();
            if (hp.width != iw) { hp.width = iw; hl.setLayoutParams(hp); }
            hl.setTranslationX((tab == 3 ? 2 : 0) * iw);
        });
    }

    void moveHighlight(int i) {
        int iw = hl.getLayoutParams().width;
        int visualIndex = i == 3 ? 2 : 0;
        hl.animate().translationX(visualIndex * iw).setDuration(340).setInterpolator(new OvershootInterpolator(1.0f)).start();
        for (int k = 0; k < 3; k++) navTx[k].setTextColor(k == visualIndex ? Ui.WHITE : Ui.SUB);
    }

    void recolor() {
        root.setBackgroundColor(Ui.bg);
        bg.invalidate();
        hl.setBackground(Ui.accentPill(24));
        filesView.ad.notifyDataSetChanged();
        favView.ad.notifyDataSetChanged();
        listView.ad.notifyDataSetChanged();
        buildHome();
        buildSettings();
        if (vault.getChildCount() > 0) buildVault();
        if (recycle.getChildCount() > 0) buildRecycleBin();
    }

    // ---------------- HOME ----------------
    LinearLayout.LayoutParams lpm(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(Ui.dp(l), Ui.dp(t), Ui.dp(r), Ui.dp(b));
        return p;
    }

    TextView section(String t) {
        TextView v = Ui.tv(this, t, 17, Ui.WHITE, true);
        v.setPadding(Ui.dp(20), Ui.dp(22), 0, Ui.dp(10));
        return v;
    }

    void buildHome() {
        home.removeAllViews();
        Indexer ix = Indexer.I;
        LinearLayout hd = new LinearLayout(this);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        hd.setPadding(Ui.dp(20), Ui.dp(8), Ui.dp(8), 0);
        hd.addView(Ui.tv(this, "Liquid Glass Files", 26, Ui.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView sb = Ui.iconBtn(this, Glyphs.SEARCH, Ui.WHITE);
        sb.setContentDescription("Search");
        sb.setOnClickListener(v -> openSearch());
        hd.addView(sb, new LinearLayout.LayoutParams(Ui.dp(48), Ui.dp(48)));
        ImageView mb = Ui.iconBtn(this, Glyphs.MORE, Ui.WHITE);
        mb.setContentDescription("Tools");
        mb.setOnClickListener(v -> showToolsMenu(v));
        hd.addView(mb, new LinearLayout.LayoutParams(Ui.dp(48), Ui.dp(48)));
        home.addView(hd, new LinearLayout.LayoutParams(-1, Ui.dp(60)));

        if (!hasAccess()) {
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setBackground(Ui.glass(24, true));
            c.setPadding(Ui.dp(20), Ui.dp(20), Ui.dp(20), Ui.dp(20));
            c.addView(Ui.tv(this, "Allow access to your files", 18, Ui.WHITE, true));
            TextView d = Ui.tv(this, "Grant \"All files access\" so Liquid Glass can browse, open and manage every file on your phone.", 13, Ui.SUB, false);
            d.setPadding(0, Ui.dp(8), 0, Ui.dp(14));
            c.addView(d);
            TextView btn = Ui.tv(this, "Grant access", 14, Ui.WHITE, true);
            btn.setBackground(Ui.accentPill(22));
            btn.setGravity(Gravity.CENTER);
            btn.setPadding(0, Ui.dp(13), 0, Ui.dp(13));
            btn.setOnClickListener(v -> showStorageAccess());
            Ui.press(btn);
            c.addView(btn, new LinearLayout.LayoutParams(-1, -2));
            home.addView(c, lpm(-1, -2, 16, 12, 16, 0));
            return;
        }

        // Same structure as the File Manager+ reference: one 3-column grid, nothing else.
        File root = Environment.getExternalStorageDirectory();
        long total = root.getTotalSpace(), free = root.getFreeSpace(), used = Math.max(0, total - free);
        final File rootF = root;
        final File dl = new File(root, "Download");
        final File sd = sdRoot();
        final int cMain = Color.rgb(255, 176, 64), cSd = Color.rgb(120, 130, 255), cRec = Color.rgb(255, 92, 120), cVault = Color.rgb(46, 196, 140), cOther = Color.rgb(64, 190, 245);
        View mainTile = tile(iconTile(Glyphs.FOLDER, cMain), "Main storage", Ui.size(used) + " / " + Ui.size(total), cMain, "Main storage. Open", v -> openDir(rootF));
        View secondTile;
        if (sd != null) {
            long sdTotal = sd.getTotalSpace(), sdFree = sd.getFreeSpace();
            secondTile = tile(iconTile(Glyphs.FILES, cSd), "SD card", Ui.size(Math.max(0, sdTotal - sdFree)) + " / " + Ui.size(sdTotal), cSd, "SD card. Open", v -> openDir(sd));
        } else {
            secondTile = tile(iconTile(Glyphs.FILES, cSd), "Other storage", "SD, USB, cloud", cSd, "Other storage. Browse", v -> openOtherStorage());
        }
        View dlTile = tile(imgTile(FileKinds.DIR), "Downloads", ix.ready ? Ui.size(ix.dlSize) + " (" + ix.dlCount + ")" : "…", FileKinds.color(FileKinds.DIR), "Downloads. Open", v -> openDir(dl.isDirectory() ? dl : rootF));
        addTileRow(mainTile, secondTile, dlTile);
        addTileRow(catTile(FileKinds.IMAGE, 0, "Images"), catTile(FileKinds.AUDIO, 2, "Audio"), catTile(FileKinds.VIDEO, 1, "Videos"));
        addTileRow(catTile(FileKinds.DOC, 3, "Documents"), catTile(FileKinds.APK, 5, "Apps"), catTile(FileKinds.ARCHIVE, 4, "Archives"));
        final int binCount = RecycleBin.list(this).size();
        final int vaultCount = Vault.list(this).size();
        addTileRow(
                tile(iconTile(Glyphs.TRASH, cRec), "Recycle Bin", binCount == 0 ? "Empty" : binCount + (binCount == 1 ? " item" : " items"), cRec, "Recycle Bin. Open", v -> showRecycleBin()),
                tile(iconTile(Glyphs.TUNE, cVault), "Vault", vaultCount + (vaultCount == 1 ? " item" : " items"), cVault, "Vault. Unlock", v -> promptVaultPin()),
                tile(iconTile(Glyphs.FOLDER_PLUS, cOther), "Other storage", "SD, USB, cloud", cOther, "Other storage. Browse", v -> openOtherStorage()));
    }

    void showToolsMenu(View anchor) {
        android.widget.PopupMenu pm = new android.widget.PopupMenu(this, anchor);
        String[] items = {"Largest files", "Duplicate files", "Empty folders", "Storage analysis", "Shuffle music", "Receive via Wi-Fi"};
        for (int i = 0; i < items.length; i++) pm.getMenu().add(0, i, i, items[i]);
        pm.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 0: openLargest(); break;
                case 1: openDuplicates(); break;
                case 2: openCleanup(); break;
                case 3: openStorageAnalyzer(); break;
                case 4: shuffleMusic(); break;
                default: receiveViaWifi();
            }
            return true;
        });
        pm.show();
    }

    // ---- home building blocks ----
    View tile(View icon, String title, String sub, int color, String desc, final View.OnClickListener l) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setBackground(Ui.glass(20, false));
        t.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(10), Ui.dp(12));
        t.addView(icon, new LinearLayout.LayoutParams(Ui.dp(38), Ui.dp(38)));
        TextView nm = Ui.tv(this, title, 14, Ui.WHITE, true);
        nm.setSingleLine(true);
        nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nm.setPadding(0, Ui.dp(10), 0, 0);
        t.addView(nm);
        TextView st = Ui.tv(this, sub, 11, Glyphs.mix(Ui.SUB, color, 0.55f), false);
        st.setSingleLine(true);
        st.setEllipsize(android.text.TextUtils.TruncateAt.END);
        st.setPadding(0, Ui.dp(3), 0, 0);
        t.addView(st);
        t.setContentDescription(desc);
        t.setFocusable(true);
        t.setOnClickListener(v -> { Ui.tick(v); l.onClick(v); });
        Ui.press(t);
        return t;
    }

    View iconTile(int glyph, int color) {
        FrameLayout f = new FrameLayout(this);
        android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR, new int[]{Glyphs.mix(color, Color.WHITE, 0.35f), color});
        gd.setCornerRadius(Ui.dp(12));
        gd.setStroke(Math.max(1, Ui.dp(1)), Color.argb(150, 255, 255, 255));
        f.setBackground(gd);
        ImageView g = new ImageView(this);
        g.setImageDrawable(Glyphs.get(glyph, Ui.WHITE));
        f.addView(g, new FrameLayout.LayoutParams(Ui.dp(22), Ui.dp(22), Gravity.CENTER));
        return f;
    }

    View imgTile(int fileKind) {
        ImageView ic = new ImageView(this);
        ic.setImageDrawable(Glyphs.tile(fileKind));
        return ic;
    }

    View catTile(int kind, final int cat, String name) {
        Indexer ix = Indexer.I;
        String sub = ix.ready ? Ui.size(ix.sizes[cat]) + " (" + ix.counts[cat] + ")" : "…";
        String desc = name + ", " + (ix.ready ? ix.counts[cat] + " files" : "count loading") + ". Open category";
        return tile(imgTile(kind), name, sub, FileKinds.color(kind), desc, v -> openCategory(cat));
    }

    void addTileRow(View a, View b, View c) {
        LinearLayout row = new LinearLayout(this);
        View[] v = {a, b, c};
        for (int i = 0; i < 3; i++) {
            LinearLayout.LayoutParams p = lpm(0, -2, i == 0 ? 16 : 4, 0, i == 2 ? 16 : 4, 8);
            p.weight = 1f;
            row.addView(v[i], p);
        }
        home.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    View chip(android.graphics.drawable.Drawable icon, String label, String desc, final View.OnClickListener l) {
        LinearLayout ch = new LinearLayout(this);
        ch.setGravity(Gravity.CENTER_VERTICAL);
        ch.setBackground(Ui.glass(22, false));
        ch.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(16), Ui.dp(8));
        ImageView ic = new ImageView(this);
        ic.setImageDrawable(icon);
        ch.addView(ic, new LinearLayout.LayoutParams(Ui.dp(30), Ui.dp(30)));
        TextView t = Ui.tv(this, label, 14, Ui.WHITE, false);
        t.setPadding(Ui.dp(10), 0, 0, 0);
        ch.addView(t);
        ch.setContentDescription(desc);
        ch.setFocusable(true);
        ch.setOnClickListener(v -> { Ui.tick(v); l.onClick(v); });
        Ui.press(ch);
        return ch;
    }

    HorizontalScrollView chipRow(List<View> chips) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setClipToPadding(false);
        hs.setPadding(Ui.dp(16), 0, Ui.dp(16), 0);
        LinearLayout lin = new LinearLayout(this);
        for (View c : chips) lin.addView(c, lpm(-2, -2, 0, 0, 10, 0));
        hs.addView(lin);
        return hs;
    }

    /** Root of a removable SD card (or other secondary volume) if one is mounted and readable. */
    File sdRoot() {
        try {
            File[] dirs = getExternalFilesDirs(null);
            if (dirs == null) return null;
            for (int i = 1; i < dirs.length; i++) {
                if (dirs[i] == null) continue;
                String p = dirs[i].getAbsolutePath();
                int k = p.indexOf("/Android/data");
                if (k > 0) {
                    File r = new File(p.substring(0, k));
                    if (r.isDirectory() && r.canRead()) return r;
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** Plays every indexed audio file (up to 400) in random order in the built-in player. */
    void shuffleMusic() {
        Indexer ix = Indexer.I;
        if (!ix.ready) { Ui.toast(this, "Still scanning — try again in a moment"); return; }
        List<Entry> songs = ix.cats.get(2);
        if (songs.isEmpty()) { Ui.toast(this, "No music found on this device"); return; }
        ArrayList<String> ps = new ArrayList<>();
        for (Entry x : songs) { ps.add(x.f.getAbsolutePath()); if (ps.size() >= 400) break; }
        java.util.Collections.shuffle(ps);
        Intent i = new Intent(this, ViewerActivity.class);
        i.putStringArrayListExtra("paths", ps);
        i.putExtra("index", 0);
        i.putExtra("shuffle", true);
        startActivity(i);
    }

    // ---------------- SETTINGS ----------------
    View row(int glyph, String title, String sub, View right, View.OnClickListener l) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setBackground(Ui.glass(18, false));
        r.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(14), Ui.dp(12));
        FrameLayout ic = new FrameLayout(this);
        ic.setBackground(Ui.accentPill(12));
        ImageView g = new ImageView(this);
        g.setImageDrawable(Glyphs.get(glyph, Ui.WHITE));
        ic.addView(g, new FrameLayout.LayoutParams(Ui.dp(22), Ui.dp(22), Gravity.CENTER));
        r.addView(ic, new LinearLayout.LayoutParams(Ui.dp(40), Ui.dp(40)));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(Ui.dp(14), 0, Ui.dp(8), 0);
        tx.addView(Ui.tv(this, title, 15, Ui.WHITE, false));
        if (sub != null) {
            TextView s = Ui.tv(this, sub, 12, Ui.SUB, false);
            s.setPadding(0, Ui.dp(3), 0, 0);
            tx.addView(s);
        }
        r.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
        if (right != null) r.addView(right);
        if (l != null) { r.setOnClickListener(l); Ui.press(r); }
        return r;
    }

    Switch sw(final String key, boolean def, final Runnable onChange) {
        Switch s = new Switch(this);
        s.setChecked(Ui.bool(key, def));
        s.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{Ui.accent, Color.rgb(200, 205, 215)}));
        s.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{Color.argb(120, Color.red(Ui.accent), Color.green(Ui.accent), Color.blue(Ui.accent)), Color.argb(90, 255, 255, 255)}));
        s.setOnCheckedChangeListener((b, on) -> { Ui.set(key, on); if (onChange != null) onChange.run(); });
        return s;
    }

    View switchRow(int glyph, String title, String sub, String key, boolean def, Runnable onChange) {
        final Switch s = sw(key, def, onChange);
        return row(glyph, title, sub, s, v -> s.toggle());
    }

    String subKey;

    View chevron() {
        ImageView c = new ImageView(this);
        c.setImageDrawable(Glyphs.get(Glyphs.NEXT, Ui.SUB));
        c.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(20), Ui.dp(20)));
        return c;
    }

    void openSub(String key) {
        subKey = key;
        buildSettings();
        settingsScroll.scrollTo(0, 0);
    }

    void closeSub() {
        subKey = null;
        buildSettings();
        settingsScroll.scrollTo(0, 0);
    }

    View subHeader(String title) {
        LinearLayout hd = new LinearLayout(this);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        hd.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8));
        ImageView back = Ui.iconBtn(this, Glyphs.BACK, Ui.WHITE);
        back.setContentDescription("Back to settings");
        back.setOnClickListener(v -> closeSub());
        hd.addView(back, new LinearLayout.LayoutParams(Ui.dp(48), Ui.dp(48)));
        hd.addView(Ui.tv(this, title, 26, Ui.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        return hd;
    }

    void add(View v) { settings.addView(v, lpm(-1, -2, 16, 0, 16, 8)); }

    void buildSettings() {
        settings.removeAllViews();
        if (subKey == null) buildSettingsMain(); else buildSettingsSub(subKey);
    }

    void buildSettingsMain() {
        TextView t = Ui.tv(this, "Settings", 32, Ui.WHITE, true);
        t.setPadding(Ui.dp(20), Ui.dp(12), 0, Ui.dp(12));
        settings.addView(t);
        add(row(Glyphs.TUNE, "Appearance", Ui.THEMES[Ui.theme] + " • " + (Ui.light ? "Light" : "Dark"), chevron(), v -> openSub("appearance")));
        add(row(Glyphs.FILES, "Browsing", "Hidden files, sorting, start folder", chevron(), v -> openSub("browsing")));
        add(row(Glyphs.PLAY, "Music and video", "Resume, background playback", chevron(), v -> openSub("media")));
        add(row(Glyphs.FOLDER, "Storage and Recycle Bin", hasAccess() ? "All files access allowed" : "Access needed", chevron(), v -> openSub("storage")));
        add(row(Glyphs.CHECK, "Security", (Ui.bool("applock_on", false) ? "App Lock on" : "App Lock off") + " • Vault " + (Vault.hasPin(this) ? "ready" : "not set up"), chevron(), v -> openSub("security")));
        add(row(Glyphs.SHARE, "Transfer and backup", "Wi-Fi transfer, export and import settings", chevron(), v -> openSub("backup")));
        add(row(Glyphs.INFO, "About and privacy", versionName(), chevron(), v -> openSub("about")));
    }

    void buildSettingsSub(String key) {
        switch (key) {
            case "appearance": {
                settings.addView(subHeader("Appearance"));
                add(row(Glyphs.TUNE, "Theme", Ui.THEMES[Ui.theme], null, v -> themeDialog()));
                add(switchRow(Glyphs.TUNE, "Light mode", "Switches panels, text, and system dialogs for a bright background", "light", false, () -> { Ui.setLight(Ui.bool("light", false), true); recreate(); }));
                add(switchRow(Glyphs.IMAGE, "Background blur", "Soft frosted glass look (Android 12+)", "blur", true, () -> bg.applyBlur()));
                add(switchRow(Glyphs.TUNE, "Haptic feedback", "Gentle vibration on selection", "haptic", true, null));
                break;
            }
            case "browsing": {
                settings.addView(subHeader("Browsing"));
                add(switchRow(Glyphs.FILE, "Show hidden files", "Files and folders starting with a dot", "hidden", false, () -> filesView.reload()));
                add(switchRow(Glyphs.OPEN, "Open files inside the app", "Built-in viewer for photos, video, audio, PDF and text", "inapp", true, null));
                add(switchRow(Glyphs.TRASH, "Confirm before deleting", null, "confirm", true, null));
                add(row(Glyphs.SORT, "Default sort", null, null, v -> filesView.sortDialog()));
                final String defFolder = Ui.sp.getString("default_folder", null);
                add(row(Glyphs.FOLDER, "Default start folder", defFolder != null ? defFolder : "Internal storage root (open a folder, then ⋮ → Set as default start folder)", null, v -> {
                    if (defFolder == null) { Ui.toast(this, "Open a folder, then use ⋮ → Set as default start folder"); return; }
                    new AlertDialog.Builder(this).setTitle("Reset default folder?").setMessage("Will start from Internal storage root again.")
                            .setNegativeButton("Cancel", null)
                            .setPositiveButton("Reset", (d, w) -> { Ui.sp.edit().remove("default_folder").apply(); buildSettings(); }).show();
                }));
                break;
            }
            case "media": {
                settings.addView(subHeader("Music and video"));
                add(switchRow(Glyphs.PLAY, "Resume videos where you left off", "Remembers where you stopped each video", "resume_video", true, null));
                add(switchRow(Glyphs.AUDIO, "Keep music playing in the background", "Music keeps playing when you leave the app or turn the screen off. Turn off to pause when the player is left.", "bg_audio", true, null));
                break;
            }
            case "storage": {
                settings.addView(subHeader("Storage and Recycle Bin"));
                add(row(Glyphs.FOLDER, "All files access", hasAccess() ? "Allowed" : "Not allowed — tap to fix", null, v -> { if (!hasAccess()) showStorageAccess(); }));
                add(row(Glyphs.SEARCH, "Rescan storage", "Refresh category counts, sizes and search", null, v -> { Indexer.I.dirty = true; startIndex(); Ui.toast(this, "Scanning…"); }));
                add(row(Glyphs.FOLDER, "Browse other storage", "SD card, USB, or a cloud app's documents (read-only import)", null, v -> openOtherStorage()));
                settings.addView(section("Recycle Bin"));
                add(switchRow(Glyphs.TRASH, "Use Recycle Bin", "Deleted items are kept here before being removed for good", "recyclebin", true, null));
                final int binCount = RecycleBin.list(this).size();
                final int days = Ui.sp.getInt("recyclebin_days", 30);
                add(row(Glyphs.TRASH, "Open Recycle Bin", binCount == 0 ? "Empty" : binCount + (binCount == 1 ? " item" : " items"), null, v -> showRecycleBin()));
                add(row(Glyphs.TRASH, "Keep deleted items for", days + " days", null, v -> retentionDialog()));
                break;
            }
            case "security": {
                settings.addView(subHeader("Security"));
                settings.addView(section("App Lock"));
                add(row(Glyphs.TUNE, AppLock.hasPin(this) ? "Change App Lock PIN" : "Set App Lock PIN", "Biometric unlock is offered first on supported devices", null, v -> setAppLockPin()));
                add(switchRow(Glyphs.TUNE, "Require unlock to open app", "Checked every time the app returns to the foreground", "applock_on", false, () -> {
                    if (Ui.bool("applock_on", false) && !AppLock.hasPin(this)) { Ui.toast(this, "Set an App Lock PIN first"); Ui.set("applock_on", false); buildSettings(); }
                }));
                settings.addView(section("Vault"));
                add(row(Glyphs.TUNE, Vault.hasPin(this) ? "Change Vault PIN" : "Set Vault PIN", "AES-256 encrypted, key held in Android Keystore", null, v -> setVaultPin()));
                final int vc = Vault.list(this).size();
                add(row(Glyphs.FOLDER, "Open Vault", vc + (vc == 1 ? " item" : " items"), null, v -> promptVaultPin()));
                break;
            }
            case "backup": {
                settings.addView(subHeader("Transfer and backup"));
                add(row(Glyphs.SHARE, "Receive via Wi-Fi", "Both devices must be on the same Wi-Fi network. To send, select files in Browse, then ⋮ → Send via Wi-Fi.", null, v -> receiveViaWifi()));
                add(row(Glyphs.SHARE, "Export settings", "Save theme and preferences to a file you can share or keep", null, v -> exportSettings()));
                add(row(Glyphs.OPEN, "Import settings", "Restore from a previously exported file", null, v -> importSettingsPick()));
                break;
            }
            case "about": {
                settings.addView(subHeader("About and privacy"));
                add(row(Glyphs.INFO, "Privacy and connectivity audit", "Review app permissions and what offline mode means", null, v -> showPrivacyAudit()));
                add(row(Glyphs.INFO, "About Liquid Glass Files", versionName(), null, v -> showAbout()));
                break;
            }
            default:
                subKey = null;
                buildSettingsMain();
        }
    }

    // ---------------- STORAGE ANALYZER ----------------
    void openStorageAnalyzer() {
        if (!hasAccess()) { showStorageAccess(); return; }
        Ui.toast(this, "Analyzing storage…");
        io.execute(() -> {
            File rootDir = Environment.getExternalStorageDirectory();
            long[] totals = new long[6]; // images, video, audio, documents, archives, other
            long[] counts = new long[6];
            List<File> largest = new ArrayList<>();
            long[] totalBytes = {0};
            int[] totalFiles = {0};
            scanStorage(rootDir, totals, counts, largest, totalBytes, totalFiles, 0);
            largest.sort((a, b) -> Long.compare(b.length(), a.length()));
            String[] labels = {"Images", "Videos", "Audio", "Documents", "Archives", "Other files"};
            StringBuilder report = new StringBuilder();
            report.append("Scanned internal shared storage\n\nFiles: ").append(totalFiles[0])
                    .append("\nEstimated file size total: ").append(formatBytes(totalBytes[0])).append("\n\nBy category:\n");
            for (int i = 0; i < labels.length; i++) report.append(labels[i]).append(": ").append(counts[i]).append(" files • ").append(formatBytes(totals[i])).append("\n");
            report.append("\nLargest files found (up to 15):\n");
            int n = Math.min(15, largest.size());
            for (int i = 0; i < n; i++) report.append("\n").append(formatBytes(largest.get(i).length())).append(" — ").append(largest.get(i).getAbsolutePath());
            if (n == 0) report.append("None found.");
            final String result = report.toString();
            runOnUiThread(() -> new AlertDialog.Builder(this).setTitle("Storage analysis")
                    .setMessage(result).setPositiveButton("Done", null)
                    .setNeutralButton("Share report", (d, w) -> {
                        try {
                            Intent share = new Intent(Intent.ACTION_SEND);
                            share.setType("text/plain"); share.putExtra(Intent.EXTRA_TEXT, result);
                            startActivity(Intent.createChooser(share, "Share storage report"));
                        } catch (Exception ex) { Ui.toast(this, "Unable to share report"); }
                    }).show());
        });
    }

    void scanStorage(File f, long[] totals, long[] counts, List<File> largest, long[] totalBytes, int[] totalFiles, int depth) {
        if (f == null || depth > 60) return;
        try {
            if (f.isDirectory()) {
                File[] children = f.listFiles();
                if (children != null) for (File child : children) scanStorage(child, totals, counts, largest, totalBytes, totalFiles, depth + 1);
                return;
            }
            if (!f.isFile() || !f.canRead()) return;
            long size = f.length(); totalBytes[0] += size; totalFiles[0]++;
            String name = f.getName().toLowerCase(java.util.Locale.ROOT);
            int k = name.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|heic|heif)$") ? 0
                    : name.matches(".*\\.(mp4|mkv|mov|webm|3gp|avi|m4v)$") ? 1
                    : name.matches(".*\\.(mp3|m4a|aac|wav|ogg|flac|opus|wma)$") ? 2
                    : name.matches(".*\\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|rtf|odt|ods|odp)$") ? 3
                    : name.matches(".*\\.(zip|7z|rar|tar|gz|bz2|xz)$") ? 4 : 5;
            totals[k] += size; counts[k]++;
            // Bound memory on devices with very large storage; this report is an estimate.
            if (largest.size() < 1000) largest.add(f);
            else {
                int smallest = 0;
                for (int i = 1; i < largest.size(); i++) if (largest.get(i).length() < largest.get(smallest).length()) smallest = i;
                if (size > largest.get(smallest).length()) largest.set(smallest, f);
            }
        } catch (SecurityException ignored) { }
    }

    String formatBytes(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024) return String.format(java.util.Locale.getDefault(), "%.1f KB", b / 1024.0);
        if (b < 1024L * 1024 * 1024) return String.format(java.util.Locale.getDefault(), "%.1f MB", b / (1024.0 * 1024));
        return String.format(java.util.Locale.getDefault(), "%.2f GB", b / (1024.0 * 1024 * 1024));
    }

    void showPrivacyAudit() {
        String report = "OFFLINE & PRIVACY REVIEW\n\n"
                + "• File browsing and built-in viewing operate on local files.\n"
                + "• No account or cloud-sync feature is provided by this app.\n"
                + "• Wi-Fi transfer is a local-network feature; it requires network permission and both devices on a reachable network. It is not internet cloud storage.\n"
                + "• All-files access gives broad access to shared storage. Disable it in Android settings when you no longer need it.\n"
                + "• App Lock protects opening this app; Vault behavior and its limits are described separately in the Vault screen.\n"
                + "• Settings export creates a readable JSON file. Do not share it if it contains preferences you consider private.\n\n"
                + "This is an in-app permission/feature summary, not an independent network-traffic audit. To verify network behavior, inspect the source and test traffic on the device.";
        new AlertDialog.Builder(this).setTitle("Privacy and connectivity audit")
                .setMessage(report).setPositiveButton("OK", null).show();
    }

    // ---------------- APP LOCK ----------------
    void setAppLockPin() {
        final EditText in = pinField();
        new AlertDialog.Builder(this).setTitle(AppLock.hasPin(this) ? "Change App Lock PIN" : "Set App Lock PIN")
                .setView(wrapField(in)).setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> {
                    String p = in.getText().toString().trim();
                    if (p.length() < 4) { Ui.toast(this, "Use at least 4 digits"); return; }
                    AppLock.setPin(this, p);
                    Ui.toast(this, "App Lock PIN saved");
                    buildSettings();
                }).show();
    }

    /** Blocking, non-cancelable lock screen shown on launch/resume when App Lock is on. */
    void showAppLock() {
        final android.app.Dialog dlg = new android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dlg.setCancelable(false);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.bg);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(Ui.dp(32), 0, Ui.dp(32), 0);
        col.addView(Ui.tv(this, "Liquid Glass Files is locked", 18, Ui.WHITE, true), lpm(-2, -2, 0, 0, 0, 16));
        final EditText in = pinField();
        col.addView(wrapField(in), new LinearLayout.LayoutParams(-1, -2));
        TextView unlockBtn = Ui.tv(this, "Unlock", 16, Ui.accent, true);
        unlockBtn.setGravity(Gravity.CENTER);
        unlockBtn.setBackground(Ui.glass(18, false));
        unlockBtn.setPadding(0, Ui.dp(14), 0, Ui.dp(14));
        Ui.press(unlockBtn);
        unlockBtn.setOnClickListener(v -> {
            if (AppLock.checkPin(this, in.getText().toString().trim())) { unlocked = true; dlg.dismiss(); }
            else Ui.toast(this, "Wrong PIN");
        });
        col.addView(unlockBtn, lpm(-1, -2, 0, 20, 0, 0));
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        dlg.setContentView(root);
        dlg.setOnKeyListener((d, keyCode, event) -> keyCode == android.view.KeyEvent.KEYCODE_BACK);
        dlg.show();
        if (Build.VERSION.SDK_INT >= 28) tryBiometric(dlg);
    }

    void tryBiometric(final android.app.Dialog dlg) {
        try {
            android.hardware.biometrics.BiometricPrompt prompt = new android.hardware.biometrics.BiometricPrompt.Builder(this)
                    .setTitle("Unlock Liquid Glass Files")
                    .setNegativeButton("Use PIN", getMainExecutor(), (d, w) -> { })
                    .build();
            prompt.authenticate(new android.os.CancellationSignal(), getMainExecutor(),
                    new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                        @Override public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult result) {
                            unlocked = true;
                            dlg.dismiss();
                        }
                    });
        } catch (Exception ignored) { } // no enrolled biometric / unsupported — PIN field stays usable
    }

    // ---------------- DUPLICATE FINDER ----------------
    void openDuplicates() {
        if (!Indexer.I.ready) { Ui.toast(this, "Still scanning storage — try again in a moment"); return; }
        Ui.toast(this, "Scanning for duplicates…");
        io.execute(() -> {
            final List<DupFinder.Group> groups = DupFinder.find(Indexer.I.all);
            runOnUiThread(() -> { buildDuplicates(groups); showOverlay(dupScroll); });
        });
    }

    void buildDuplicates(final List<DupFinder.Group> groups) {
        dup.removeAllViews();
        LinearLayout hd = new LinearLayout(this);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        hd.setPadding(Ui.dp(8), 0, Ui.dp(8), 0);
        ImageView bk = Ui.iconBtn(this, Glyphs.BACK, Ui.WHITE);
        bk.setContentDescription("Back");
        bk.setOnClickListener(v -> closeOverlay());
        hd.addView(bk, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        hd.addView(Ui.tv(this, "Duplicate Files", 22, Ui.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        dup.addView(hd, new LinearLayout.LayoutParams(-1, Ui.dp(56)));

        if (groups.isEmpty()) {
            TextView w = Ui.tv(this, "No exact duplicates found", 14, Ui.SUB, false);
            w.setPadding(Ui.dp(20), Ui.dp(20), 0, 0);
            dup.addView(w);
            return;
        }
        long reclaimable = 0;
        for (DupFinder.Group g : groups) reclaimable += g.size * (g.files.size() - 1);
        TextView sum = Ui.tv(this, groups.size() + " duplicate group" + (groups.size() == 1 ? "" : "s") + " — up to " + Ui.size(reclaimable) + " reclaimable", 12, Ui.SUB, false);
        sum.setPadding(Ui.dp(20), Ui.dp(2), Ui.dp(20), Ui.dp(6));
        dup.addView(sum);

        TextView bulk = Ui.tv(this, "Move all but the oldest copy to Recycle Bin", 14, Ui.accent, true);
        bulk.setBackground(Ui.glass(18, false));
        bulk.setPadding(Ui.dp(16), Ui.dp(12), Ui.dp(16), Ui.dp(12));
        bulk.setGravity(Gravity.CENTER);
        Ui.press(bulk);
        bulk.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Move duplicates to Recycle Bin?")
                .setMessage("Keeps the oldest file in each group, moves the rest to Recycle Bin — they can still be restored from there.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Move", (d, w) -> {
                    List<File> victims = new ArrayList<>();
                    for (DupFinder.Group g : groups) {
                        File keep = g.files.get(0);
                        for (File f : g.files) if (f.lastModified() < keep.lastModified()) keep = f;
                        for (File f : g.files) if (f != keep) victims.add(f);
                    }
                    RecycleBin.moveToBin(this, victims, msg -> { Ui.toast(this, msg); afterOps(); openDuplicates(); });
                }).show());
        dup.addView(bulk, lpm(-1, -2, 16, 4, 16, 14));

        for (final DupFinder.Group g : groups) {
            TextView gh = Ui.tv(this, g.files.size() + " copies • " + Ui.size(g.size) + " each", 12, Ui.SUB, true);
            gh.setPadding(Ui.dp(20), Ui.dp(10), Ui.dp(20), Ui.dp(2));
            dup.addView(gh);
            for (final File f : g.files) {
                Entry e = new Entry(f);
                View rv = Rows.build(this);
                Rows.H h = (Rows.H) rv.getTag();
                Rows.bind(h, e, false, false, f.getParentFile() == null ? "" : f.getParentFile().getAbsolutePath());
                View.OnClickListener act = v -> new AlertDialog.Builder(this).setTitle("Move to Recycle Bin?").setMessage(f.getAbsolutePath())
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Move", (d, w) -> RecycleBin.moveToBin(this, java.util.Collections.singletonList(f), msg -> { Ui.toast(this, msg); afterOps(); openDuplicates(); }))
                        .show();
                rv.setOnClickListener(act);
                h.more.setOnClickListener(act);
                dup.addView(rv, new LinearLayout.LayoutParams(-1, -2));
            }
        }
    }

    void openCleanup() {
        if (!Indexer.I.ready) { Ui.toast(this, "Still scanning storage — try again in a moment"); return; }
        Ui.toast(this, "Scanning for empty folders…");
        io.execute(() -> {
            final List<File> empties = new ArrayList<>();
            for (Entry e : Indexer.I.all) {
                if (e.dir) { File[] kids = e.f.listFiles(); if (kids == null || kids.length == 0) empties.add(e.f); }
            }
            runOnUiThread(() -> { buildEmptyFolders(empties); showOverlay(dupScroll); });
        });
    }

    void buildEmptyFolders(final List<File> empties) {
        dup.removeAllViews();
        LinearLayout hd = new LinearLayout(this);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        hd.setPadding(Ui.dp(8), 0, Ui.dp(8), 0);
        ImageView bk = Ui.iconBtn(this, Glyphs.BACK, Ui.WHITE);
        bk.setContentDescription("Back");
        bk.setOnClickListener(v -> closeOverlay());
        hd.addView(bk, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        hd.addView(Ui.tv(this, "Empty Folders", 22, Ui.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        dup.addView(hd, new LinearLayout.LayoutParams(-1, Ui.dp(56)));

        if (empties.isEmpty()) {
            TextView w = Ui.tv(this, "No empty folders found", 14, Ui.SUB, false);
            w.setPadding(Ui.dp(20), Ui.dp(20), 0, 0);
            dup.addView(w);
            return;
        }
        TextView sum = Ui.tv(this, empties.size() + " empty folder" + (empties.size() == 1 ? "" : "s"), 12, Ui.SUB, false);
        sum.setPadding(Ui.dp(20), Ui.dp(2), Ui.dp(20), Ui.dp(6));
        dup.addView(sum);

        TextView bulk = Ui.tv(this, "Delete all empty folders", 14, Ui.accent, true);
        bulk.setBackground(Ui.glass(18, false));
        bulk.setPadding(Ui.dp(16), Ui.dp(12), Ui.dp(16), Ui.dp(12));
        bulk.setGravity(Gravity.CENTER);
        Ui.press(bulk);
        bulk.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Delete " + empties.size() + " empty folders?")
                .setMessage("They contain nothing, so this goes straight to Recycle Bin, same as any other delete.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> RecycleBin.moveToBin(this, empties, msg -> { Ui.toast(this, msg); afterOps(); openCleanup(); }))
                .show());
        dup.addView(bulk, lpm(-1, -2, 16, 4, 16, 14));

        for (final File f : empties) {
            Entry e = new Entry(f);
            View rv = Rows.build(this);
            Rows.H h = (Rows.H) rv.getTag();
            Rows.bind(h, e, false, false, f.getParentFile() == null ? "" : f.getParentFile().getAbsolutePath());
            View.OnClickListener act = v -> RecycleBin.moveToBin(this, java.util.Collections.singletonList(f), msg -> { Ui.toast(this, msg); afterOps(); openCleanup(); });
            rv.setOnClickListener(act);
            h.more.setOnClickListener(act);
            dup.addView(rv, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    // ---------------- VAULT ----------------
    EditText pinField() {
        EditText in = new EditText(this);
        in.setSingleLine(true);
        in.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        in.setHint("4+ digit PIN");
        return in;
    }

    View wrapField(View v) {
        FrameLayout f = new FrameLayout(this);
        f.setPadding(Ui.dp(22), Ui.dp(8), Ui.dp(22), 0);
        f.addView(v, new FrameLayout.LayoutParams(-1, -2));
        return f;
    }

    void setVaultPin() {
        final EditText in = pinField();
        new AlertDialog.Builder(this).setTitle(Vault.hasPin(this) ? "Change Vault PIN" : "Set Vault PIN")
                .setView(wrapField(in)).setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> {
                    String p = in.getText().toString().trim();
                    if (p.length() < 4) { Ui.toast(this, "Use at least 4 digits"); return; }
                    Vault.setPin(this, p);
                    Ui.toast(this, "Vault PIN saved");
                    buildSettings();
                }).show();
    }

    void promptVaultPin() {
        if (!Vault.hasPin(this)) { Ui.toast(this, "Set a Vault PIN first"); return; }
        final EditText in = pinField();
        new AlertDialog.Builder(this).setTitle("Enter Vault PIN")
                .setView(wrapField(in)).setNegativeButton("Cancel", null)
                .setPositiveButton("Unlock", (d, w) -> {
                    if (Vault.checkPin(this, in.getText().toString().trim())) { buildVault(); showOverlay(vaultScroll); }
                    else Ui.toast(this, "Wrong PIN");
                }).show();
    }

    void buildVault() {
        vault.removeAllViews();
        LinearLayout hd = new LinearLayout(this);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        hd.setPadding(Ui.dp(8), 0, Ui.dp(8), 0);
        ImageView bk = Ui.iconBtn(this, Glyphs.BACK, Ui.WHITE);
        bk.setContentDescription("Back");
        bk.setOnClickListener(v -> closeOverlay());
        hd.addView(bk, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        hd.addView(Ui.tv(this, "Vault", 24, Ui.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        hd.addView(new View(this), new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        vault.addView(hd, new LinearLayout.LayoutParams(-1, Ui.dp(56)));

        TextView note = Ui.tv(this, "Encrypted with AES-256 (key stored in Android's hardware Keystore, not derived from your PIN). The PIN gates this screen; the encryption protects the file bytes even if someone pulls them off the device directly.", 12, Ui.SUB, false);
        note.setPadding(Ui.dp(20), Ui.dp(2), Ui.dp(20), Ui.dp(10));
        vault.addView(note);

        List<Vault.Item> items = Vault.list(this);
        if (items.isEmpty()) {
            TextView w = Ui.tv(this, "Vault is empty", 14, Ui.SUB, false);
            w.setPadding(Ui.dp(20), Ui.dp(20), 0, 0);
            vault.addView(w);
        } else {
            for (final Vault.Item it : items) {
                Entry e = new Entry(it.file);
                View rv = Rows.build(this);
                Rows.H h = (Rows.H) rv.getTag();
                Rows.bind(h, e, false, false, "from " + it.originalParent.getName());
                rv.setOnClickListener(v -> vaultItemMenu(it));
                h.more.setOnClickListener(v -> vaultItemMenu(it));
                vault.addView(rv, new LinearLayout.LayoutParams(-1, -2));
            }
        }
    }

    void vaultItemMenu(final Vault.Item it) {
        String[] opts = {"Move out of Vault", "Delete forever"};
        new AlertDialog.Builder(this).setTitle(it.file.getName()).setItems(opts, (d, w) -> {
            if (w == 0) Vault.restoreOut(this, it, msg -> { Ui.toast(this, msg); afterOps(); buildVault(); });
            else new AlertDialog.Builder(this).setTitle("Delete forever?").setMessage("This can't be undone.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete", (d2, w2) -> Vault.deleteForever(this, it, msg -> { Ui.toast(this, msg); buildVault(); }))
                    .show();
        }).show();
    }

    // ---------------- WI-FI TRANSFER ----------------
    void receiveViaWifi() {
        final AlertDialog waitDlg = new AlertDialog.Builder(this).setTitle("Waiting for sender…")
                .setMessage("Starting…")
                .setNegativeButton("Cancel", (d, w) -> LanTransfer.cancel())
                .setCancelable(false).show();
        File destDir = new File(Environment.getExternalStorageDirectory(), "Download/LanReceived");
        LanTransfer.receive(destDir, new LanTransfer.Listener() {
            @Override public void onWaiting(String ip, int port) {
                runOnUiThread(() -> waitDlg.setMessage("On the sending device, use ⋮ → Send via Wi-Fi… and enter:\n\n" + ip + ":" + port + "\n\nBoth devices must be on the same Wi-Fi network."));
            }
            @Override public void onIncoming(String fromIp, int count, long totalBytes, Runnable accept, Runnable reject) {
                runOnUiThread(() -> {
                    if (waitDlg.isShowing()) waitDlg.dismiss();
                    new AlertDialog.Builder(MainActivity.this).setTitle("Incoming transfer")
                            .setMessage("From " + fromIp + "\n" + count + " file" + (count == 1 ? "" : "s") + ", " + Ui.size(totalBytes))
                            .setCancelable(false)
                            .setNegativeButton("Decline", (d, w) -> reject.run())
                            .setPositiveButton("Accept", (d, w) -> { accept.run(); busy(true); progress("Receiving…"); })
                            .show();
                });
            }
            @Override public void onFileStart(int idx, int total, String name) { runOnUiThread(() -> progress("Receiving " + idx + " of " + total + ": " + name)); }
            @Override public void onDone(String msg) { runOnUiThread(() -> { busy(false); Ui.toast(MainActivity.this, msg); afterOps(); }); }
            @Override public void onError(String msg) {
                runOnUiThread(() -> { busy(false); if (waitDlg.isShowing()) waitDlg.dismiss(); Ui.toast(MainActivity.this, msg); });
            }
        });
    }

    void sendViaWifi(final List<File> files) {
        if (files.isEmpty()) return;
        final EditText in = new EditText(this);
        in.setHint("e.g. 192.168.1.42");
        in.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Send via Wi-Fi")
                .setMessage("Enter the receiving device's IP address (shown on its \"Receive via Wi-Fi\" screen). Both devices must be on the same Wi-Fi network.")
                .setView(wrapField(in)).setNegativeButton("Cancel", null)
                .setPositiveButton("Send", (d, w) -> {
                    String raw = in.getText().toString().trim();
                    if (raw.isEmpty()) return;
                    String ip = raw.contains(":") ? raw.substring(0, raw.indexOf(':')) : raw;
                    busy(true);
                    progress("Connecting…");
                    LanTransfer.send(ip, files, new LanTransfer.Listener() {
                        @Override public void onWaiting(String ip2, int port) { }
                        @Override public void onIncoming(String fromIp, int count, long totalBytes, Runnable accept, Runnable reject) { }
                        @Override public void onFileStart(int idx, int total, String name) { runOnUiThread(() -> progress("Sending " + idx + " of " + total + ": " + name)); }
                        @Override public void onDone(String msg) { runOnUiThread(() -> { busy(false); Ui.toast(MainActivity.this, msg); }); }
                        @Override public void onError(String msg) { runOnUiThread(() -> { busy(false); Ui.toast(MainActivity.this, msg); }); }
                    });
                }).show();
    }

    // ---------------- OTHER STORAGE (SAF, read-only import) ----------------
    void openOtherStorage() {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            startActivityForResult(i, REQ_SAF_TREE);
        } catch (Exception ex) { Ui.toast(this, "Can't open the storage picker on this device"); }
    }

    @Override protected void onActivityResult(int rq, int rc, Intent data) {
        super.onActivityResult(rq, rc, data);
        if (rc != RESULT_OK || data == null) return;
        if (rq == REQ_SAF_TREE) {
            Uri tree = data.getData();
            if (tree == null) return;
            try { getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            safTree = tree;
            String rootDoc = DocumentsContract.getTreeDocumentId(tree);
            showSafLevel(tree, DocumentsContract.buildDocumentUriUsingTree(tree, rootDoc), "Other storage");
        } else if (rq == REQ_IMPORT_SETTINGS) {
            Uri file = data.getData();
            if (file != null) applyImportedSettings(file);
        }
    }

    void showSafLevel(final Uri tree, final Uri docUri, final String title) {
        Ui.toast(this, "Loading…");
        io.execute(() -> {
            final List<String[]> rows = new ArrayList<>(); // [docId, name, "1" dir / "0" file]
            try {
                Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(docUri));
                Cursor c = getContentResolver().query(children, new String[]{
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null);
                if (c != null) {
                    while (c.moveToNext()) rows.add(new String[]{c.getString(0), c.getString(1), DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2)) ? "1" : "0"});
                    c.close();
                }
            } catch (Exception ignored) { }
            runOnUiThread(() -> {
                if (rows.isEmpty()) { Ui.toast(this, "Nothing here, or can't read this location"); return; }
                String[] names = new String[rows.size()];
                for (int i = 0; i < rows.size(); i++) names[i] = (rows.get(i)[2].equals("1") ? "📁 " : "") + rows.get(i)[1];
                new AlertDialog.Builder(this).setTitle(title).setItems(names, (d, w) -> {
                    String[] r = rows.get(w);
                    Uri childUri = DocumentsContract.buildDocumentUriUsingTree(tree, r[0]);
                    if (r[2].equals("1")) showSafLevel(tree, childUri, r[1]);
                    else importSafDoc(childUri, r[1]);
                }).setNegativeButton("Close", null).show();
            });
        });
    }

    void importSafDoc(final Uri doc, final String name) {
        busy(true);
        io.execute(() -> {
            String msg;
            try {
                File dest = FileOps.unique(new File(Environment.getExternalStorageDirectory(), "Download"), name);
                try (InputStream in = getContentResolver().openInputStream(doc); OutputStream out = new FileOutputStream(dest)) {
                    byte[] buf = new byte[65536];
                    int n;
                    while (in != null && (n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                msg = "Imported to Download/" + dest.getName();
            } catch (Exception ex) { msg = "Import failed: " + ex.getMessage(); }
            final String m = msg;
            runOnUiThread(() -> { busy(false); Ui.toast(this, m); afterOps(); });
        });
    }

    // ---------------- SETTINGS BACKUP ----------------
    void exportSettings() {
        io.execute(() -> {
            String msg;
            try {
                JSONObject o = new JSONObject();
                for (Map.Entry<String, ?> e : Ui.sp.getAll().entrySet()) o.put(e.getKey(), e.getValue());
                File dest = FileOps.unique(new File(Environment.getExternalStorageDirectory(), "Download"), "liquidglass_settings.json");
                try (OutputStream out = new FileOutputStream(dest)) { out.write(o.toString(2).getBytes()); }
                msg = "Saved to Download/" + dest.getName();
                final File fd = dest;
                final String exportMessage = msg;
                runOnUiThread(() -> {
                    Ui.toast(this, exportMessage);
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("application/json");
                        i.putExtra(Intent.EXTRA_STREAM, FileOps.uri(this, fd));
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(i, "Share settings file"));
                    } catch (Exception ignored) { }
                });
                return;
            } catch (Exception ex) { msg = "Export failed: " + ex.getMessage(); }
            final String m = msg;
            runOnUiThread(() -> Ui.toast(this, m));
        });
    }

    void importSettingsPick() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("*/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, "Choose settings file"), REQ_IMPORT_SETTINGS);
        } catch (Exception ex) { Ui.toast(this, "Can't open file picker"); }
    }

    void applyImportedSettings(final Uri file) {
        io.execute(() -> {
            String msg;
            try {
                StringBuilder sb = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(file); BufferedReader r = new BufferedReader(new InputStreamReader(in))) {
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                }
                JSONObject o = new JSONObject(sb.toString());
                SharedPreferences.Editor ed = Ui.sp.edit();
                java.util.Iterator<String> keys = o.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    Object v = o.get(k);
                    if (v instanceof Boolean) ed.putBoolean(k, (Boolean) v);
                    else if (v instanceof Integer) ed.putInt(k, (Integer) v);
                    else if (v instanceof Long) ed.putInt(k, (int) (long) (Long) v);
                    else if (v instanceof String) ed.putString(k, (String) v);
                }
                ed.apply();
                msg = "Settings restored";
            } catch (Exception ex) { msg = "Import failed: " + ex.getMessage(); }
            final String m = msg;
            runOnUiThread(() -> {
                Ui.toast(this, m);
                Ui.setTheme(Ui.sp.getInt("theme", 0), false);
                recolor();
                buildSettings();
            });
        });
    }

    // ---------------- LARGEST FILES ----------------
    void openLargest() {
        Indexer ix = Indexer.I;
        if (!ix.ready) { Ui.toast(this, "Still scanning storage — try again in a moment"); return; }
        List<Entry> big = new ArrayList<>(ix.all);
        java.util.Collections.sort(big, (x, y) -> Long.compare(y.len, x.len));
        if (big.size() > 300) big = big.subList(0, 300);
        listView.setList("Largest files", big, false, false);
        showOverlay(listView);
    }

    void retentionDialog() {
        final int[] days = {7, 14, 30, 60, 90};
        String[] labels = new String[days.length];
        for (int i = 0; i < days.length; i++) labels[i] = days[i] + " days";
        new AlertDialog.Builder(this).setTitle("Keep deleted items for")
                .setItems(labels, (d, w) -> { Ui.sp.edit().putInt("recyclebin_days", days[w]).apply(); buildSettings(); })
                .show();
    }

    // ---------------- RECYCLE BIN ----------------
    void showRecycleBin() { buildRecycleBin(); showOverlay(recycleScroll); }

    void buildRecycleBin() {
        recycle.removeAllViews();
        LinearLayout hd = new LinearLayout(this);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        hd.setPadding(Ui.dp(8), 0, Ui.dp(8), 0);
        ImageView bk = Ui.iconBtn(this, Glyphs.BACK, Ui.WHITE);
        bk.setOnClickListener(v -> closeOverlay());
        hd.addView(bk, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        hd.addView(Ui.tv(this, "Recycle Bin", 24, Ui.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView emptyBtn = Ui.tv(this, "Empty", 14, Ui.accent, true);
        emptyBtn.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10));
        emptyBtn.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Empty Recycle Bin?")
                .setMessage("Every item will be permanently deleted. This can't be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Empty", (d, w) -> RecycleBin.empty(this, msg -> { Ui.toast(this, msg); buildRecycleBin(); }))
                .show());
        Ui.press(emptyBtn);
        hd.addView(emptyBtn, new LinearLayout.LayoutParams(-2, -2));
        recycle.addView(hd, new LinearLayout.LayoutParams(-1, Ui.dp(56)));

        TextView note = Ui.tv(this, "Items are kept for " + Ui.sp.getInt("recyclebin_days", 30) + " days, then removed automatically. Change this in Settings.", 12, Ui.SUB, false);
        note.setPadding(Ui.dp(20), Ui.dp(2), Ui.dp(20), Ui.dp(10));
        recycle.addView(note);

        List<RecycleBin.Item> items = RecycleBin.list(this);
        if (items.isEmpty()) {
            TextView w = Ui.tv(this, "Recycle Bin is empty", 14, Ui.SUB, false);
            w.setPadding(Ui.dp(20), Ui.dp(20), 0, 0);
            recycle.addView(w);
        } else {
            for (final RecycleBin.Item it : items) {
                Entry e = new Entry(it.file);
                View rv = Rows.build(this);
                Rows.H h = (Rows.H) rv.getTag();
                Rows.bind(h, e, false, false, "from " + it.originalParent.getName());
                rv.setOnClickListener(v -> recycleItemMenu(it));
                h.more.setOnClickListener(v -> recycleItemMenu(it));
                recycle.addView(rv, new LinearLayout.LayoutParams(-1, -2));
            }
        }
    }

    void recycleItemMenu(final RecycleBin.Item it) {
        String[] opts = {"Restore", "Delete forever"};
        new AlertDialog.Builder(this).setTitle(it.file.getName()).setItems(opts, (d, w) -> {
            if (w == 0) {
                RecycleBin.restore(this, it, msg -> { Ui.toast(this, msg); afterOps(); buildRecycleBin(); });
            } else {
                new AlertDialog.Builder(this).setTitle("Delete forever?").setMessage("This can't be undone.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete", (d2, w2) -> RecycleBin.permanentDelete(this, java.util.Collections.singletonList(it), msg -> { Ui.toast(this, msg); buildRecycleBin(); }))
                        .show();
            }
        }).show();
    }

    String versionName() {
        try { return "Version " + getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return ""; }
    }

    void themeDialog() {
        new AlertDialog.Builder(this).setTitle("Theme").setItems(Ui.THEMES, (d, w) -> { Ui.setTheme(w, true); recolor(); }).show();
    }

    void showAbout() {
        about.removeAllViews();
        LinearLayout hd = new LinearLayout(this);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        hd.setPadding(Ui.dp(8), 0, Ui.dp(8), 0);
        ImageView bk = Ui.iconBtn(this, Glyphs.BACK, Ui.WHITE);
        bk.setContentDescription("Back");
        bk.setOnClickListener(v -> closeOverlay());
        hd.addView(bk, new LinearLayout.LayoutParams(Ui.dp(44), Ui.dp(44)));
        hd.addView(Ui.tv(this, "About", 24, Ui.WHITE, true), new LinearLayout.LayoutParams(0, -2, 1f));
        about.addView(hd, new LinearLayout.LayoutParams(-1, Ui.dp(56)));

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER);
        hero.setBackground(Ui.glass(28, true));
        hero.setPadding(Ui.dp(20), Ui.dp(28), Ui.dp(20), Ui.dp(26));
        ImageView logo = new ImageView(this);
        logo.setImageDrawable(Glyphs.tile(FileKinds.DIR));
        hero.addView(logo, new LinearLayout.LayoutParams(Ui.dp(84), Ui.dp(84)));
        TextView nm = Ui.tv(this, "Liquid Glass Files", 24, Ui.WHITE, true);
        nm.setPadding(0, Ui.dp(16), 0, 0);
        hero.addView(nm);
        TextView vs = Ui.tv(this, versionName(), 13, Ui.accent, true);
        vs.setPadding(0, Ui.dp(6), 0, 0);
        hero.addView(vs);
        TextView tg = Ui.tv(this, "One fast, beautiful file manager for everything on your phone.", 14, Ui.SUB, false);
        tg.setGravity(Gravity.CENTER);
        tg.setPadding(0, Ui.dp(10), 0, 0);
        hero.addView(tg);
        about.addView(hero, lpm(-1, -2, 16, 8, 16, 0));

        about.addView(section("What it does"));
        String[][] feats = {
                {"Open everything", "Photos, videos, music, PDF, text and ZIP open right inside the app. APKs install, other files open with the right app."},
                {"Manage files", "Copy, move, rename, delete, compress, extract, share and favorite — one at a time or in bulk."},
                {"Find anything", "Browse by category or search every file on your storage instantly."}};
        for (String[] f : feats) {
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setBackground(Ui.glass(18, false));
            c.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(14));
            c.addView(Ui.tv(this, f[0], 15, Ui.WHITE, true));
            TextView d = Ui.tv(this, f[1], 13, Ui.SUB, false);
            d.setPadding(0, Ui.dp(5), 0, 0);
            c.addView(d);
            about.addView(c, lpm(-1, -2, 16, 0, 16, 8));
        }
        about.addView(section("Contact"));
        // Intentionally left blank — fill these in with your own email / website / social link
        // before publishing. Each row only becomes tappable once you set a real value.
        final String contactEmail = "";   // e.g. "you@example.com"
        final String contactWeb = "";      // e.g. "https://yoursite.com"
        LinearLayout cc = new LinearLayout(this);
        cc.setOrientation(LinearLayout.VERTICAL);
        cc.setBackground(Ui.glass(18, false));
        cc.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(14));
        TextView ct = Ui.tv(this, contactEmail.isEmpty() && contactWeb.isEmpty()
                ? "Add your email and website in MainActivity.showAbout() before publishing."
                : (contactEmail.isEmpty() ? "" : "Email: " + contactEmail) + (contactWeb.isEmpty() ? "" : (contactEmail.isEmpty() ? "" : "\n") + "Website: " + contactWeb),
                13, Ui.SUB, false);
        cc.addView(ct);
        about.addView(cc, lpm(-1, -2, 16, 0, 16, 8));

        about.addView(section("Privacy"));
        LinearLayout pc = new LinearLayout(this);
        pc.setOrientation(LinearLayout.VERTICAL);
        pc.setBackground(Ui.glass(18, false));
        pc.setPadding(Ui.dp(16), Ui.dp(14), Ui.dp(16), Ui.dp(14));
        TextView pt = Ui.tv(this, "No ads, no analytics, no internet access. \"All files access\" is used only to show and manage your files on this device.", 13, Ui.SUB, false);
        pc.addView(pt);
        about.addView(pc, lpm(-1, -2, 16, 0, 16, 8));
        TextView by = Ui.tv(this, "Made by Chandu", 12, Ui.SUB, false);
        by.setGravity(Gravity.CENTER);
        by.setPadding(0, Ui.dp(14), 0, 0);
        about.addView(by, new LinearLayout.LayoutParams(-1, -2));
        showOverlay(aboutScroll);
    }

    // ---------------- background + donut ----------------
    static final class BgView extends View {
        BgView(android.content.Context c) { super(c); setLayerType(LAYER_TYPE_HARDWARE, null); applyBlur(); }

        void applyBlur() {
            if (Build.VERSION.SDK_INT >= 31) {
                boolean lowRam = false;
                try {
                    android.app.ActivityManager am = (android.app.ActivityManager) getContext().getSystemService(android.content.Context.ACTIVITY_SERVICE);
                    lowRam = am != null && am.isLowRamDevice();
                } catch (Exception ignored) { }
                if (Ui.bool("blur", true) && !lowRam) setRenderEffect(RenderEffect.createBlurEffect(Ui.dp(24), Ui.dp(24), Shader.TileMode.CLAMP));
                else setRenderEffect(null);
            }
        }

        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            c.drawColor(Ui.bg);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            blob(c, p, w * 0.12f, h * 0.10f, w * 0.85f, Ui.blob1);
            blob(c, p, w * 0.98f, h * 0.52f, w * 0.95f, Ui.blob2);
            blob(c, p, w * 0.25f, h * 1.00f, w * 0.85f, Ui.blob3);
        }

        void blob(Canvas c, Paint p, float x, float y, float r, int col) {
            p.setShader(new RadialGradient(x, y, r, col, Color.TRANSPARENT, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, r, p);
        }
    }

    static final class DonutView extends View {
        float[] parts = new float[0];
        int[] cols = new int[0];
        String big = "", small = "";
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF r = new RectF();

        DonutView(android.content.Context c) {
            super(c);
            t.setTextAlign(Paint.Align.CENTER);
            t.setColor(Ui.WHITE);
        }

        void set(float[] pa, int[] co, String b, String s) { parts = pa; cols = co; big = b; small = s; invalidate(); }

        @Override protected void onDraw(Canvas c) {
            float sw = Ui.dp(11), pad = sw / 2f + Ui.dp(2);
            r.set(pad, pad, getWidth() - pad, getHeight() - pad);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(sw);
            p.setColor(Ui.light ? Color.argb(45, 20, 22, 30) : Color.argb(45, 255, 255, 255));
            c.drawArc(r, 0, 360, false, p);
            float start = -90;
            for (int i = 0; i < parts.length && i < cols.length; i++) {
                float sweep = parts[i] * 360f;
                if (sweep < 0.5f) continue;
                p.setColor(cols[i]);
                c.drawArc(r, start, Math.max(sweep - 1.5f, 0.5f), false, p);
                start += sweep;
            }
            t.setColor(Ui.WHITE);
            t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            t.setTextSize(Ui.dp(22));
            c.drawText(big, getWidth() / 2f, getHeight() / 2f + Ui.dp(5), t);
            t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            t.setTextSize(Ui.dp(11));
            t.setColor(Ui.SUB);
            c.drawText(small, getWidth() / 2f, getHeight() / 2f + Ui.dp(21), t);
        }
    }
}
