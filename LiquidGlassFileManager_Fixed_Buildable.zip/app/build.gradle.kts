plugins {
    id("com.android.application")
}

android {
    namespace = "com.music.echo.offline"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.music.echo.offline"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug { applicationIdSuffix = ".debug" }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // FileProvider (sharing / "Open with") is the only AndroidX API the Java sources use.
    implementation("androidx.core:core:1.13.1")
    // Real backdrop blur + SDF refraction + dispersion glass for the View system (MIT, minSdk 24).
    implementation("com.github.QWEA0:liquidglass:v2.0.11")
}
