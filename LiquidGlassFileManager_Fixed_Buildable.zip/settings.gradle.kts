pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Liquid-Glass-Android (MIT) is published on JitPack
        maven {
            url = uri("https://jitpack.io")
            content { includeGroup("com.github.QWEA0") }
        }
    }
}
rootProject.name = "LiquidGlassFileManager"
include(":app")
