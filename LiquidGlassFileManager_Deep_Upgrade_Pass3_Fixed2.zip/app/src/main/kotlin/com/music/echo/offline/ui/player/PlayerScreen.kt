package com.music.echo.offline.ui.player

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.music.echo.offline.data.SongArt
import com.music.echo.offline.data.UiStyle
import com.music.echo.offline.ui.MainViewModel
import com.music.echo.offline.ui.components.ArtImage
import com.music.echo.offline.ui.components.formatTime
import com.music.echo.offline.ui.theme.LocalUiStyle
import com.music.echo.offline.ui.theme.glass

@Composable
fun PlayerScreen(vm: MainViewModel, onClose: () -> Unit, onOpenEqualizer: () -> Unit) {
    val player = vm.player
    val ps by player.state.collectAsState()
    val pos by player.position.collectAsState()
    val map by vm.songMap.collectAsState()
    val favs by vm.favoriteIds.collectAsState()
    val sleepAt by player.sleepAt.collectAsState()
    val ab by player.ab.collectAsState()
    val song = ps.currentId?.let { map[it] }
    val glass = LocalUiStyle.current == UiStyle.Glass

    var showLyrics by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }

    val fg = if (glass) Color.White else MaterialTheme.colorScheme.onSurface
    val fgDim = fg.copy(alpha = 0.7f)

    // Accent colour pulled from the album art (Material style background).
    val ctx = LocalContext.current
    var accent by remember { mutableStateOf<Color?>(null) }
    LaunchedEffect(song?.id) {
        accent = null
        val s = song ?: return@LaunchedEffect
        accent = withContext(Dispatchers.IO) {
            runCatching {
                val req = ImageRequest.Builder(ctx).data(SongArt(s.uri)).allowHardware(false).size(128).build()
                val bmp = (ctx.imageLoader.execute(req) as? SuccessResult)?.drawable?.toBitmap()
                bmp?.let {
                    val p = Palette.from(it).generate()
                    (p.vibrantSwatch ?: p.dominantSwatch)?.rgb?.let { rgb -> Color(rgb) }
                }
            }.getOrNull()
        }
    }
    val topTint by animateColorAsState(
        accent?.copy(alpha = 0.6f) ?: MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
        label = "accent",
    )

    Box(Modifier.fillMaxSize().background(if (glass) Color.Black else MaterialTheme.colorScheme.surface)) {
        // ---- background -------------------------------------------------------------------
        Box(Modifier.fillMaxSize()) {
            if (glass) {
                if (song != null) {
                    AsyncImage(
                        model = SongArt(song.uri), contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().then(
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Modifier.blur(80.dp) else Modifier,
                        ),
                    )
                }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(0.45f), Color.Black.copy(0.8f)))))
            } else {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(topTint, MaterialTheme.colorScheme.surface)),
                    ),
                )
            }
        }

        Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // ---- top bar ---------------------------------------------------------------
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close", tint = fg, modifier = Modifier.size(32.dp)) }
                    Text(
                        "Now playing", color = fgDim, style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                    IconButton(onClick = onOpenEqualizer) { Icon(Icons.Rounded.Equalizer, "Equalizer", tint = fg) }
                }

                // ---- artwork / lyrics ----------------------------------------------------------
                Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                    if (song == null) {
                        Text("Nothing playing", color = fgDim)
                    } else if (showLyrics) {
                        LyricsView(vm, song, fg, Modifier.fillMaxSize())
                    } else {
                        ArtImage(
                            song,
                            Modifier.aspectRatio(1f).shadow(if (glass) 0.dp else 16.dp, RoundedCornerShape(28.dp)),
                            RoundedCornerShape(if (glass) 24.dp else 28.dp),
                        )
                    }
                }

                // ---- title -----------------------------------------------------------------
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            song?.title.orEmpty(), color = fg, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                        )
                        Text(
                            song?.artist.orEmpty(), color = fgDim, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                    if (song != null) {
                        val fav = song.id in favs
                        IconButton(onClick = { vm.toggleFavorite(song) }) {
                            Icon(
                                if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorite",
                                tint = if (fav) MaterialTheme.colorScheme.primary else fg,
                            )
                        }
                        IconButton(onClick = { vm.pickPlaylistFor.value = listOf(song) }) {
                            Icon(Icons.Rounded.PlaylistAdd, "Add to playlist", tint = fg)
                        }
                    }
                }

                // ---- seek bar -----------------------------------------------------------------
                val dur = (ps.durationMs.takeIf { it > 0 } ?: song?.durationMs ?: 1L).coerceAtLeast(1)
                var drag by remember { mutableStateOf<Float?>(null) }
                val frac = drag ?: (pos.toFloat() / dur).coerceIn(0f, 1f)
                Slider(
                    value = frac,
                    onValueChange = { drag = it },
                    onValueChangeFinished = { drag?.let { player.seekTo((it * dur).toLong()) }; drag = null },
                    colors = SliderDefaults.colors(
                        thumbColor = fg, activeTrackColor = fg, inactiveTrackColor = fg.copy(alpha = 0.25f),
                    ),
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                    Text(formatTime((frac * dur).toLong()), color = fgDim, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.weight(1f))
                    Text(formatTime(dur), color = fgDim, style = MaterialTheme.typography.labelMedium)
                }

                // ---- transport ----------------------------------------------------------------
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { player.toggleShuffle() }) {
                        Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (ps.shuffle) MaterialTheme.colorScheme.primary else fgDim)
                    }
                    IconButton(onClick = { player.previous() }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.SkipPrevious, "Previous", tint = fg, modifier = Modifier.size(40.dp))
                    }
                    FilledIconButton(
                        onClick = { player.togglePlay() }, modifier = Modifier.size(72.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = if (glass) Color.White else MaterialTheme.colorScheme.primary,
                            contentColor = if (glass) Color.Black else MaterialTheme.colorScheme.onPrimary,
                        ),
                    ) {
                        Icon(if (ps.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", Modifier.size(40.dp))
                    }
                    IconButton(onClick = { player.next() }, modifier = Modifier.size(56.dp)) {
                        Icon(Icons.Rounded.SkipNext, "Next", tint = fg, modifier = Modifier.size(40.dp))
                    }
                    IconButton(onClick = { player.cycleRepeat() }) {
                        Icon(
                            if (ps.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, "Repeat",
                            tint = if (ps.repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else fgDim,
                        )
                    }
                }

                // ---- bottom action pill -------------------------------------------------------
                val pill = RoundedCornerShape(28.dp)
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        .then(
                            if (glass) Modifier.glass(pill, opacity = 0.25f)
                            else Modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), pill),
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { showLyrics = !showLyrics }) {
                        Icon(Icons.Rounded.Lyrics, "Lyrics", tint = if (showLyrics) MaterialTheme.colorScheme.primary else fg)
                    }
                    IconButton(onClick = { showSleep = true }) {
                        Icon(Icons.Rounded.Bedtime, "Sleep timer", tint = if (sleepAt != null) MaterialTheme.colorScheme.primary else fg)
                    }
                    TextButton(onClick = {
                        val next = when (ps.speed) { 1f -> 1.25f; 1.25f -> 1.5f; 1.5f -> 0.75f; else -> 1f }
                        player.setSpeed(next)
                    }) { Text("${ps.speed}x", color = fg, fontWeight = FontWeight.Bold) }
                    TextButton(onClick = { player.cycleAb() }) {
                        val label = when {
                            ab.first == null -> "A-B"
                            ab.second == null -> "A→"
                            else -> "A-B ✓"
                        }
                        Text(label, color = if (ab.first != null) MaterialTheme.colorScheme.primary else fg, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { showQueue = true }) { Icon(Icons.Rounded.QueueMusic, "Queue", tint = fg) }
                }
            }
    }

    if (showQueue) QueueSheet(vm) { showQueue = false }
    if (showSleep) {
        AlertDialog(
            onDismissRequest = { showSleep = false },
            title = { Text("Sleep timer") },
            text = {
                Column {
                    if (sleepAt != null) {
                        val mins = ((sleepAt!! - System.currentTimeMillis()) / 60_000).coerceAtLeast(0) + 1
                        Text("Music stops in about $mins min", modifier = Modifier.padding(bottom = 8.dp))
                    }
                    listOf(5, 15, 30, 45, 60, 90).forEach { m ->
                        Text(
                            "$m minutes",
                            modifier = Modifier.fillMaxWidth().clickable { player.setSleepTimer(m); showSleep = false }.padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { player.setSleepTimer(null); showSleep = false }) { Text("Turn off") }
            },
        )
    }
}
