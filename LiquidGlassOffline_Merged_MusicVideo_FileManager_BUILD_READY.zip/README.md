# Echo Offline

A fully offline re-creation of Echo Music: plays the music already on your device, with Echo's look
(translucent cards, floating tab bar, dynamic colour) and two switchable styles — **Material You**
and **Liquid Glass** (Settings → Appearance).

**No `INTERNET` permission is declared**, there are no network libraries, and no accounts.

## Build
1. Open this folder in Android Studio (Ladybug or newer, JDK 17). It will sync and generate the Gradle wrapper.
   (Or run `gradle wrapper --gradle-version 8.9` once, then `./gradlew assembleDebug`.)
2. Run on a device/emulator with Android 8.0+ (API 26). Liquid Glass backdrop blur needs Android 12+; older versions fall back to translucency.

## Features
- Scans MediaStore for songs, albums, artists (min-duration filter to hide ringtones)
- Background playback (Media3 + MediaSession): notification, lock screen, headset/Bluetooth buttons
- Queue (play next, add, reorder, remove), shuffle, repeat, speed, sleep timer
- Favorites, playlists, history, most played, recently added (Room database)
- Synced lyrics: import a `.lrc` (or `.txt`) per song; tap a line to seek
- System equalizer with presets
- Export / restore backup (favorites, playlists, history) as JSON
- Material You dynamic colour, light/dark/AMOLED

## Added in v1.1
- Resume queue (last queue, song and position restored on launch, paused)
- Picture-in-Picture (leave the app from the player screen while playing; prev/play/next in the PiP window)
- A-B repeat, skip silence, bass boost and virtualizer
- Folder browser with per-folder hide switches; sorting (title / artist / newest / longest)
- Smart lists: most played, never played, added this week
- Listening stats (plays, estimated hours, top songs and artists)
- Album-art colour theming in the Material player; swipe the mini player left/right to skip
- Share a song file

## Layout
- `data/` MediaStore scanner, Room, DataStore settings, lyrics, backup, cover-art loader
- `playback/` `MusicService`, `PlayerController`, `EqualizerController`
- `ui/theme/` theme + `Modifier.glass()` · `ui/screens/` · `ui/player/` · `ui/components/`

## Not included (needs network or is out of scope)
Streaming, online lyrics, Cast, Listen Together, Spotify import, AI playlists, song recognition, Discord RPC.

## GitHub build

This repository is ready to build in GitHub Actions.

### 1. Create the repository

1. Go to GitHub and create a new repository, for example `EchoOffline`.
2. Keep it empty if you are uploading these files.
3. Upload the **contents of this project folder** so that `build.gradle.kts`, `settings.gradle.kts`, `app/`, and `.github/` are at the repository root.

### 2. Push from a computer

```bash
git init
git add .
git commit -m "Initial EchoOffline Android project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/EchoOffline.git
git push -u origin main
```

### 3. Let GitHub build the APK

Open the repository on GitHub → **Actions** → **Android Build**.  
The workflow uses JDK 17 and Gradle 8.9, then runs:

```bash
gradle --no-daemon assembleDebug
```

When it finishes, open the workflow run and download the **EchoOffline-debug-apk** artifact.

### 4. Build a release APK

The repository also contains `.github/workflows/release.yml`.

You can run it manually from **Actions → Android Release APK → Run workflow**, or create a version tag:

```bash
git tag v1.0.0
git push origin v1.0.0
```

The release workflow currently builds an unsigned release APK. For a Play Store-ready signed APK/AAB, add Android signing secrets and a signing configuration before publishing.

### Project structure

```text
EchoOffline/
├── .github/
│   ├── workflows/
│   │   ├── android-build.yml
│   │   └── release.yml
│   └── PULL_REQUEST_TEMPLATE.md
├── app/
│   ├── build.gradle.kts
│   └── src/main/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradle/
│   └── wrapper/
├── proguard-rules.pro
└── README.md
```

### Important

- No `INTERNET` permission is declared by the app.
- The app is intended to play local device audio.
- The GitHub workflow installs Gradle 8.9 directly, so a `gradlew` wrapper script is not required for the CI build.
- For local Android Studio builds, open the project root (`EchoOffline`) and use JDK 17.
