package com.music.echo.offline.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.music.echo.offline.data.Song
import com.music.echo.offline.ui.LocalBottomPad
import com.music.echo.offline.ui.MainViewModel
import com.music.echo.offline.ui.components.*

@Composable
fun HomeScreen(vm: MainViewModel, onOpenCollection: (String) -> Unit, onOpenAlbum: (Long) -> Unit) {
    val songs by vm.songs.collectAsState()
    val most by vm.mostPlayed.collectAsState()
    val albums by vm.albums.collectAsState()

    LazyColumn(contentPadding = PaddingValues(bottom = LocalBottomPad.current)) {
        item {
            Column(Modifier.statusBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp)) {
                Text("Liquid Glass", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.ExtraBold)
                Text(
                    "${songs.size} songs • fully offline",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard("Shuffle all", Icons.Rounded.Shuffle, Modifier.weight(1f)) {
                    vm.player.play(songs.shuffled(), 0, shuffle = true)
                }
                QuickCard("Favorites", Icons.Rounded.Favorite, Modifier.weight(1f)) { onOpenCollection("favorites") }
            }
        }
        if (songs.isEmpty()) item { EmptyState("No music found on this device yet.") }
        item { SongShelf("Most played", most, vm, "mostplayed", onOpenCollection) }
        if (albums.isNotEmpty()) {
            item { SectionTitle("Albums", Modifier.padding(top = 12.dp)) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    itemsIndexed(albums.take(30), key = { _, a -> a.id }) { _, a ->
                        ShelfCard(a.songs.first(), a.name, a.artist) { onOpenAlbum(a.id) }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickCard(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.softCard().clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(36.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.surface, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Text(label, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun SongShelf(title: String, songs: List<Song>, vm: MainViewModel, kind: String, onOpen: (String) -> Unit) {
    if (songs.isEmpty()) return
    Column(Modifier.padding(top = 12.dp)) {
        Row(Modifier.fillMaxWidth().clickable { onOpen(kind) }, verticalAlignment = Alignment.CenterVertically) {
            SectionTitle(title, Modifier.weight(1f))
            Text("See all", color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 20.dp))
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            itemsIndexed(songs, key = { i, s -> "$kind-$i-${s.id}" }) { i, s ->
                ShelfCard(s, s.title, s.artist) { vm.player.play(songs, i) }
            }
        }
    }
}

@Composable
fun ShelfCard(song: Song, title: String, subtitle: String, onClick: () -> Unit) {
    Column(Modifier.width(140.dp).clickable(onClick = onClick)) {
        ArtImage(song, Modifier.size(140.dp), RoundedCornerShape(20.dp))
        Spacer(Modifier.height(8.dp))
        Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
        Text(
            subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
