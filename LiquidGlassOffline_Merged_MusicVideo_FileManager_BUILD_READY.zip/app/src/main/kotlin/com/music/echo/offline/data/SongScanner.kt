package com.music.echo.offline.data

import android.content.Context
import android.os.Build
import android.provider.MediaStore.Audio.Media
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object SongScanner {
    suspend fun scan(ctx: Context, minDurationMs: Long): List<Song> = withContext(Dispatchers.IO) {
        val out = ArrayList<Song>()
        val q = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val pathCol = if (q) Media.RELATIVE_PATH else Media.DATA
        val projection = arrayOf(
            Media._ID, Media.TITLE, Media.ARTIST, Media.ALBUM,
            Media.ALBUM_ID, Media.DURATION, Media.DATE_ADDED, Media.TRACK, pathCol,
        )
        val selection = "${Media.IS_MUSIC} != 0 AND ${Media.DURATION} >= ?"
        runCatching {
            ctx.contentResolver.query(
                Media.EXTERNAL_CONTENT_URI, projection, selection,
                arrayOf(minDurationMs.toString()), "${Media.TITLE} COLLATE NOCASE ASC",
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(Media._ID)
                val iTitle = c.getColumnIndexOrThrow(Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(Media.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(Media.ALBUM)
                val iAlbumId = c.getColumnIndexOrThrow(Media.ALBUM_ID)
                val iDur = c.getColumnIndexOrThrow(Media.DURATION)
                val iAdded = c.getColumnIndexOrThrow(Media.DATE_ADDED)
                val iTrack = c.getColumnIndexOrThrow(Media.TRACK)
                val iPath = c.getColumnIndexOrThrow(pathCol)
                while (c.moveToNext()) {
                    val raw = c.getString(iPath).orEmpty()
                    val folder = (if (q) raw.trimEnd('/') else File(raw).parent.orEmpty()).ifBlank { "Other" }
                    out += Song(
                        id = c.getLong(iId),
                        title = c.getString(iTitle)?.takeIf { it.isNotBlank() } ?: "Unknown title",
                        artist = clean(c.getString(iArtist), "Unknown artist"),
                        album = clean(c.getString(iAlbum), "Unknown album"),
                        albumId = c.getLong(iAlbumId),
                        durationMs = c.getLong(iDur),
                        dateAdded = c.getLong(iAdded),
                        track = c.getInt(iTrack) % 1000,
                        folder = folder,
                    )
                }
            }
        }
        out
    }

    private fun clean(s: String?, fallback: String): String =
        if (s.isNullOrBlank() || s == "<unknown>") fallback else s
}
