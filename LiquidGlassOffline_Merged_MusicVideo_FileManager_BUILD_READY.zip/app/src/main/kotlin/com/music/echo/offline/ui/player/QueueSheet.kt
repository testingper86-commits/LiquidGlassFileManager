package com.music.echo.offline.ui.player

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.music.echo.offline.ui.MainViewModel
import com.music.echo.offline.ui.components.ArtImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueSheet(vm: MainViewModel, onDismiss: () -> Unit) {
    val ps by vm.player.state.collectAsState()
    val map by vm.songMap.collectAsState()
    val listState = rememberLazyListState()
    LaunchedEffect(Unit) { if (ps.index > 0) listState.scrollToItem(ps.index) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Text("Up next", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        LazyColumn(state = listState, modifier = Modifier.weight(1f, fill = false), contentPadding = PaddingValues(bottom = 24.dp)) {
            itemsIndexed(ps.queueIds) { i, id ->
                val s = map[id] ?: return@itemsIndexed
                val cur = i == ps.index
                Row(
                    Modifier.fillMaxWidth().clickable { vm.player.skipTo(i) }.padding(start = 20.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ArtImage(s, Modifier.size(44.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                            color = if (cur) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        )
                        Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { vm.player.moveInQueue(i, i - 1) }, enabled = i > 0) { Icon(Icons.Rounded.KeyboardArrowUp, "Move up") }
                    IconButton(onClick = { vm.player.moveInQueue(i, i + 1) }, enabled = i < ps.queueIds.lastIndex) { Icon(Icons.Rounded.KeyboardArrowDown, "Move down") }
                    IconButton(onClick = { vm.player.removeFromQueue(i) }, enabled = !cur) { Icon(Icons.Rounded.Close, "Remove") }
                }
            }
        }
    }
}
