package com.music.echo.offline.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.music.echo.offline.data.Keys
import com.music.echo.offline.playback.EqualizerController
import com.music.echo.offline.ui.LocalBottomPad
import com.music.echo.offline.ui.MainViewModel
import com.music.echo.offline.ui.components.BackHeader
import com.music.echo.offline.ui.components.EmptyState
import com.music.echo.offline.ui.components.softCard

@Composable
fun EqualizerScreen(vm: MainViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsState()
    val ps by vm.player.state.collectAsState()
    val info = remember(ps.connected, ps.currentId) { EqualizerController.info }

    Column(Modifier.fillMaxSize()) {
        BackHeader("Equalizer", onBack)
        if (info == null) {
            EmptyState("Start playing a song to configure the equalizer.")
            return@Column
        }
        val bands = info.freqsHz.size
        var bass by remember(s.bass) { mutableFloatStateOf(s.bass.toFloat()) }
        var virt by remember(s.virt) { mutableFloatStateOf(s.virt.toFloat()) }
        val levels = remember(info, s.eqLevels) {
            mutableStateListOf<Int>().apply {
                addAll(if (s.eqLevels.size == bands) s.eqLevels else List(bands) { 0 })
            }
        }
        fun persist() = vm.set(Keys.EQ_LEVELS, levels.joinToString(","))

        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = LocalBottomPad.current)) {
            Row(Modifier.fillMaxWidth().softCard().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Enable equalizer", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Switch(s.eqEnabled, { vm.set(Keys.EQ_ON, it) })
            }
            if (info.presets.isNotEmpty()) {
                Text("Presets", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(info.presets) { i, name ->
                        AssistChip(onClick = {
                            EqualizerController.presetLevels(i)?.let { l ->
                                levels.clear(); levels.addAll(l)
                                vm.set(Keys.EQ_ON, true); persist()
                            }
                        }, label = { Text(name) })
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Column(Modifier.fillMaxWidth().softCard().padding(20.dp)) {
                Text("Bass boost", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = bass, valueRange = 0f..1000f,
                    onValueChange = { bass = it; EqualizerController.configureEffects(bass.toInt(), virt.toInt()) },
                    onValueChangeFinished = { vm.set(Keys.BASS, bass.toInt()) },
                )
                Text("Virtualizer (surround)", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = virt, valueRange = 0f..1000f,
                    onValueChange = { virt = it; EqualizerController.configureEffects(bass.toInt(), virt.toInt()) },
                    onValueChangeFinished = { vm.set(Keys.VIRT, virt.toInt()) },
                )
            }
            Spacer(Modifier.height(20.dp))
            Column(Modifier.fillMaxWidth().softCard().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                for (i in 0 until bands) {
                    val hz = info.freqsHz[i]
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (hz >= 1000) "${hz / 1000} kHz" else "$hz Hz", Modifier.width(64.dp), style = MaterialTheme.typography.labelMedium)
                        Slider(
                            value = levels[i].toFloat(),
                            onValueChange = {
                                levels[i] = it.toInt()
                                EqualizerController.configure(s.eqEnabled, levels.toList())
                            },
                            onValueChangeFinished = { persist() },
                            valueRange = info.minLevel.toFloat()..info.maxLevel.toFloat(),
                            enabled = s.eqEnabled,
                            modifier = Modifier.weight(1f),
                        )
                        Text("${levels[i] / 100} dB", Modifier.width(48.dp), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
