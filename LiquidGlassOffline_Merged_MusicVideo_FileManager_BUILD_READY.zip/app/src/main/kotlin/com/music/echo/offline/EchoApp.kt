package com.music.echo.offline

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.music.echo.offline.data.EchoDatabase
import com.music.echo.offline.data.LyricsStore
import com.music.echo.offline.data.SettingsStore
import com.music.echo.offline.data.SongArtFetcher
import com.music.echo.offline.data.SongArtKeyer
import com.music.echo.offline.playback.PlayerController

class EchoApp : Application(), ImageLoaderFactory {
    lateinit var db: EchoDatabase
        private set
    lateinit var settings: SettingsStore
        private set
    lateinit var lyrics: LyricsStore
        private set
    lateinit var player: PlayerController
        private set

    override fun onCreate() {
        super.onCreate()
        db = EchoDatabase.build(this)
        settings = SettingsStore(this)
        lyrics = LyricsStore(this)
        player = PlayerController(this, db.dao(), settings)
    }

    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components {
            add(SongArtKeyer())
            add(SongArtFetcher.Factory())
        }
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.20).build() }
        .diskCache {
            DiskCache.Builder().directory(cacheDir.resolve("art")).maxSizeBytes(64L * 1024 * 1024).build()
        }
        .crossfade(true)
        .build()
}
