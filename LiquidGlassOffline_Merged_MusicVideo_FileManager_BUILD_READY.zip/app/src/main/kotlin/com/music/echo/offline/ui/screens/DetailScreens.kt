package com.music.echo.offline.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.music.echo.offline.data.Song
import com.music.echo.offline.ui.LocalBottomPad
import com.music.echo.offline.ui.MainViewModel
import com.music.echo.offline.ui.components.*

@Composable
fun SongListScreen(
    title: String,
    subtitle: String,
    songs: List<Song>,
    vm: MainViewModel,
    onBack: () -> Unit,
    onRemove: ((Song) -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val ps by vm.player.state.collectAsState()
    Column(Modifier.fillMaxSize()) {
        BackHeader(title, onBack, actions)
        LazyColumn(contentPadding = PaddingValues(bottom = LocalBottomPad.current)) {
            item {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    ArtImage(songs.firstOrNull(), Modifier.size(180.dp), RoundedCornerShape(28.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { vm.player.play(songs, 0) }, enabled = songs.isNotEmpty()) {
                            Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Play")
                        }
                        FilledTonalButton(onClick = { vm.player.play(songs.shuffled(), 0, true) }, enabled = songs.isNotEmpty()) {
                            Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(6.dp)); Text("Shuffle")
                        }
                    }
                }
            }
            if (songs.isEmpty()) item { EmptyState("Nothing here yet.") }
            itemsIndexed(songs, key = { i, s -> "$i-${s.id}" }) { i, s ->
                SongRow(
                    s, vm, ps.currentId == s.id, onClick = { vm.player.play(songs, i) },
                    onRemove = onRemove?.let { { it(s) } },
                )
            }
        }
    }
}

@Composable
fun AlbumScreen(id: Long, vm: MainViewModel, onBack: () -> Unit) {
    val albums by vm.albums.collectAsState()
    val a = albums.firstOrNull { it.id == id }
    SongListScreen(a?.name ?: "Album", a?.artist.orEmpty(), a?.songs.orEmpty(), vm, onBack)
}

@Composable
fun ArtistScreen(name: String, vm: MainViewModel, onBack: () -> Unit) {
    val artists by vm.artists.collectAsState()
    val a = artists.firstOrNull { it.name == name }
    SongListScreen(name, "${a?.songs?.size ?: 0} songs", a?.songs.orEmpty(), vm, onBack)
}

@Composable
fun CollectionScreen(kind: String, vm: MainViewModel, onBack: () -> Unit) {
    val fav by vm.favoriteSongs.collectAsState()
    val recent by vm.recentlyPlayed.collectAsState()
    val most by vm.mostPlayed.collectAsState()
    val added by vm.recentlyAdded.collectAsState()
    val never by vm.neverPlayed.collectAsState()
    val week by vm.addedThisWeek.collectAsState()
    val (title, list) = when (kind) {
        "never" -> "Never played" to never
        "week" -> "Added this week" to week
        "favorites" -> "Favorites" to fav
        "recent" -> "Recently played" to recent
        "mostplayed" -> "Most played" to most
        else -> "Recently added" to added
    }
    SongListScreen(
        title, "${list.size} songs", list, vm, onBack,
        onRemove = if (kind == "favorites") ({ s -> vm.toggleFavorite(s) }) else null,
        actions = {
            if (kind == "recent") IconButton({ vm.clearHistory() }) { Icon(Icons.Rounded.DeleteSweep, "Clear history") }
        },
    )
}

@Composable
fun PlaylistScreen(id: Long, vm: MainViewModel, onBack: () -> Unit) {
    val playlists by vm.playlists.collectAsState()
    val p = playlists.firstOrNull { it.id == id }
    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    SongListScreen(
        p?.name ?: "Playlist", "${p?.songs?.size ?: 0} songs", p?.songs.orEmpty(), vm, onBack,
        onRemove = { s -> vm.removeFromPlaylist(id, s) },
        actions = {
            IconButton({ rename = true }) { Icon(Icons.Rounded.Edit, "Rename") }
            IconButton({ confirmDelete = true }) { Icon(Icons.Rounded.Delete, "Delete") }
        },
    )
    if (rename && p != null) {
        TextPromptDialog("Rename playlist", p.name, "Save", { rename = false }) { vm.renamePlaylist(id, it); rename = false }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete playlist?") },
            text = { Text("Songs on your device are not affected.") },
            confirmButton = { TextButton({ vm.deletePlaylist(id); confirmDelete = false; onBack() }) { Text("Delete") } },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

@Composable
fun FolderScreen(path: String, vm: MainViewModel, onBack: () -> Unit) {
    val songs by vm.songs.collectAsState()
    val list = remember(songs, path) { songs.filter { it.folder == path } }
    SongListScreen(path.substringAfterLast('/').ifBlank { path }, path, list, vm, onBack)
}
