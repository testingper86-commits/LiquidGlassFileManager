package com.music.echo.offline.ui

import android.app.Application
import android.net.Uri
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.music.echo.offline.EchoApp
import com.music.echo.offline.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val echo = app as EchoApp
    val player = echo.player
    val dao = echo.db.dao()
    val lyricsStore = echo.lyrics

    private fun <T> Flow<T>.eager(init: T): StateFlow<T> = stateIn(viewModelScope, SharingStarted.Eagerly, init)

    val settings: StateFlow<Settings> = echo.settings.flow.eager(Settings())

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    /** Everything MediaStore returned (used by the folder browser); [songs] has excluded folders removed. */
    val allSongs: StateFlow<List<Song>> = _songs.asStateFlow()
    val songs: StateFlow<List<Song>> = combine(_songs, settings) { l, s ->
        if (s.excluded.isEmpty()) l else l.filter { it.folder !in s.excluded }
    }.eager(emptyList())
    private var restored = false
    val scanning = MutableStateFlow(false)
    val songMap: StateFlow<Map<Long, Song>> = songs.map { l -> l.associateBy { it.id } }.eager(emptyMap())

    val albums: StateFlow<List<AlbumInfo>> = songs.map { list ->
        list.groupBy { it.albumId }.map { (id, s) ->
            AlbumInfo(id, s.first().album, s.first().artist, s.sortedBy { it.track })
        }.sortedBy { it.name.lowercase() }
    }.eager(emptyList())

    val artists: StateFlow<List<ArtistInfo>> = songs.map { list ->
        list.groupBy { it.artist }.map { (n, s) -> ArtistInfo(n, s) }.sortedBy { it.name.lowercase() }
    }.eager(emptyList())

    val sortedSongs: StateFlow<List<Song>> = combine(songs, settings) { l, s ->
        when (s.sort) {
            1 -> l.sortedBy { it.artist.lowercase() }
            2 -> l.sortedByDescending { it.dateAdded }
            3 -> l.sortedByDescending { it.durationMs }
            else -> l.sortedBy { it.title.lowercase() }
        }
    }.eager(emptyList())

    val folders: StateFlow<List<Pair<String, Int>>> = allSongs.map { l ->
        l.groupBy { it.folder }.map { (k, v) -> k to v.size }.sortedBy { it.first.lowercase() }
    }.eager(emptyList())

    val history: StateFlow<List<HistoryEntity>> = dao.history().eager(emptyList())

    val neverPlayed: StateFlow<List<Song>> = combine(songs, dao.history()) { l, h ->
        val played = h.map { it.songId }.toSet()
        l.filter { it.id !in played }.take(300)
    }.eager(emptyList())

    val addedThisWeek: StateFlow<List<Song>> = songs.map { l ->
        val cutoff = System.currentTimeMillis() / 1000 - 7 * 86_400
        l.filter { it.dateAdded >= cutoff }.sortedByDescending { it.dateAdded }
    }.eager(emptyList())

    val favoriteIds: StateFlow<Set<Long>> = dao.favorites().map { l -> l.map { it.songId }.toSet() }.eager(emptySet())
    val favoriteSongs: StateFlow<List<Song>> =
        combine(dao.favorites(), songMap) { f, m -> f.mapNotNull { m[it.songId] } }.eager(emptyList())
    val recentlyPlayed: StateFlow<List<Song>> =
        combine(dao.history(), songMap) { h, m -> h.mapNotNull { m[it.songId] }.take(30) }.eager(emptyList())
    val mostPlayed: StateFlow<List<Song>> =
        combine(dao.history(), songMap) { h, m ->
            h.sortedByDescending { it.playCount }.mapNotNull { m[it.songId] }.take(30)
        }.eager(emptyList())
    val recentlyAdded: StateFlow<List<Song>> =
        songs.map { l -> l.sortedByDescending { it.dateAdded }.take(30) }.eager(emptyList())

    val playlists: StateFlow<List<PlaylistInfo>> =
        combine(dao.playlists(), dao.allPlaylistSongs(), songMap) { ps, entries, m ->
            val by = entries.groupBy { it.playlistId }
            ps.map { p -> PlaylistInfo(p.id, p.name, by[p.id].orEmpty().mapNotNull { m[it.songId] }) }
        }.eager(emptyList())

    /** Non-null while the "add to playlist" picker should be shown. */
    val pickPlaylistFor = MutableStateFlow<List<Song>?>(null)

    fun rescan() {
        if (scanning.value) return
        viewModelScope.launch {
            scanning.value = true
            val list = SongScanner.scan(getApplication(), settings.value.minDurationSec * 1000L)
            _songs.value = list
            scanning.value = false
            if (!restored && list.isNotEmpty()) {
                restored = true
                player.restoreQueue(list.associateBy { it.id })
            }
        }
    }

    fun <T> set(key: Preferences.Key<T>, value: T) { viewModelScope.launch { echo.settings.set(key, value) } }

    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            if (song.id in favoriteIds.value) dao.removeFavorite(song.id)
            else dao.addFavorite(FavoriteEntity(song.id, System.currentTimeMillis()))
        }
    }

    fun createPlaylist(name: String, initial: List<Song> = emptyList()) {
        viewModelScope.launch {
            val id = dao.insertPlaylist(PlaylistEntity(name = name.trim(), createdAt = System.currentTimeMillis()))
            var pos = 0
            initial.forEach { dao.addToPlaylist(PlaylistSongEntity(id, it.id, pos++)) }
        }
    }

    fun addToPlaylist(playlistId: Long, songs: List<Song>) {
        viewModelScope.launch {
            var pos = dao.nextPosition(playlistId)
            songs.forEach { dao.addToPlaylist(PlaylistSongEntity(playlistId, it.id, pos++)) }
        }
    }

    fun removeFromPlaylist(playlistId: Long, song: Song) { viewModelScope.launch { dao.removeFromPlaylist(playlistId, song.id) } }
    fun renamePlaylist(id: Long, name: String) { viewModelScope.launch { dao.renamePlaylist(id, name.trim()) } }
    fun deletePlaylist(id: Long) { viewModelScope.launch { dao.clearPlaylistSongs(id); dao.deletePlaylist(id) } }
    fun toggleFolder(path: String) {
        val cur = settings.value.excluded
        set(Keys.EXCLUDED, if (path in cur) cur - path else cur + path)
    }

    fun clearHistory() { viewModelScope.launch { dao.clearHistory() } }

    fun exportBackup(uri: Uri, done: (Boolean) -> Unit) {
        viewModelScope.launch { done(Backup.export(getApplication(), dao, songs.value, uri)) }
    }

    fun importBackup(uri: Uri, done: (Boolean) -> Unit) {
        viewModelScope.launch { done(Backup.import(getApplication(), dao, songs.value, uri)) }
    }
}
