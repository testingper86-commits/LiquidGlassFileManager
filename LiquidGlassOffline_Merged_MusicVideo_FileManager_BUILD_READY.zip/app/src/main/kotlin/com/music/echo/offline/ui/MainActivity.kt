package com.music.echo.offline.ui

import android.Manifest
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.music.echo.offline.EchoApp
import com.music.echo.offline.ui.components.ArtImage
import com.music.echo.offline.ui.theme.EchoTheme
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    companion object {
        val inPip = mutableStateOf(false)
        /** True while the full player screen is open; Home → Picture-in-Picture only then. */
        val playerVisible = mutableStateOf(false)
        private const val A_PREV = "com.music.echo.offline.PIP_PREV"
        private const val A_TOGGLE = "com.music.echo.offline.PIP_TOGGLE"
        private const val A_NEXT = "com.music.echo.offline.PIP_NEXT"
    }

    private val player get() = (application as EchoApp).player

    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                A_PREV -> player.previous()
                A_TOGGLE -> player.togglePlay()
                A_NEXT -> player.next()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ContextCompat.registerReceiver(
            this, pipReceiver,
            IntentFilter().apply { addAction(A_PREV); addAction(A_TOGGLE); addAction(A_NEXT) },
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        lifecycleScope.launch {
            player.state.map { it.isPlaying }.distinctUntilChanged().collect { playing ->
                if (inPip.value) setPictureInPictureParams(pipParams(playing))
            }
        }
        setContent { AppRoot() }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(pipReceiver) }
        super.onDestroy()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (playerVisible.value && player.state.value.isPlaying) {
            runCatching { enterPictureInPictureMode(pipParams(true)) }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip.value = isInPictureInPictureMode
    }

    private fun pipParams(playing: Boolean): PictureInPictureParams {
        fun action(icon: Int, title: String, act: String, req: Int) = RemoteAction(
            Icon.createWithResource(this, icon), title, title,
            PendingIntent.getBroadcast(
                this, req, Intent(act).setPackage(packageName),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        )
        return PictureInPictureParams.Builder()
            .setAspectRatio(Rational(1, 1))
            .setActions(
                listOf(
                    action(android.R.drawable.ic_media_previous, "Previous", A_PREV, 1),
                    action(
                        if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                        "Play/Pause", A_TOGGLE, 2,
                    ),
                    action(android.R.drawable.ic_media_next, "Next", A_NEXT, 3),
                ),
            )
            .build()
    }
}

@Composable
private fun AppRoot() {
    val vm: MainViewModel = viewModel()
    val settings by vm.settings.collectAsState()
    val pip by MainActivity.inPip
    EchoTheme(settings) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Box(Modifier.fillMaxSize()) {
                PermissionGate(vm) { AppScaffold(vm) }
                if (pip) PipContent(vm)
            }
        }
    }
}

/** Compact Picture-in-Picture window: just the album art (controls are system remote actions). */
@Composable
private fun PipContent(vm: MainViewModel) {
    val ps by vm.player.state.collectAsState()
    val map by vm.songMap.collectAsState()
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        ArtImage(ps.currentId?.let { map[it] }, Modifier.fillMaxSize(), RoundedCornerShape(0.dp))
    }
}

@Composable
private fun PermissionGate(vm: MainViewModel, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    fun has() = ContextCompat.checkSelfPermission(ctx, audioPerm) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(has()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = has() }
    val minDur = vm.settings.collectAsState().value.minDurationSec

    LaunchedEffect(granted, minDur) { if (granted) vm.rescan() }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { if (granted) vm.rescan() }

    if (granted) {
        content()
    } else {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
        ) {
            Icon(Icons.Rounded.LibraryMusic, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp))
            Text("Echo Offline", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Allow access to the music on your device. Nothing ever leaves your phone — this app has no internet access.",
                textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = {
                val perms = buildList {
                    add(audioPerm)
                    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
                }
                launcher.launch(perms.toTypedArray())
            }) { Text("Grant access") }
        }
    }
}
