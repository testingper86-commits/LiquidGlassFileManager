package com.music.echo.offline.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.key.Keyer
import coil.request.Options
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SongArtKeyer : Keyer<SongArt> {
    override fun key(data: SongArt, options: Options): String = "songart:" + data.songUri
}

/** Loads cover art for a local audio file (MediaStore thumbnail, then embedded picture). */
class SongArtFetcher(private val ctx: Context, private val data: SongArt) : Fetcher {
    override suspend fun fetch(): FetchResult? = withContext(Dispatchers.IO) {
        val bmp = load(ctx, data.songUri) ?: return@withContext null
        DrawableResult(BitmapDrawable(ctx.resources, bmp), isSampled = false, dataSource = DataSource.DISK)
    }

    class Factory : Fetcher.Factory<SongArt> {
        override fun create(data: SongArt, options: Options, imageLoader: ImageLoader): Fetcher =
            SongArtFetcher(options.context, data)
    }

    private fun load(ctx: Context, uri: Uri): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching { return ctx.contentResolver.loadThumbnail(uri, Size(640, 640), null) }
        }
        return runCatching {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
            } finally {
                r.release()
            }
        }.getOrNull()
    }
}
