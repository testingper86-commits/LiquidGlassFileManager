package com.music.echo.offline.playback

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer

data class EqInfo(
    val minLevel: Int,
    val maxLevel: Int,
    val freqsHz: List<Int>,
    val presets: List<String>,
)

/** Process-wide wrapper around the audiofx Equalizer, BassBoost and Virtualizer, driven by MusicService. */
object EqualizerController {
    private var eq: Equalizer? = null
    private var bassFx: BassBoost? = null
    private var virtFx: Virtualizer? = null
    private var enabled = false
    private var levels: List<Int> = emptyList()
    private var bass = 0
    private var virt = 0

    @Volatile var info: EqInfo? = null
        private set

    fun attach(sessionId: Int) {
        release()
        if (sessionId == 0) return
        runCatching {
            val e = Equalizer(0, sessionId)
            eq = e
            val range = e.bandLevelRange
            info = EqInfo(
                minLevel = range[0].toInt(),
                maxLevel = range[1].toInt(),
                freqsHz = (0 until e.numberOfBands).map { e.getCenterFreq(it.toShort()) / 1000 },
                presets = (0 until e.numberOfPresets).map { e.getPresetName(it.toShort()) },
            )
        }
        bassFx = runCatching { BassBoost(0, sessionId) }.getOrNull()
        virtFx = runCatching { Virtualizer(0, sessionId) }.getOrNull()
        apply()
    }

    fun configure(enabled: Boolean, levels: List<Int>) {
        this.enabled = enabled
        this.levels = levels
        apply()
    }

    /** Strengths are 0..1000. */
    fun configureEffects(bass: Int, virt: Int) {
        this.bass = bass
        this.virt = virt
        apply()
    }

    /** Returns the band levels (mB) of a built-in preset, or null if unavailable. */
    fun presetLevels(index: Int): List<Int>? = runCatching {
        val e = eq ?: return null
        e.usePreset(index.toShort())
        (0 until e.numberOfBands).map { e.getBandLevel(it.toShort()).toInt() }
    }.getOrNull()

    private fun apply() {
        eq?.let { e ->
            runCatching {
                e.enabled = enabled
                if (enabled) {
                    levels.take(e.numberOfBands.toInt()).forEachIndexed { i, l -> e.setBandLevel(i.toShort(), l.toShort()) }
                }
            }
        }
        bassFx?.let { b ->
            runCatching { b.enabled = bass > 0; if (b.strengthSupported) b.setStrength(bass.toShort()) }
        }
        virtFx?.let { v ->
            runCatching { v.enabled = virt > 0; if (v.strengthSupported) v.setStrength(virt.toShort()) }
        }
    }

    fun release() {
        runCatching { eq?.release() }
        runCatching { bassFx?.release() }
        runCatching { virtFx?.release() }
        eq = null; bassFx = null; virtFx = null
    }
}
