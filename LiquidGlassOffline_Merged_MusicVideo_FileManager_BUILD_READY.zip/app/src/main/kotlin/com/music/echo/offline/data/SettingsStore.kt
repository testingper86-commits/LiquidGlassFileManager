package com.music.echo.offline.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("settings")

enum class UiStyle { Material, Glass }
enum class ThemeMode { System, Light, Dark }

data class Settings(
    val style: UiStyle = UiStyle.Material,
    val theme: ThemeMode = ThemeMode.System,
    val dynamicColor: Boolean = true,
    val amoled: Boolean = false,
    val minDurationSec: Int = 30,
    val eqEnabled: Boolean = false,
    val eqLevels: List<Int> = emptyList(),
    val skipSilence: Boolean = false,
    val bass: Int = 0,
    val virt: Int = 0,
    val sort: Int = 0,
    val excluded: Set<String> = emptySet(),
)

object Keys {
    val STYLE = stringPreferencesKey("style")
    val THEME = stringPreferencesKey("theme")
    val DYNAMIC = booleanPreferencesKey("dynamic")
    val AMOLED = booleanPreferencesKey("amoled")
    val MIN_DUR = intPreferencesKey("min_duration")
    val EQ_ON = booleanPreferencesKey("eq_on")
    val EQ_LEVELS = stringPreferencesKey("eq_levels")
    val SKIP_SILENCE = booleanPreferencesKey("skip_silence")
    val BASS = intPreferencesKey("bass")
    val VIRT = intPreferencesKey("virt")
    val SORT = intPreferencesKey("sort")
    val EXCLUDED = stringSetPreferencesKey("excluded")
    val Q_IDS = stringPreferencesKey("q_ids")
    val Q_INDEX = intPreferencesKey("q_index")
    val Q_POS = longPreferencesKey("q_pos")
}

class SettingsStore(private val ctx: Context) {
    val flow: Flow<Settings> = ctx.dataStore.data.map { p ->
        Settings(
            style = p[Keys.STYLE]?.let { runCatching { UiStyle.valueOf(it) }.getOrNull() } ?: UiStyle.Material,
            theme = p[Keys.THEME]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.System,
            dynamicColor = p[Keys.DYNAMIC] ?: true,
            amoled = p[Keys.AMOLED] ?: false,
            minDurationSec = p[Keys.MIN_DUR] ?: 30,
            eqEnabled = p[Keys.EQ_ON] ?: false,
            eqLevels = p[Keys.EQ_LEVELS]?.split(",")?.mapNotNull { it.toIntOrNull() } ?: emptyList(),
            skipSilence = p[Keys.SKIP_SILENCE] ?: false,
            bass = p[Keys.BASS] ?: 0,
            virt = p[Keys.VIRT] ?: 0,
            sort = p[Keys.SORT] ?: 0,
            excluded = p[Keys.EXCLUDED] ?: emptySet(),
        )
    }

    suspend fun saveQueue(ids: List<Long>, index: Int, pos: Long) {
        ctx.dataStore.edit {
            it[Keys.Q_IDS] = ids.joinToString(",")
            it[Keys.Q_INDEX] = index
            it[Keys.Q_POS] = pos
        }
    }

    suspend fun loadQueue(): Triple<List<Long>, Int, Long> {
        val p = ctx.dataStore.data.first()
        return Triple(
            p[Keys.Q_IDS]?.split(",")?.mapNotNull { it.toLongOrNull() } ?: emptyList(),
            p[Keys.Q_INDEX] ?: 0,
            p[Keys.Q_POS] ?: 0L,
        )
    }

    suspend fun <T> set(key: Preferences.Key<T>, value: T) {
        ctx.dataStore.edit { it[key] = value }
    }
}
