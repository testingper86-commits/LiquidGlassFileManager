package com.music.echo.offline.data

import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val dateAdded: Long,
    val track: Int,
    val folder: String = "",
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
}

data class AlbumInfo(val id: Long, val name: String, val artist: String, val songs: List<Song>)

data class ArtistInfo(val name: String, val songs: List<Song>) {
    val albumCount: Int get() = songs.map { it.albumId }.distinct().size
}

data class PlaylistInfo(val id: Long, val name: String, val songs: List<Song>)

/** Key used to look up cover art through Coil (see SongArtFetcher). */
data class SongArt(val songUri: Uri)
