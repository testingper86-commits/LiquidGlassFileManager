package com.music.echo.offline.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Portable backup: songs are matched by title+artist so it survives re-installs and new devices. */
object Backup {
    private fun key(title: String, artist: String) = (title.trim() + "|" + artist.trim()).lowercase()
    private fun ref(s: Song) = JSONObject().put("t", s.title).put("a", s.artist)

    suspend fun export(ctx: Context, dao: EchoDao, songs: List<Song>, to: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val byId = songs.associateBy { it.id }
            val root = JSONObject().put("version", 1)
            root.put("favorites", JSONArray().apply {
                dao.favorites().first().forEach { f -> byId[f.songId]?.let { put(ref(it)) } }
            })
            root.put("history", JSONArray().apply {
                dao.history().first().forEach { h ->
                    byId[h.songId]?.let { put(ref(it).put("c", h.playCount).put("l", h.lastPlayed)) }
                }
            })
            val ps = dao.allPlaylistSongs().first().groupBy { it.playlistId }
            root.put("playlists", JSONArray().apply {
                dao.playlists().first().forEach { p ->
                    put(JSONObject().put("name", p.name).put("songs", JSONArray().apply {
                        ps[p.id].orEmpty().forEach { e -> byId[e.songId]?.let { put(ref(it)) } }
                    }))
                }
            })
            ctx.contentResolver.openOutputStream(to, "wt")!!.use { it.write(root.toString(2).toByteArray()) }
            true
        }.getOrDefault(false)
    }

    suspend fun import(ctx: Context, dao: EchoDao, songs: List<Song>, from: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val byKey = songs.associateBy { key(it.title, it.artist) }
            val root = JSONObject(ctx.contentResolver.openInputStream(from)!!.use { it.readBytes().toString(Charsets.UTF_8) })
            fun find(o: JSONObject) = byKey[key(o.getString("t"), o.getString("a"))]
            val now = System.currentTimeMillis()
            root.optJSONArray("favorites")?.let { a ->
                for (i in 0 until a.length()) find(a.getJSONObject(i))?.let { dao.addFavorite(FavoriteEntity(it.id, now - i)) }
            }
            root.optJSONArray("history")?.let { a ->
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    find(o)?.let { dao.upsertHistory(HistoryEntity(it.id, o.optInt("c", 1), o.optLong("l", now))) }
                }
            }
            root.optJSONArray("playlists")?.let { a ->
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val pid = dao.insertPlaylist(PlaylistEntity(name = o.getString("name"), createdAt = now + i))
                    val arr = o.getJSONArray("songs")
                    var pos = 0
                    for (j in 0 until arr.length()) find(arr.getJSONObject(j))?.let {
                        dao.addToPlaylist(PlaylistSongEntity(pid, it.id, pos++))
                    }
                }
            }
            true
        }.getOrDefault(false)
    }
}
