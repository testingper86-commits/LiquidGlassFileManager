package com.music.echo.offline.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.music.echo.offline.data.Settings
import com.music.echo.offline.data.ThemeMode
import com.music.echo.offline.data.UiStyle

/** Echo Music's default seed colour is 0xFFED5564; these are hand-derived tonal roles from it. */
private val LightScheme = lightColorScheme(
    primary = Color(0xFFB91E3F), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDADB), onPrimaryContainer = Color(0xFF40000D),
    secondary = Color(0xFF765658), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDADB), onSecondaryContainer = Color(0xFF2C1517),
    background = Color(0xFFFFF8F7), onBackground = Color(0xFF22191A),
    surface = Color(0xFFFFF8F7), onSurface = Color(0xFF22191A),
    surfaceVariant = Color(0xFFF4DDDD), onSurfaceVariant = Color(0xFF524344),
    outline = Color(0xFF857374),
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFFFB2B7), onPrimary = Color(0xFF680020),
    primaryContainer = Color(0xFF920031), onPrimaryContainer = Color(0xFFFFDADB),
    secondary = Color(0xFFE5BDBE), onSecondary = Color(0xFF43292B),
    secondaryContainer = Color(0xFF5C3F41), onSecondaryContainer = Color(0xFFFFDADB),
    background = Color(0xFF1A1112), onBackground = Color(0xFFF0DEDE),
    surface = Color(0xFF1A1112), onSurface = Color(0xFFF0DEDE),
    surfaceVariant = Color(0xFF524344), onSurfaceVariant = Color(0xFFD7C1C2),
    outline = Color(0xFF9F8C8D),
)

@Composable
fun EchoTheme(settings: Settings, content: @Composable () -> Unit) {
    val dark = when (settings.theme) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
    }
    val ctx = LocalContext.current
    var scheme = when {
        settings.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> DarkScheme
        else -> LightScheme
    }
    if (dark && settings.amoled) {
        scheme = scheme.copy(
            background = Color.Black, surface = Color.Black,
            surfaceContainer = Color(0xFF0B0B0B), surfaceContainerHigh = Color(0xFF141414),
            surfaceContainerHighest = Color(0xFF1C1C1C),
        )
    }

    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let { w ->
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }

    CompositionLocalProvider(LocalUiStyle provides settings.style) {
        MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
    }
}

val LocalUiStyle = staticCompositionLocalOf { UiStyle.Material }
