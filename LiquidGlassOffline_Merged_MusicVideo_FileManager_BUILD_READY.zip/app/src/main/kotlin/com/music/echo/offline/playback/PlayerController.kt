package com.music.echo.offline.playback

import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.music.echo.offline.data.EchoDao
import com.music.echo.offline.data.HistoryEntity
import com.music.echo.offline.data.SettingsStore
import com.music.echo.offline.data.Song
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class PlayerState(
    val connected: Boolean = false,
    val currentId: Long? = null,
    val queueIds: List<Long> = emptyList(),
    val index: Int = -1,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1f,
)

private val ART_BASE: Uri = Uri.parse("content://media/external/audio/albumart")

fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id.toString())
    .setUri(uri)
    .setMediaMetadata(
        MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(ContentUris.withAppendedId(ART_BASE, albumId))
            .build(),
    )
    .build()

/** App-wide façade over a MediaController connected to [MusicService]. */
class PlayerController(private val ctx: Context, private val dao: EchoDao, private val store: SettingsStore) {
    private val scope = MainScope()
    private var controller: MediaController? = null

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position.asStateFlow()

    /** Epoch millis when the sleep timer fires, or null. */
    private val _sleepAt = MutableStateFlow<Long?>(null)
    val sleepAt: StateFlow<Long?> = _sleepAt.asStateFlow()
    private var sleepJob: Job? = null

    private var lastRecorded: Long? = null

    /** A-B loop: (A, B) in ms; either may be null. */
    private val _ab = MutableStateFlow<Pair<Long?, Long?>>(null to null)
    val ab: StateFlow<Pair<Long?, Long?>> = _ab.asStateFlow()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refresh()
        }
    }

    init {
        val token = SessionToken(ctx, ComponentName(ctx, MusicService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            runCatching { future.get() }.getOrNull()?.let {
                controller = it
                it.addListener(listener)
                refresh()
            }
        }, ContextCompat.getMainExecutor(ctx))

        scope.launch {
            var tick = 0
            while (isActive) {
                controller?.let { c ->
                    if (c.isPlaying) {
                        val p = c.currentPosition
                        _position.value = p
                        val (a, b) = _ab.value
                        if (a != null && b != null && p >= b) c.seekTo(a)
                        if (++tick % 20 == 0 && _state.value.queueIds.isNotEmpty()) {
                            launch { store.saveQueue(_state.value.queueIds, _state.value.index, p) }
                        }
                    }
                }
                delay(250)
            }
        }
    }

    private fun refresh() {
        val c = controller ?: return
        val ids = (0 until c.mediaItemCount).mapNotNull { c.getMediaItemAt(it).mediaId.toLongOrNull() }
        val cur = c.currentMediaItem?.mediaId?.toLongOrNull()
        _state.value = PlayerState(
            connected = true,
            currentId = cur,
            queueIds = ids,
            index = c.currentMediaItemIndex,
            isPlaying = c.isPlaying,
            durationMs = c.duration.takeIf { it > 0 } ?: 0,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            speed = c.playbackParameters.speed,
        )
        _position.value = c.currentPosition
        if (ids.isNotEmpty()) {
            scope.launch(Dispatchers.IO) { store.saveQueue(ids, c.currentMediaItemIndex, c.currentPosition) }
        }
        if (cur != null && cur != lastRecorded) {
            lastRecorded = cur
            _ab.value = null to null
            scope.launch(Dispatchers.IO) {
                val old = dao.historyFor(cur)
                dao.upsertHistory(HistoryEntity(cur, (old?.playCount ?: 0) + 1, System.currentTimeMillis()))
            }
        }
    }

    // ---- transport -------------------------------------------------------------------------

    fun play(songs: List<Song>, startIndex: Int = 0, shuffle: Boolean = false) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        c.shuffleModeEnabled = shuffle
        c.setMediaItems(songs.map { it.toMediaItem() }, startIndex.coerceIn(songs.indices), 0L)
        c.prepare()
        c.play()
    }

    fun playNext(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return play(listOf(song))
        c.addMediaItem(c.currentMediaItemIndex + 1, song.toMediaItem())
    }

    fun addToQueue(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return play(listOf(song))
        c.addMediaItem(song.toMediaItem())
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() {
        val c = controller ?: return
        if (c.currentPosition > 3000) c.seekTo(0) else c.seekToPreviousMediaItem()
    }
    fun seekTo(ms: Long) { controller?.seekTo(ms); _position.value = ms }
    fun skipTo(index: Int) { controller?.seekTo(index, 0L); controller?.play() }
    fun removeFromQueue(index: Int) { controller?.removeMediaItem(index) }
    fun moveInQueue(from: Int, to: Int) { controller?.moveMediaItem(from, to) }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }
    fun setSpeed(speed: Float) { controller?.setPlaybackSpeed(speed) }

    fun stopAndClear() {
        controller?.run { stop(); clearMediaItems() }
        lastRecorded = null
    }

    fun cycleAb() {
        val c = controller ?: return
        val (a, b) = _ab.value
        _ab.value = when {
            a == null -> c.currentPosition to null
            b == null -> a to c.currentPosition.coerceAtLeast(a + 500)
            else -> null to null
        }
    }

    /** Restores the last saved queue (paused) once the controller is connected. */
    suspend fun restoreQueue(songs: Map<Long, Song>) {
        var tries = 0
        while (controller == null && tries++ < 50) delay(100)
        val c = controller ?: return
        if (c.mediaItemCount > 0) return
        val (ids, index, pos) = store.loadQueue()
        val list = ids.mapNotNull { songs[it] }
        if (list.isEmpty()) return
        val idx = ids.getOrNull(index)?.let { id -> list.indexOfFirst { it.id == id } }?.takeIf { it >= 0 } ?: 0
        c.setMediaItems(list.map { it.toMediaItem() }, idx, pos)
        c.prepare()
    }

    // ---- sleep timer -----------------------------------------------------------------------

    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        if (minutes == null) { _sleepAt.value = null; return }
        val at = System.currentTimeMillis() + minutes * 60_000L
        _sleepAt.value = at
        sleepJob = scope.launch {
            delay(minutes * 60_000L)
            controller?.pause()
            _sleepAt.update { null }
        }
    }
}
