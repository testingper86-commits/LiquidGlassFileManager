package com.music.echo.offline.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.os.Build
import com.music.echo.offline.data.*
import com.music.echo.offline.ui.LocalBottomPad
import com.music.echo.offline.ui.MainViewModel
import com.music.echo.offline.ui.components.SegmentedPills

@Composable
private fun Group(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(
        title.uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 28.dp, top = 20.dp, bottom = 6.dp),
    )
    Column(
        Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHighest).padding(vertical = 6.dp),
        content = content,
    )
}

@Composable
private fun SettingRow(
    title: String, subtitle: String? = null, icon: ImageVector? = null,
    onClick: (() -> Unit)? = null, trailing: @Composable (() -> Unit)? = null,
) {
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) { Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.width(16.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing?.invoke()
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, onOpenEqualizer: () -> Unit) {
    val s by vm.settings.collectAsState()
    val songs by vm.songs.collectAsState()
    val ctx = LocalContext.current
    fun toast(ok: Boolean, good: String) =
        Toast.makeText(ctx, if (ok) good else "Something went wrong", Toast.LENGTH_SHORT).show()

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { vm.exportBackup(it) { ok -> toast(ok, "Backup saved") } }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importBackup(it) { ok -> toast(ok, "Backup restored") } }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = LocalBottomPad.current)) {
        Text(
            "Settings", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.statusBarsPadding().padding(start = 20.dp, top = 16.dp),
        )

        Group("Appearance") {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Player & navigation style", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp))
                SegmentedPills(
                    listOf("Material You", "Liquid Glass"), s.style.ordinal,
                    { vm.set(Keys.STYLE, UiStyle.entries[it].name) },
                )
                if (s.style == UiStyle.Glass && Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                    Text(
                        "Real backdrop blur needs Android 12+. Older devices use plain translucency.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 4.dp),
                    )
                }
                Text("Theme", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 6.dp))
                SegmentedPills(
                    listOf("System", "Light", "Dark"), s.theme.ordinal,
                    { vm.set(Keys.THEME, ThemeMode.entries[it].name) },
                )
            }
            SettingRow("Dynamic color", "Use your wallpaper colors (Android 12+)", Icons.Rounded.Palette,
                onClick = { vm.set(Keys.DYNAMIC, !s.dynamicColor) }) {
                Switch(s.dynamicColor, { vm.set(Keys.DYNAMIC, it) })
            }
            SettingRow("Pure black", "AMOLED background in dark mode", Icons.Rounded.DarkMode,
                onClick = { vm.set(Keys.AMOLED, !s.amoled) }) {
                Switch(s.amoled, { vm.set(Keys.AMOLED, it) })
            }
        }

        Group("Library") {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Hide short audio (ringtones, voice notes)", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp))
                val opts = listOf(0, 30, 60)
                SegmentedPills(
                    listOf("Show all", "< 30s", "< 60s"), opts.indexOf(s.minDurationSec).coerceAtLeast(0),
                    { vm.set(Keys.MIN_DUR, opts[it]) },
                )
            }
            SettingRow("Rescan device", "${songs.size} songs found", Icons.Rounded.Refresh, onClick = { vm.rescan() })
        }

        Group("Audio") {
            SettingRow("Equalizer, bass & virtualizer", if (s.eqEnabled) "On" else "Off", Icons.Rounded.Equalizer, onClick = onOpenEqualizer)
            SettingRow("Skip silence", "Trim silent gaps in tracks", Icons.Rounded.GraphicEq,
                onClick = { vm.set(Keys.SKIP_SILENCE, !s.skipSilence) }) {
                Switch(s.skipSilence, { vm.set(Keys.SKIP_SILENCE, it) })
            }
        }

        Group("Your data") {
            SettingRow("Export backup", "Favorites, playlists and play history → file", Icons.Rounded.FileUpload,
                onClick = { exporter.launch("echo-offline-backup.json") })
            SettingRow("Restore backup", "Matches songs by title and artist", Icons.Rounded.FileDownload,
                onClick = { importer.launch(arrayOf("application/json", "*/*")) })
            SettingRow("Clear play history", null, Icons.Rounded.DeleteSweep, onClick = { vm.clearHistory() })
        }

        Group("About") {
            SettingRow(
                "100% offline", "No internet permission. Everything stays on this device.", Icons.Rounded.CloudOff,
            )
        }
    }
}
