package com.music.echo.offline.files;

import com.music.echo.offline.R;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Shared look & feel helpers: theme colours, glass drawables, small view factories. */
final class Ui {
    static float D = 3f;
    static SharedPreferences sp;
    static int theme = 0, accent = Color.rgb(150, 175, 255), blob1, blob2, blob3;
    static int top = 0, bottom = 0;
    // Not "final" on purpose: javac only inlines static-final primitives initialized with a
    // constant expression. WHITE (a literal) would be baked into every call site and could
    // never be swapped for a light theme; keeping it a real mutable field means one call to
    // setLight() recolors every screen that reads Ui.WHITE / Ui.SUB, without editing each file.
    static int WHITE = 0xFFFFFFFF;
    static int SUB = Color.argb(175, 225, 230, 244);
    static boolean light = false;
    static int bg = Color.rgb(7, 9, 15);
    static int panelR = 10, panelG = 14, panelB = 26;
    static int hiTop = Color.argb(56, 255, 255, 255), hiBot = Color.argb(6, 255, 255, 255);
    static int edgeStroke = Color.argb(72, 255, 255, 255);
    static final String[] THEMES = {"Cool Blue", "Warm Amber", "Monochrome", "Aurora Green"};
    static final int[] DOTS = {Color.rgb(150, 175, 255), Color.rgb(255, 190, 120), Color.rgb(225, 228, 235), Color.rgb(120, 235, 200)};
    static final SimpleDateFormat DF = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());

    static void init(Context c) {
        D = c.getResources().getDisplayMetrics().density;
        if (sp == null) sp = c.getApplicationContext().getSharedPreferences("lg_settings", Context.MODE_PRIVATE);
        setLight(sp.getBoolean("light", false), false);
        setTheme(sp.getInt("theme", 0), false);
    }

    static void setLight(boolean l, boolean save) {
        light = l;
        if (save) sp.edit().putBoolean("light", l).apply();
        if (l) {
            WHITE = Color.rgb(18, 20, 26);
            SUB = Color.argb(210, 70, 75, 90);
            bg = Color.rgb(236, 238, 244);
            panelR = 255; panelG = 255; panelB = 255;
            hiTop = Color.argb(150, 255, 255, 255); hiBot = Color.argb(10, 255, 255, 255);
            edgeStroke = Color.argb(50, 20, 22, 30);
        } else {
            WHITE = 0xFFFFFFFF;
            SUB = Color.argb(175, 225, 230, 244);
            bg = Color.rgb(7, 9, 15);
            panelR = 10; panelG = 14; panelB = 26;
            hiTop = Color.argb(56, 255, 255, 255); hiBot = Color.argb(6, 255, 255, 255);
            edgeStroke = Color.argb(72, 255, 255, 255);
        }
    }

    static int dp(float v) { return Math.round(v * D); }

    static void setTheme(int t, boolean save) {
        theme = t;
        if (save) sp.edit().putInt("theme", t).apply();
        switch (t) {
            case 1: accent = Color.rgb(255, 190, 120); blob1 = Color.argb(115, 255, 150, 70); blob2 = Color.argb(95, 255, 80, 90); blob3 = Color.argb(70, 255, 210, 120); break;
            case 2: accent = Color.rgb(225, 228, 235); blob1 = Color.argb(70, 255, 255, 255); blob2 = Color.argb(55, 170, 180, 200); blob3 = Color.argb(40, 255, 255, 255); break;
            case 3: accent = Color.rgb(120, 235, 200); blob1 = Color.argb(105, 30, 200, 160); blob2 = Color.argb(90, 70, 120, 255); blob3 = Color.argb(70, 150, 255, 200); break;
            default: accent = Color.rgb(150, 175, 255); blob1 = Color.argb(115, 90, 120, 255); blob2 = Color.argb(100, 170, 100, 255); blob3 = Color.argb(70, 60, 200, 255);
        }
    }

    static boolean bool(String k, boolean d) { return sp.getBoolean(k, d); }
    static void set(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }

    /** Liquid-glass panel: dark tint (keeps text readable) + top highlight + hairline edge. */
    static Drawable glass(float radiusDp, boolean strong) {
        float rad = dp(radiusDp);
        GradientDrawable base = new GradientDrawable();
        base.setColor(Color.argb(strong ? (light ? 175 : 125) : (light ? 135 : 92), panelR, panelG, panelB));
        base.setCornerRadius(rad);
        GradientDrawable hi = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{hiTop, hiBot});
        hi.setCornerRadius(rad);
        GradientDrawable edge = new GradientDrawable();
        edge.setColor(Color.TRANSPARENT);
        edge.setCornerRadius(rad);
        edge.setStroke(Math.max(1, dp(1)), edgeStroke);
        return new LayerDrawable(new Drawable[]{base, hi, edge});
    }

    static Drawable accentPill(float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(105, Color.red(accent), Color.green(accent), Color.blue(accent)));
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(Math.max(1, dp(1)), Color.argb(130, 255, 255, 255));
        return g;
    }

    static TextView tv(Context c, CharSequence t, float sp, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        v.setIncludeFontPadding(false);
        return v;
    }

    static ImageView iconBtn(Context c, int glyph, int color) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(Glyphs.get(glyph, color));
        v.setPadding(dp(10), dp(10), dp(10), dp(10));
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        press(v);
        return v;
    }

    /** Springy "liquid" press feedback; never consumes the touch so clicks still work. */
    static void press(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL)
                x.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(new OvershootInterpolator(2.2f)).start();
            return false;
        });
    }

    static void round(View v, final float rDp) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline o) {
                o.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(rDp));
            }
        });
        v.setClipToOutline(true);
    }

    static void tick(View v) {
        if (bool("haptic", true)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    static void toast(Context c, String m) { Toast.makeText(c, m, Toast.LENGTH_SHORT).show(); }

    static String size(long n) {
        if (n < 1024) return n + " B";
        if (n < 1048576L) return (n / 1024) + " KB";
        if (n < 1073741824L) return String.format(Locale.US, "%.1f MB", n / 1048576.0);
        return String.format(Locale.US, "%.2f GB", n / 1073741824.0);
    }

    static String date(long t) { return DF.format(new Date(t)); }
}
