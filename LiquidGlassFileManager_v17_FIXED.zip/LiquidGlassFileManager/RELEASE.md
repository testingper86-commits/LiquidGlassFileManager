# Building a Release APK

## Debug build (fastest way to test on your own device)
In Android Studio: open the project, let Gradle sync, then Run ▶. Or from a terminal:
```
./gradlew assembleDebug
```
Output: `app/build/outputs/apk/debug/app-debug.apk`

## Signed release build

### 1. Generate a keystore (once — keep this file and its passwords safe forever;
losing it means you can never publish an update to the same app under the same signature)
```
keytool -genkeypair -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias liquidglass
```
You'll be asked for a keystore password, a key password, and your name/org details.

### 2. Tell Gradle about it
Create `keystore.properties` in the project root (same folder as `settings.gradle`) —
**never commit this file to a public repo**:
```
storeFile=../release-key.jks
storePassword=YOUR_STORE_PASSWORD
keyAlias=liquidglass
keyPassword=YOUR_KEY_PASSWORD
```

Add a `signingConfigs` block to `app/build.gradle`, inside the `android { }` block:
```gradle
def keystoreProps = new Properties()
def keystoreFile = rootProject.file("keystore.properties")
if (keystoreFile.exists()) keystoreProps.load(new FileInputStream(keystoreFile))

signingConfigs {
    release {
        if (keystoreFile.exists()) {
            storeFile file(keystoreProps['storeFile'])
            storePassword keystoreProps['storePassword']
            keyAlias keystoreProps['keyAlias']
            keyPassword keystoreProps['keyPassword']
        }
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled false // flip to true once you've tested a minified build thoroughly
    }
}
```

### 3. Build it
```
./gradlew assembleRelease
```
Output: `app/build/outputs/apk/release/app-release.apk` — this one is signed and
installable/shareable directly (sideloading), or uploadable to a store listing.

### 4. Verify the signature (optional sanity check)
```
apksigner verify --print-certs app/build/outputs/apk/release/app-release.apk
```

## Notes
- This project was built and edited without a local Android SDK or network access available
  to the assistant, so none of the above commands have actually been run against this exact
  codebase — they're the standard, correct Gradle/keytool steps, but you are the first to run
  them here. If `assembleRelease` fails, the error text is the most useful thing to go on.
- The included `gradle-wrapper.properties` points at Gradle 8.9; the wrapper jar/scripts
  (`gradlew`, `gradlew.bat`) are not bundled, Android Studio regenerates them on first sync.
