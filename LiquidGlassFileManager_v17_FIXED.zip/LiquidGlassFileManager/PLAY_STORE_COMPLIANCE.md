# Play Store notes: MANAGE_EXTERNAL_STORAGE

This app requests `MANAGE_EXTERNAL_STORAGE` ("All files access"). I can't submit
anything to Play Console or guarantee approval on your behalf — this is a summary
of what Google's policy currently requires, so you know what's ahead if you ever
publish rather than sideload this app. Verify against Google's live policy page
before submitting, since these requirements change.

## When it's actually required
Google only approves this permission for apps whose **core function** requires
broad file access — a general-purpose file manager is one of the accepted use
cases, but Google reviews the *actual functionality*, not just the app category.
If most of the app is really about one thing (e.g. photo editing) and file
browsing is secondary, they will likely reject it and expect you to use the
Storage Access Framework / scoped storage instead.

## What the submission needs
- **Permission declaration form** in Play Console, explaining in your own words
  why the app needs broad access and how it's used.
- **A privacy policy URL**, published and reachable, describing what file data
  the app can access and whether anything leaves the device (this app doesn't
  transmit files anywhere, which is worth stating explicitly).
- **An in-app disclosure before the permission prompt** — a short screen or
  dialog explaining why you're about to ask for the permission. `showStorageAccess()`
  in this app already does something close to this; you may need to strengthen
  the wording for review purposes.
- Sometimes a **demo video** showing the broad-access feature in use, if
  requested during review.

## Practical risk
Google has been increasingly strict about this permission over the past few
years, and rejections/re-reviews are common even for legitimate file managers.
Budget for at least one rejection-and-resubmit cycle if you go this route.

## Alternative if you don't need it
If you're fine limiting the app to the Downloads/Pictures/Documents/Movies/Music
folders (the ones already surfaced in Quick Access), you could drop
`MANAGE_EXTERNAL_STORAGE` entirely and use the Storage Access Framework
(`ACTION_OPEN_DOCUMENT_TREE`) instead — no special Play Store review, but the
user has to grant access per-folder rather than once for the whole device.
