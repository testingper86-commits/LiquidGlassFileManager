# LiquidGlassFileManager

This archive is laid out as a GitHub repository: project files and `.github/workflows/build.yml` are at the repository root. Do not upload this ZIP as a nested project archive inside another ZIP.

## Create a new GitHub repository
1. Create an empty repository (for example, `LiquidGlassFileManager`).
2. Extract this ZIP on your device/computer.
3. Upload the *contents* of the extracted folder to the repository root. Ensure `settings.gradle.kts`, `app/`, `gradlew`, `gradle/`, and `.github/workflows/build.yml` appear at the root.
4. Commit to `main`. The workflow starts automatically. You can also open **Actions → Build LiquidGlassFileManager APK → Run workflow**.
5. If successful, open the completed run and download the `LiquidGlassFileManager-debug-apk` artifact.

## Honest status
The ZIP layout and workflow are prepared, but a GitHub-hosted build has not been run from your new repository. The APK artifact will only be available if the workflow succeeds. Device-level behavior still needs testing.
